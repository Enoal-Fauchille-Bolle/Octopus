# API Documentation

Ce projet fournit une API permettant la gestion des utilisateurs, des redirections, des sessions, et des statistiques de redirections. 

## Table des matières
- [Installation](#installation)
- [Configuration](#configuration)
- [Endpoints](#endpoints)
- [Tests unitaires](#tests-unitaires)

## Installation

1. Clonez le repository:
   ```bash
   git clone <repo_url>
   cd <repo_directory>
   ```

2. Installez les dépendances:
   ```bash
   npm install
   ```

3. Configurez la base de données PostgreSQL selon le schéma de tables fourni dans `database.sql`.

4. Lancez l'application:
   ```bash
   npm start
   ```

## Configuration

Les variables d'environnement nécessaires sont définies dans `.env`. Voici quelques exemples:

```
DB_HOST=localhost
DB_PORT=5432
DB_USER=<username>
DB_PASSWORD=<password>
DB_NAME=<database_name>
JWT_SECRET=<jwt_secret>
```

Assurez-vous de définir les valeurs appropriées pour chaque variable.

## Endpoints

### Authentification
- **POST** `/api/auth/register` - Enregistrer un nouvel utilisateur
- **POST** `/api/auth/verify-email` - Vérifier l'email d'un utilisateur
- **POST** `/api/auth/resend-verification-email` - Renvoyer l'email de vérification
- **POST** `/api/auth/login` - Authentifier un utilisateur
- **POST** `/api/auth/forgot-password` - Demander la réinitialisation du mot de passe
- **POST** `/api/auth/reset-password` - Réinitialiser le mot de passe
- **GET** `/api/auth/reset-password` - Vérifier un lien de réinitialisation du mot de passe
- **POST** `/api/auth/logout` - Déconnecter l'utilisateur
- **GET** `/api/auth/sessions` - Obtenir les sessions actives d'un utilisateur
- **DELETE** `/api/auth/sessions/all` - Supprimer toutes les sessions de l'utilisateur
- **DELETE** `/api/auth/sessions/{sessionId}` - Supprimer une session spécifique
- **POST** `/api/auth/unlock-account` - Déverrouiller le compte utilisateur
- **POST** `/api/auth/whitelist-country` - Ajouter un pays à la liste blanche
- **GET** `/api/auth/me` - Obtenir les informations de l'utilisateur connecté
- **PATCH** `/api/auth/me` - Mettre à jour les informations de l'utilisateur connecté
- **DELETE** `/api/auth/me` - Supprimer le compte utilisateur

### Redirection
- **GET** `/api/redirect/{alias}` - Accéder à une redirection par alias
- **POST** `/api/redirect` - Créer une nouvelle redirection
- **GET** `/api/redirects` - Obtenir toutes les redirections de l'utilisateur
- **PUT** `/api/redirect/{id}` - Mettre à jour une redirection
- **DELETE** `/api/redirect/{id}` - Supprimer une redirection

### Statistiques
- **GET** `/api/stats/redirect/{id}` - Obtenir les statistiques d'une redirection
- **GET** `/api/stats` - Obtenir des statistiques générales

## Tests unitaires

Les tests unitaires sont basés sur [Jest](https://jestjs.io/) et [Supertest](https://github.com/visionmedia/supertest) pour tester les API.

### Configuration de Jest

1. Créez un fichier de test pour chaque endpoint sous `__tests__/`.

2. Exemple de test pour l'endpoint `/api/auth/login`:
   ```javascript
   const request = require('supertest');
   const app = require('../app'); // Importez votre application Express ici

   describe('POST /api/auth/login', () => {
     it('should return 200 and the user token when login is successful', async () => {
       const response = await request(app)
         .post('/api/auth/login')
         .send({
           email: 'test@example.com',
           password: 'password123'
         });

       expect(response.status).toBe(200);
       expect(response.body).toHaveProperty('token');
     });

     it('should return 400 for incorrect credentials', async () => {
       const response = await request(app)
         .post('/api/auth/login')
         .send({
           email: 'test@example.com',
           password: 'wrongpassword'
         });

       expect(response.status).toBe(400);
     });
   });
   ```

3. Pour lancer les tests :
   ```bash
   npm run test
   ```

### Tests de la base de données

Assurez-vous de créer un environnement de test isolé (par exemple, une base de données PostgreSQL temporaire) pour éviter d'impacter les données de production.