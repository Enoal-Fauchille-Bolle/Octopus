const logger = require('./logger');

logger.debug("Starting anticrash");

const handleUncaughtException = (error) => {
    logger.error("Uncaught Exception", error);
};

const handleUnhandledRejection = (reason, promise) => {
    logger.error(`Unhandled Rejection`, reason);
};

process.on('uncaughtException', handleUncaughtException);

process.on('unhandledRejection', handleUnhandledRejection);

logger.debug("Anticrash started");
