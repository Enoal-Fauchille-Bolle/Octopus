// Initialize logger
const logger = require('./logger.js');
const config = require('./config.js');

// Log the start of the server
logger.info("Starting Server");

// Import dependencies
const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const bodyParser = require('body-parser');

// Load environment variables
dotenv.config();

// Anti-crash
// require('./anticrash.js');

// Import routes and middlewares
const authRoutes = require('./routes/authRoutes.js');
const userRoutes = require('./routes/userRoutes.js');
const redirectRoutes = require('./routes/redirectRoutes.js');
const redirectStatsRoutes = require('./routes/redirectStatsRoutes.js');
const adminRoutes = require('./routes/adminRoutes.js');
const notFoundMiddleware = require('./middleware/notFound.js');
const authMiddleware = require('./middleware/authMiddleware.js');
const adminMiddleware = require('./middleware/adminMiddleware.js');
const languageMiddleware = require('./middleware/languageMiddleware');
const requestLogger = require('./middleware/requestLogger');
const responseTimeLogger = require('./middleware/responseTimeLogger');
const ipAccessCheck = require('./middleware/ipAccessCheck');
const redirectController = require('./controllers/redirectController');

// logger.info(`enoal.fauchille@gmail.com 1234567890 GET /api/auth/login c44634b5-df60-4072-9807-53f58bfe6dc4 82.67.83.142 4s 0.000s https://host.azerdev.me`);

// Express app setup
const app = express();
const PORT = process.env.PORT || 3000;

// Enable trust proxy
app.set('trust proxy', true);

// Swagger UI setup
if (config.swagger.enable_swagger) {
    logger.debug("Starting Swagger UI");
    const setupSwagger = require('./swagger.js');
    setupSwagger(app);
    logger.debug("Swagger UI started");
}

// Resource Monitoring setup
if (config.resource_monitoring.memory.enable_memory_monitoring || config.resource_monitoring.cpu.enable_cpu_monitoring) {
    logger.debug("Starting Resource Monitoring");
    const resourceMonitoring = require('./resourceMonitoring.js');
    resourceMonitoring.startResourceMonitoring(config);
    logger.debug("Resource Monitoring started");
}

// Logger Middleware
app.use(requestLogger);
app.use(responseTimeLogger);

// Language Middleware
app.use(languageMiddleware);

// Domain Check Middleware
if (config.general_security.check_domain_origin) {
    const domainCheck = require('./middleware/domainCheck');
    logger.debug("Starting Domain Check Middleware");
    app.use(domainCheck);
    logger.debug("Domain Check Middleware started");
}

// HTTP Method Check Middleware
if (config.general_security.block_unused_http_methods) {
    logger.debug("Starting HTTP Method Check Middleware");
    const methodCheck = require('./middleware/methodCheck');
    app.use(methodCheck);
    logger.debug("HTTP Method Check Middleware started");
}

// User-Agent Check Middleware
if (config.general_security.check_user_agent) {
    const useragentCheck = require('./middleware/useragentCheck');
    logger.debug("Starting User-Agent Check Middleware");
    app.use(useragentCheck);
    logger.debug("User-Agent Check Middleware started");
}

// VPN Check Middleware
if (config.general_security.block_vpn) {
    logger.debug("Starting VPN Check Middleware");
    const vpnCheck = require('./middleware/vpnCheck.js');
    app.use(vpnCheck);
    logger.debug("VPN Check Middleware started");
}

// IP Access Control Middleware
app.use(ipAccessCheck);

// Rate Limiter Middleware
if (config.rate_limiting.enable_rate_limiting) {
    logger.debug("Starting Rate Limiter Middleware");
    const rateLimiter = require('./middleware/rateLimit.js');
    app.use(rateLimiter);
    logger.debug("Rate Limiter Middleware started");
}

// CORS & Body Parser Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Routes
app.use('/api/auth', authRoutes);
app.get('/api/redirect/:identifier', redirectController.getRedirect);
app.use('/api/admin', authMiddleware, adminMiddleware, adminRoutes);
app.use("/api", authMiddleware, [
    userRoutes,
    redirectRoutes,
    redirectStatsRoutes
]);

// Not found middleware
app.use(notFoundMiddleware);

// Server Starting
app.listen(PORT, () => {
    logger.info(`Server is running on port ${PORT}`);
}).on('error', (error) => {
    logger.error(`Error while starting server`, error);
    process.exit(1);
});

module.exports = app;
