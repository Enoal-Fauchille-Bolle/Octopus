const fs = require('fs');
const yaml = require('js-yaml');

let config;
let reloadTimeout = null

// Check the config for missing or invalid values
function checkConfig(config) {
    const checks = [
        { path: 'app.application_name', type: 'string' },
        { path: 'app.application_icon', type: 'string' },
        { path: 'app.base_url', type: 'string' },
        { path: 'session_management.max_sessions_per_user', type: 'number' },
        { path: 'session_management.short_token_expiry', type: 'string' },
        { path: 'session_management.long_token_expiry', type: 'string' },
        { path: 'redirect.max_original_url_length', type: 'number' },
        { path: 'redirect.alias_length', type: 'number' },
        { path: 'redirect.alias_characters', type: 'string' },
        { path: 'redirect.allow_custom_alias', type: 'boolean' },
        { path: 'redirect.custom_alias_min_length', type: 'number' },
        { path: 'redirect.custom_alias_max_length', type: 'number' },
        { path: 'redirect.use_cache', type: 'boolean' },
        { path: 'email.from_address', type: 'string' },
        { path: 'email.resend_email_cooldown', type: 'number' },
        { path: 'password_policy.enable_password_policy', type: 'boolean' },
        { path: 'password_policy.min_length', type: 'number' },
        { path: 'password_policy.max_length', type: 'number' },
        { path: 'password_policy.require_numbers', type: 'boolean' },
        { path: 'password_policy.require_lowercase', type: 'boolean' },
        { path: 'password_policy.require_uppercase', type: 'boolean' },
        { path: 'password_policy.require_special_characters', type: 'boolean' },
        { path: 'account_lockout.enable_account_lockout', type: 'boolean' },
        { path: 'account_lockout.max_failed_attempts', type: 'number' },
        { path: 'account_lockout.require_email_verification', type: 'boolean' },
        { path: 'account_lockout.lockout_duration', type: 'number' },
        { path: 'general_security.block_vpn', type: 'boolean' },
        { path: 'general_security.check_domain_origin', type: 'boolean' },
        { path: 'general_security.allowed_domains', type: 'array' },
        { path: 'logging.enable_logging', type: 'boolean' },
        { path: 'logging.log_level', type: 'string' },
        { path: 'logging.log_dir', type: 'string' },
        { path: 'logging.colors', type: 'boolean' },
        { path: 'logging.max_size', type: 'number' },
        { path: 'resource_monitoring.memory.enable_memory_monitoring', type: 'boolean' },
        { path: 'resource_monitoring.memory.warning_threshold', type: 'number' },
        { path: 'resource_monitoring.memory.check_interval', type: 'number' },
        { path: 'resource_monitoring.cpu.enable_cpu_monitoring', type: 'boolean' },
        { path: 'resource_monitoring.cpu.warning_threshold', type: 'number' },
        { path: 'resource_monitoring.cpu.check_interval', type: 'number' },
        { path: 'rate_limiting.enable_rate_limiting', type: 'boolean' },
        { path: 'rate_limiting.mode', type: 'string' },
        { path: 'rate_limiting.max_requests', type: 'number' },
        { path: 'rate_limiting.time_window', type: 'number' },
    ];

    for (const check of checks) {
        const value = getValue(config, check.path.split('.'));
        if (value === undefined) {
            console.error(`Missing required config: ${check.path}`);
        } else if (typeof value !== check.type && !(check.type === 'array' && Array.isArray(value))) {
            console.error(`Invalid type for ${check.path}: expected ${check.type}, got ${value ? typeof value : value}`);
        }
    }

}

// Get a value from an object using an array of keys
function getValue(obj, pathArray) {
    return pathArray.reduce((acc, key) => acc && acc[key], obj);
}

// Load the configuration from config.yaml
const loadConfig = () => {
    try {
        config = yaml.load(fs.readFileSync('./config.yaml', 'utf8'));
        checkConfig(config);
    } catch (error) {
        console.error("Error while loading config file", error);
    }
};

// Load the configuration for the first time
loadConfig();

// Listen for changes in the config file
fs.watch('./config.yaml', (eventType, a) => {
    if (eventType === 'change') {
        if (reloadTimeout)
            clearTimeout(reloadTimeout);
        reloadTimeout = setTimeout(() => {
            const logger = require('./logger');
            if (logger && logger.debug)
                logger.debug("Config file changed, reloading config...");
            else
                console.log("Config file changed, reloading config...");
            loadConfig();
            if (logger && logger.debug)
                logger.debug("Config reloaded");
            else
                console.log("Config reloaded");
        }, 100);
    }
});

// Create a proxy object to access the config object
const configProxy = new Proxy({}, {
    get: (_, prop) => config[prop]
});

module.exports = configProxy;
