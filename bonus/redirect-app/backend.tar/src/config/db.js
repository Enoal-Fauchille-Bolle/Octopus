const { Pool } = require('pg');
const dotenv = require('dotenv');
const logger = require('../logger');
const config = require('../config');
const sleep = require("../utils/sleep");

dotenv.config();

const poolConfig = {
    user: process.env.POSTGRES_USER,
    host: process.env.POSTGRES_HOST,
    database: process.env.POSTGRES_DB,
    password: process.env.POSTGRES_PASSWORD,
    port: process.env.POSTGRES_PORT || 5432,
    max: 10,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 2000
};

const pool = new Pool(poolConfig);

logger.debug(`Connecting to database ${process.env.POSTGRES_DB} on ${process.env.POSTGRES_HOST}:${process.env.POSTGRES_PORT}`);


let attemptCount = 0;

// Connection logic
async function connectToDatabase() {
    attemptCount++;
    try {
        await pool.connect();
        logger.info('Connected to the database');
        return true;
    } catch (error) {
        logger.error(`Error connecting to the database (attempt ${attemptCount})`, error);
        return handleConnectionRetry();
    }
}

// Retry logic
async function handleConnectionRetry() {
    if (attemptCount < config.database.connection_attempts) {
        await sleep(5000);
        return connectToDatabase();
    } else {
        logger.error(`Failed to connect to the database after ${attemptCount} attempts`);
        return false;
    }
}

// Error handling
pool.on('error', async (error) => {
    logger.error('Unexpected database error:', error);
    await reconnectDatabase();
});

// Reconnection logic
async function reconnectDatabase() {
    try {
        await pool.connect();
        logger.info('Reconnected to the database');
    } catch (reconnectErr) {
        logger.error('Reconnection attempt failed:', reconnectErr);
    }
}

// Connection check
async function checkDatabaseConnection() {
    try {
        await pool.query("SELECT 1");
        attemptCount = 0;
    } catch (error) {
        attemptCount++;
        logger.warn(`Warning: Lost connection to the database, attempt #${attemptCount}.`);
        await reconnectDatabase();
    }
}

// Initial connection
(async () => {
    const isConnected = await connectToDatabase();
    if (!isConnected) return;

    attemptCount = 0;
    if (config.database.enable_connection_check)
        setInterval(checkDatabaseConnection, config.database.connection_check_interval * 1000);
})();

module.exports = pool;
