const color = {
    default: function (msg) {
        return '\u001b[' + 0 + 'm' + msg + '\u001b[0m'
    },
    red: function (msg) {
        return '\u001b[' + 31 + 'm' + msg + '\u001b[0m'
    },
    yellow: function (msg) {
        // return '\u001b[' + 93 + 'm' + msg + '\u001b[0m'
        return '\u001b[' + 33 + 'm' + msg + '\u001b[0m'
    },
    cyan: function (msg) {
        return '\u001b[' + 36 + 'm' + msg + '\u001b[0m'
    },
    green: function (msg) {
        return '\u001b[' + 32 + 'm' + msg + '\u001b[0m'
    },
    gray: function (msg) {
        return '\u001b[' + 90 + 'm' + msg + '\u001b[0m'
    },
    blue: function (msg) {
        return '\u001b[' + 34 + 'm' + msg + '\u001b[0m'
    },
    magenta: function (msg) {
        return '\u001b[' + 35 + 'm' + msg + '\u001b[0m'
    },
    white: function (msg) {
        return '\u001b[' + 37 + 'm' + msg + '\u001b[0m'
    },
}
const background = {
    red: function (msg) {
        return '\u001b[' + 101 + 'm' + msg + '\u001b[0m'
    },
    orange: function (msg) {
        return '\u001b[' + 43 + 'm' + msg + '\u001b[0m'
    },
    cyan: function (msg) {
        return '\u001b[' + 46 + 'm' + msg + '\u001b[0m'
    },
    green: function (msg) {
        return '\u001b[' + 42 + 'm' + msg + '\u001b[0m'
    },
    gray: function (msg) {
        return '\u001b[' + 40 + 'm' + msg + '\u001b[0m'
    },
    blue: function (msg) {
        return '\u001b[' + 44 + 'm' + msg + '\u001b[0m'
    },
    purple: function (msg) {
        return '\u001b[' + 45 + 'm' + msg + '\u001b[0m'
    },
    white: function (msg) {
        return '\u001b[' + 47 + 'm' + msg + '\u001b[0m'
    },
}
const textformatting = {
    bold: function (msg) {
        return '\u001b[' + 1 + 'm' + msg + '\u001b[0m'
    },
    low: function (msg) {
        return '\u001b[' + 2 + 'm' + msg + '\u001b[0m'
    },
    italic: function (msg) {
        return '\u001b[' + 3 + 'm' + msg + '\u001b[0m'
    },
    underlined: function (msg) {
        return '\u001b[' + 4 + 'm' + msg + '\u001b[0m'
    },
    slowblink: function (msg) {
        return '\u001b[' + 5 + 'm' + msg + '\u001b[0m'
    },
    fastblink: function (msg) {
        return '\u001b[' + 6 + 'm' + msg + '\u001b[0m'
    },
    invisible: function (msg) {
        return '\u001b[' + 8 + 'm' + msg + '\u001b[0m'
    },
    strikethrough: function (msg) {
        return '\u001b[' + 9 + 'm' + msg + '\u001b[0m'
    },
    doubleunderlined: function (msg) {
        return '\u001b[' + 21 + 'm' + msg + '\u001b[0m'
    },
    overlined: function (msg) {
        return '\u001b[' + 53 + 'm' + msg + '\u001b[0m'
    },
    uptext: function (msg) {
        return '\u001b[' + 73 + 'm' + msg + '\u001b[0m'
    },
    downtext: function (msg) {
        return '\u001b[' + 74 + 'm' + msg + '\u001b[0m'
    },
}

module.exports = {
    color,
    background,
    textformatting
}