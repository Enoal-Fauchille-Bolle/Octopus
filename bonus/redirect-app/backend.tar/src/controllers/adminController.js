const logger = require('../logger');
const config = require('../config');

const User = require('../models/userModel');

// const { checkCode, decryptMfaSecret } = require('../utils/mfa');

const getUsers = async (req, res) => {
    logger.debug(`Getting all users`);

    const users = (await User.getAllUsers())
        .sort((a, b) => a.id - b.id)
        .map(user => {
            return { ...user, is_admin: config.admin.admin_emails.includes(user.email) }
        });

    res.status(200).json(users);
};

const getUser = async (req, res) => {
    const { id } = req.params;

    // Check parameters
    if (!id) {
        return res.status(400).json({ error: req.translate("errors.missing_path_parameter", { param: "id" }) });
    }

    logger.debug(`Getting user with ID ${id}`);

    const user = await User.findById(id)

    user.is_admin = config.admin.admin_emails.includes(user.email);

    if (!user) {
        return res.status(404).json({ error: req.translate("errors.user_not_found") });
    }

    res.status(200).json(user);
}

module.exports = {
    getUsers,
    getUser,
};