const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const ms = require('ms');
require('dotenv').config();
const { v4: uuidv4 } = require('uuid');

const config = require('../config');
const logger = require('../logger');

const User = require('../models/userModel');
const Session = require('../models/sessionModel');

const emailIsValid = require('../utils/emailIsValid');
const sendVerificationEmail = require('../services/sendVerificationEmail');
const sendResetPasswordEmail = require('../services/sendResetPasswordEmail');
const sendPasswordChangedEmail = require('../services/sendPasswordChangedEmail');
const sendAccountLockedEmail = require('../services/sendAccountLockedEmail');
const sendWhitelistCountryEmail = require('../services/sendWhitelistCountryEmail');
const sendUnknownCountryEmail = require('../services/sendUnknownCountryEmail');
const getCountryFromIP = require('../services/getCountryFromIP');
const checkUUID = require('../utils/checkUUID');
const sleep = require('../utils/sleep');
const checkPasswordPolicy = require('../utils/checkPasswordPolicy');
const parseRequest = require('../utils/parseRequest');
const checkEmailAccess = require('../utils/checkEmailAccess');
const checkRecaptchaResponse = require('../services/checkRecaptchaResponse');
const { generateMfaSecret, checkCode, encryptMfaSecret, decryptMfaSecret } = require('../utils/mfa');
const generateBackupCodes = require('../utils/generateBackupCodes.js');

const verificationEmailCooldown = [];

const register = async (req, res) => {
    const { username, email, password, recaptchaResponse } = req.body;
    const { useragent, browser, os, ipAddress } = parseRequest(req);

    // Check parameters
    if (!username) {
        logger.debug('Missing required parameter: username');
        return res.status(400).json({ error: req.translate("error.missing_parameter", { param: "username" }) });
    }
    if (!email) {
        logger.debug('Missing required parameter: email');
        return res.status(400).json({ error: req.translate("error.missing_parameter", { param: "email" }) });
    }
    if (!emailIsValid(email)) {
        logger.debug('Invalid email');
        return res.status(400).json({ error: req.translate("user.invalid_email") });
    }
    if (!password) {
        logger.debug('Missing required parameter: password');
        return res.status(400).json({ error: req.translate("error.missing_parameter", { param: "password" }) });
    }

    // Check recaptcha response
    if (config.recaptcha.enable_recaptcha_registration) {
        const recaptcha = await checkRecaptchaResponse(recaptchaResponse, config.recaptcha.recaptcha_type_registration);
        if (!recaptcha) {
            logger.debug('Recaptcha verification failed');
            return res.status(403).json({ error: req.translate("auth.recaptcha.failed"), recaptcha_failed: true });
        }
    }

    // Check email access
    const emailAccess = checkEmailAccess(email);
    if (!emailAccess.allowed) {
        if (emailAccess.blacklisted) {
            logger.debug(`Email ${email} is in the blacklist`);
            return res.status(403).json({ error: req.translate("user.email_blacklisted") });
        }
        if (!emailAccess.whitelisted) {
            logger.debug(`Email ${email} is not in the whitelist`);
            return res.status(403).json({ error: req.translate("user.email_not_whitelisted") });
        }
    }

    // Check request headers
    if (!useragent) {
        logger.error("Could not parse useragent");
        return res.status(500).json({ error: req.translate("error.internal", { action: "parsing useragent" }) });
    }
    if (!ipAddress) {
        logger.error("Could not get IP address from request");
        return res.status(500).json({ error: req.translate("error.internal", { action: "getting IP address from request" }) });
    }

    try {
        const userExists = await User.findByEmail(email) != null;
        if (userExists) {
            logger.debug('This email is already in use.');
            return res.status(409).json({ error: req.translate("user.email_already_in_use") });
        }

        const usernameExists = await User.findByUsername(username) != null;
        if (usernameExists) {
            logger.debug('This username is already in use.');
            return res.status(409).json({ error: req.translate("user.username_already_in_use") });
        }

        // Check password policy
        const passwordPolicy = checkPasswordPolicy(password, req);
        if (!passwordPolicy.valid) {
            logger.debug('Password does not meet the password policy requirements');
            return res.status(400).json({ error: req.translate("auth.password_policy.invalid_password_policy", { message: passwordPolicy.message }) });
        }

        // Hash password
        const salt = bcrypt.genSaltSync(10);
        const hashedPassword = bcrypt.hashSync(password, salt);

        // Generate an uuid email-verification-token
        const email_token = uuidv4();

        // Get country from IP
        const country_code = await getCountryFromIP(ipAddress);
        if (!country_code) {
            logger.error("Error while getting country from IP");
            return res.status(500).json({ error: req.translate("error.internal", { action: "getting country from IP" }) });
        }

        // Create new user
        const newUser = await User.createUser(username, email, hashedPassword, email_token, country_code);

        // Send email with token
        await sendVerificationEmail(email, email_token);

        // Add email to cooldown and remove it after x seconds
        verificationEmailCooldown.push(email);
        setTimeout(() => {
            const index = verificationEmailCooldown.indexOf(email);
            if (index > -1) {
                verificationEmailCooldown.splice(index, 1);
            }
        }, config.email.resend_email_cooldown * 1000);

        // Generate sessionId
        const sessionId = uuidv4();

        // Generate token
        const token = jwt.sign({
            userId: newUser.id,
            sessionId: sessionId
        }, process.env.JWT_SECRET, {
            expiresIn: config.session_management.short_token_expiry,
        });

        // Save session
        const token_expiresAt = new Date(Date.now() + ms(config.session_management.short_token_expiry)).toISOString();
        await Session.createSession(sessionId, newUser.id, token_expiresAt, useragent, os, browser, ipAddress, country_code);

        logger.debug(`Useragent: ${useragent}`);
        logger.debug(`Browser: ${browser}`);
        logger.debug(`OS: ${os}`);
        logger.debug(`IP Address: ${ipAddress}`);
        logger.debug(`Country: ${req.getCountryName(country_code)}`);

        logger.debug(`User ID ${newUser.id} created: ${newUser.email}`);
        res.status(201).json({ token });
    } catch (error) {
        logger.error("Error while creating user", error);
        res.status(500).json({ error: req.translate("error.internal", { action: "creating user" }) });
    }
};

const verifyEmail = async (req, res) => {
    const { token: verificationToken } = req.body;
    logger.debug(`Email Verification Token: ${verificationToken}`);

    // Check parameters
    if (!verificationToken) {
        logger.debug('Missing required parameter: token');
        return res.status(400).json({ error: req.translate("error.missing_parameter", { param: "token" }) });
    }

    try {
        const user = await User.findByEmailVerificationToken(verificationToken);
        if (user == null) {
            logger.debug('Invalid verification token.');
            return res.status(404).json({ error: req.translate("auth.email_verification.invalid_token") });
        }

        // Check if the user is already verified
        if (user.email_verified) {
            logger.debug('Email is already verified.');
            return res.status(400).json({ error: req.translate("auth.email_verification.already_verified") });
        }

        // Update user email_verified_at
        await User.verifyEmail(user.id);

        logger.debug(`User ID ${user.id} email verified: ${user.email}`);
        res.status(200).json({ message: req.translate("auth.email_verification.verified") });
    } catch (error) {
        logger.error("Error while verifying email", error);
        res.status(500).json({ error: req.translate("error.internal", { action: "verifying email" }) });
    }
}

const resendVerificationEmail = async (req, res) => {
    const { email, recaptchaResponse } = req.body;
    logger.debug(`Email: ${email}`);

    // Check parameters
    if (!email) {
        logger.debug('Missing required parameter: email');
        return res.status(400).json({ error: req.translate("error.missing_parameter", { param: "email" }) });
    }

    // Check recaptcha response
    if (config.recaptcha.enable_recaptcha_resend_email_verification) {
        const recaptcha = await checkRecaptchaResponse(recaptchaResponse, config.recaptcha.recaptcha_type_resend_email_verification);
        if (!recaptcha) {
            logger.debug('Recaptcha verification failed');
            return res.status(403).json({ error: req.translate("auth.recaptcha.failed"), recaptcha_failed: true });
        }
    }

    try {
        const user = await User.findByEmail(email);
        if (user == null) {
            logger.debug('User not found.');
            return res.status(404).json({ error: req.translate("user.not_found") });
        }

        // Check if user is already verified
        if (user.email_verified) {
            logger.debug('Email is already verified.');
            return res.status(400).json({ error: req.translate("auth.email_verification.already_verified") });
        }

        // Check if email is on cooldown
        if (verificationEmailCooldown.find(obj => obj.email === email)) {
            const remainingCooldown = Math.round(config.email.resend_email_cooldown - (Date.now() - verificationEmailCooldown.find(obj => obj.email === email)?.sent_at) / 1000);
            logger.debug(`Email is on cooldown. Remaining cooldown: ${remainingCooldown}s`);
            return res.status(429).json({
                error: req.translate("auth.email_verification.cooldown", { cooldown: remainingCooldown }),
                delay: remainingCooldown
            });
        }

        // Check if user already has verification-token
        if (!user.email_verification_token) {
            // Create new verification token
            user.email_verification_token = uuidv4();
            logger.debug(`New email verification token created for ${email}: ${user.email_verification_token}`);
            await User.updateEmailVerificationToken(user.id, user.email_verification_token);
        }

        // Send email with token
        await sendVerificationEmail(email, user.email_verification_token);

        // Add email to cooldown and remove it after x seconds
        verificationEmailCooldown.push({
            email: email,
            sent_at: new Date()
        });
        setTimeout(() => {
            const index = verificationEmailCooldown.findIndex(obj => obj.email === email);
            if (index > -1) {
                verificationEmailCooldown.splice(index, 1);
            }
            logger.debug(`Email removed from verification cooldown: ${email}`);
        }, config.email.resend_email_cooldown * 1000);

        res.status(200).json({ message: req.translate("auth.email_verification.sent") });
    } catch (error) {
        logger.error("Error while sending email", error);
        res.status(500).json({ error: req.translate("error.internal", { action: "sending email" }) });
    }
}

const login = async (req, res) => {
    const { email, password, rememberme, mfa_code, recaptchaResponse } = req.body;
    const { useragent, browser, os, ipAddress } = parseRequest(req);
    logger.debug(`Email: ${email}`);

    // Check parameters
    if (!email) {
        logger.debug('Missing required parameter: email');
        return res.status(400).json({ error: req.translate("error.missing_parameter", { param: "email" }) });
    }
    if (!password) {
        logger.debug('Missing required parameter: password');
        return res.status(400).json({ error: req.translate("error.missing_parameter", { param: "password" }) });
    }

    // Check request headers
    if (!useragent) {
        logger.error("Could not parse useragent");
        return res.status(500).json({ error: req.translate("error.internal", { action: "parsing useragent" }) });
    }
    if (!ipAddress) {
        logger.error("Could not get IP address from request");
        return res.status(500).json({ error: req.translate("error.internal", { action: "getting IP address from request" }) });
    }

    // Check recaptcha response
    if (config.recaptcha.enable_recaptcha_login) {
        const recaptcha = await checkRecaptchaResponse(recaptchaResponse, config.recaptcha.recaptcha_type_login);
        if (!recaptcha) {
            logger.debug('Recaptcha verification failed');
            return res.status(403).json({ error: req.translate("auth.recaptcha.failed"), recaptcha_failed: true });
        }
    }

    try {
        const user = await User.findByEmail(email);
        if (user == null) {
            logger.debug('User not found.');
            return res.status(404).json({ error: req.translate("user.not_found") });
        }

        // Check if user is verified and require_email_verification for unlocking is enabled
        // if (config.account_lockout.enable_account_lockout && config.account_lockout.require_email_verification && !user.email_verified) {
        //     return res.status(403).json({ error: req.translate("auth.email_verification.not_verified") });
        // }

        // Check if user is locked out
        if (config.account_lockout.enable_account_lockout && user.is_locked) {
            // Check if account unlock is by email verification
            if (config.account_lockout.require_email_verification) {
                logger.debug('Account is locked.');
                return res.status(403).json({ error: req.translate("auth.account_lockout.locked_email_sent") });
            } else {
                // Check if lockout expired
                if (user.lockout_expires > new Date()) {
                    const remainingLockoutMinutes = Math.round((user.lockout_expires - new Date()) / 1000 / 60);
                    logger.debug(`Account is locked. Lockout expires in ${remainingLockoutMinutes} minutes`);
                    return res.status(403).json({ error: req.translate("auth.account_lockout.locked_wait", { remaining_minutes: remainingLockoutMinutes }), lockout_expires: user.lockout_expires, remaining_lockout: remainingLockoutMinutes });
                } else {
                    logger.debug('Account lockout expired.');
                    logger.debug(`User ID ${user.id} unlocked: ${user.email}`);
                    await User.unlockUserAccount(user.id);
                }
            }
        }

        // Check password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            logger.debug('Incorrect password.');

            // If account lockout is enabled
            if (config.account_lockout.enable_account_lockout) {
                // Increase failed attempts
                user.failed_attempts = (user.failed_attempts || 0) + 1;
                logger.debug(`Failed attempts: ${user.failed_attempts}`);

                // Check if user did too many failed attempts
                if (user.failed_attempts >= config.account_lockout.max_failed_attempts) {
                    user.is_locked = true;
                    if (!config.account_lockout.require_email_verification) {
                        user.lockout_expires = new Date(Date.now() + config.account_lockout.lockout_duration * 60000);
                        logger.debug(`Account locked for ${config.account_lockout.lockout_duration} minutes`);
                        await User.lockUserAccount(user.id, null, user.lockout_expires);
                    } else {
                        const unlock_token = uuidv4();
                        await User.lockUserAccount(user.id, unlock_token, null);
                        logger.debug(`Unlock token created for User ID ${user.id}: ${unlock_token}`);
                        await sendAccountLockedEmail(email, unlock_token);
                    }
                    logger.debug(`User ID ${user.id} locked: ${user.email}`);
                    if (config.account_lockout.require_email_verification) {
                        return res.status(403).json({ error: req.translate("auth.account_lockout.locked_check_email") });
                    } else {
                        return res.status(403).json({ error: req.translate("auth.account_lockout.locked_wait"), lockout_expires: user.lockout_expires });
                    }
                }
                await User.updateFailedAttempts(user.id, user.failed_attempts);
            } else {
                logger.debug('Account lockout is not enabled. Waiting 2 seconds before sending response.');
                // Wait 2 seconds before sending response to prevent brute force attacks
                await sleep(2000);
            }

            return res.status(403).json({ error: req.translate("auth.login.invalid_password") });
        }

        // Check email access
        const emailAccess = checkEmailAccess(email);
        if (!emailAccess.allowed) {
            if (emailAccess.blacklisted) {
                logger.debug(`Email ${email} is in the blacklist`);
                return res.status(403).json({ error: req.translate("user.email_blacklisted") });
            }
            if (!emailAccess.whitelisted) {
                logger.debug(`Email ${email} is not in the whitelist`);
                return res.status(403).json({ error: req.translate("user.email_not_whitelisted") });
            }
        }

        // Check if the country is in the user's whitelist
        const country_code = await getCountryFromIP(ipAddress);
        if (!country_code) {
            logger.error("Error while getting country from IP");
            return res.status(500).json({ error: req.translate("error.internal", { action: "getting country from IP" }) });
        }
        const whitelistedCoutries = user.whitelisted_countries
        if (!whitelistedCoutries.includes(country_code)) {
            if (config.connection_verification.enable_connection_verification) {
                logger.debug(`Country ${country_code} not whitelisted for User ID ${user.id}`);

                if (config.connection_verification.require_email_verification) {
                    // Check that the user has not already received a whitelist token and that the token has not expired
                    if (user.connection_verification_token && user.connection_verification_expires > new Date()) {
                        logger.debug(`User ID ${user.id} already has a whitelist token`);
                        return res.status(400).json({ error: req.translate("auth.connection_verification.country_not_whitelisted_check_email") });
                    }

                    // Generate a new whitelist token
                    const whitelist_token = uuidv4();
                    logger.debug(`Country whitelist token created for User ID ${user.id}: ${whitelist_token}`);
                    const whitelist_token_expires = new Date(Date.now() + config.connection_verification.whitelist_token_expiry * 60000);
                    logger.debug(`Country whitelist token expires at: ${whitelist_token_expires}`);

                    // Update user with whitelist token
                    await User.updateConnectionVerificationToken(user.id, country_code, whitelist_token, whitelist_token_expires);

                    // Send email with token
                    await sendWhitelistCountryEmail(email, whitelist_token, ipAddress, req.getCountryName(country_code));

                    return res.status(403).json({ error: req.translate("auth.connection_verification.country_not_whitelisted_email_sent") });
                } else {
                    const newCountries = user.whitelisted_countries;
                    newCountries.push(country_code);
                    logger.debug(`New whitelisted countries: ${newCountries.join(', ')}`);

                    // Update user with new country
                    await User.updateWhitelistedCountries(user.id, newCountries);

                    // Send warning email
                    await sendUnknownCountryEmail(email, ipAddress, req.getCountryName(country_code));
                }
            } else {
                const newCountries = user.whitelisted_countries;
                newCountries.push(country_code);
                logger.debug(`New whitelisted countries: ${newCountries.join(', ')}`);

                // Update user with new country
                await User.updateWhitelistedCountries(user.id, newCountries);
            }
        }

        // Reset failed attempts
        if (config.account_lockout.enable_account_lockout) {
            await User.resetFailedAttempts(user.id);
            logger.debug(`Failed attempts reset for User ID ${user.id}`);
        }

        // Check if user has MFA enabled
        if (config.mfa.enable_multi_factor_authentication && user.mfa_enabled) {
            logger.debug('Checking Multi-factor authentication code...');
            if (!mfa_code) {
                logger.debug('Multi-factor authentication code required.');
                return res.status(403).json({ error: req.translate("auth.mfa.code_required"), mfa: true });
            }
            const userSecret = decryptMfaSecret(user.mfa_secret);
            const { valid, alreadyUsed, backupCode, hashedBackupCode } = await checkCode(mfa_code, userSecret, user.mfa_backup_codes);

            // Check if the code is not valid
            if (!valid) {
                if (alreadyUsed) {
                    logger.debug('MFA Code already used');
                    return res.status(403).json({ error: req.translate("auth.mfa.code_already_used") });
                } else if (backupCode) {
                    logger.debug('Invalid MFA Backup code');
                    return res.status(403).json({ error: req.translate("auth.mfa.invalid_backup_code") });
                } else {
                    logger.debug('Invalid MFA code');
                    return res.status(403).json({ error: req.translate("auth.mfa.invalid_code") });
                }
            }

            // Check if the code is a backup code
            if (hashedBackupCode) {
                // Remove backup code
                const index = user.mfa_backup_codes.indexOf(hashedBackupCode);
                user.mfa_backup_codes.splice(index, 1);
                await User.updateBackupCodes(user.id, user.mfa_backup_codes);
                logger.debug(`Backup code used for User ID ${user.id}`);
            }
            logger.debug('MFA code is valid');
        }

        // Generate sessionId
        const sessionId = uuidv4();
        logger.debug(`User ID ${user.id} logged in: ${user.email}`);
        logger.debug(`Session ID ${sessionId} created for user ID ${user.id}`);

        // Generate token
        let token_expiresIn;
        if (rememberme) {
            token_expiresIn = config.session_management.long_token_expiry;
        } else {
            token_expiresIn = config.session_management.short_token_expiry
        }
        logger.debug(`Token expires in: ${token_expiresIn}`);
        const token = jwt.sign({
            userId: user.id,
            sessionId: sessionId
        }, process.env.JWT_SECRET, {
            expiresIn: token_expiresIn,
        });

        // Save session
        const token_expiresAt = new Date(Date.now() + ms(token_expiresIn)).toISOString();
        await Session.createSession(sessionId, user.id, token_expiresAt, useragent, os, browser, ipAddress, country_code);

        logger.debug(`Useragent: ${useragent}`);
        logger.debug(`Browser: ${browser}`);
        logger.debug(`OS: ${os}`);
        logger.debug(`IP Address: ${ipAddress}`);
        logger.debug(`Country: ${req.getCountryName(country_code)}`);

        // Disable old sessions
        if (config.session_management.max_sessions_per_user != 0) {
            setImmediate(async () => {
                const disabledSessions = await Session.disableOldSessions(user.id, config.session_management.max_sessions_per_user);
                for (const session of disabledSessions) {
                    logger.debug(`Session ID ${session.id} disabled from User ID ${session.user_id}`);
                }
            });
        }

        res.status(200).json({ token });
    } catch (error) {
        logger.error("Error while logging in", error);
        res.status(500).json({ error: req.translate("error.internal", { action: "logging in" }) });
    }
};

const forgotPassword = async (req, res) => {
    const { email, recaptchaResponse } = req.body;
    logger.debug(`Email: ${email}`);

    // Check parameters
    if (!email) {
        logger.debug('Missing required parameter: email');
        return res.status(400).json({ error: req.translate("error.missing_parameter", { param: "email" }) });
    }

    // Check recaptcha response
    if (config.recaptcha.enable_recaptcha_forgot_password) {
        const recaptcha = await checkRecaptchaResponse(recaptchaResponse, config.recaptcha.recaptcha_type_forgot_password);
        if (!recaptcha) {
            logger.debug('Recaptcha verification failed');
            return res.status(403).json({ error: req.translate("auth.recaptcha.failed"), recaptcha_failed: true });
        }
    }

    try {
        const user = await User.findByEmail(email);
        if (user == null) {
            logger.debug('User not found.');
            return res.status(404).json({ error: req.translate("user.not_found") });
        }

        // Check if user is verified
        if (!user.email_verified) {
            logger.debug('Email is not verified.');
            return res.status(403).json({ error: req.translate("auth.email_verification.not_verified") });
        }

        // Check if user already has reset-token
        if (user.reset_token_expires && user.reset_token_expires > new Date()) {
            logger.debug('There is already a reset-token for this user.');
            return res.status(400).json({ error: req.translate("auth.password_reset.already_resetting_password") });
        }

        // Generate an uuid reset-token with 1h expiration
        const reset_token = uuidv4();
        logger.debug(`New reset token created for ${email}: ${reset_token}`);

        // Save reset-token
        await User.updateResetToken(user.id, reset_token);

        // Send email with token
        await sendResetPasswordEmail(email, reset_token);

        logger.debug(`Reset password email sent to ${email}`);
        res.status(200).json({ message: req.translate("auth.password_reset.sent") });
    } catch (error) {
        logger.error("Error while sending email", error);
        res.status(500).json({ error: req.translate("error.internal", { action: "sending email" }) });
    }
}

const resetPassword = async (req, res) => {
    const { token: resetToken, password } = req.body;
    logger.debug(`Reset Token: ${resetToken}`);

    // Check parameters
    if (!resetToken) {
        logger.debug('Missing required parameter: token');
        return res.status(400).json({ error: req.translate("error.missing_parameter", { param: "token" }) });
    }
    if (!password) {
        logger.debug('Missing required parameter: password');
        return res.status(400).json({ error: req.translate("error.missing_parameter", { param: "password" }) });
    }
    const passwordPolicy = checkPasswordPolicy(password, req);
    if (!passwordPolicy.valid) {
        logger.debug('Password does not meet the password policy requirements');
        return res.status(400).json({ error: req.translate("auth.password_policy.invalid_password_policy"), message: passwordPolicy.message });
    }

    try {
        const user = await User.findByResetToken(resetToken);
        logger.debug(`User ID: ${user.id}`);
        if (user == null) {
            logger.debug('Invalid reset token.');
            return res.status(404).json({ error: req.translate("auth.password_reset.invalid_token") });
        }

        // Check if token is still valid
        if (user.reset_token_expires < new Date()) {
            logger.debug('Reset Token expired.');
            return res.status(400).json({ error: req.translate("auth.password_reset.token_expired") });
        }

        // Hash password
        const salt = bcrypt.genSaltSync(10);
        const hashedPassword = bcrypt.hashSync(password, salt);

        // Update user password
        await User.updatePassword(user.id, hashedPassword);
        logger.debug(`Password updated for User ID ${user.id}`);

        // Disable all sessions
        const disabledSessions = await Session.disableAllSessions(user.id);
        for (const session of disabledSessions) {
            logger.debug(`Session ID ${session.id} disabled from User ID ${session.user_id}`);
        }

        await sendPasswordChangedEmail(user.email);

        res.status(200).json({ message: req.translate("auth.password_reset.password_changed") });
    } catch (error) {
        logger.error("Error while updating password", error);
        res.status(500).json({ error: req.translate("error.internal", { action: "updating password" }) });
    }
}

const checkResetToken = async (req, res) => {
    const { token: resetToken } = req.query;
    logger.debug(`Reset token: ${resetToken}`);

    // Check parameters
    if (!resetToken) {
        logger.debug('Missing required query parameter: token');
        return res.status(400).json({ error: req.translate("error.missing_query_parameter", { param: "token" }) });
    }

    try {
        const user = await User.findByResetToken(resetToken);
        if (user == null) {
            logger.debug('Invalid reset token.');
            return res.status(404).json({ error: req.translate("auth.password_reset.invalid_token") });
        }
        logger.debug(`User ID: ${user.id}`);

        // Check if token is still valid
        if (user.reset_token_expires < new Date()) {
            logger.debug('Reset Token expired.');
            return res.status(400).json({ error: req.translate("auth.password_reset.token_expired") });
        }

        logger.debug(`Reset token is valid.`);
        res.status(200).json({
            message: req.translate("auth.password_reset.token_valid"), user: {
                id: user.id,
                username: user.username,
                email: user.email
            }
        });
    } catch (error) {
        logger.error("Error while checking token", error);
        res.status(500).json({ error: req.translate("error.internal", { action: "checking token" }) });
    }
}

const logout = async (req, res) => {
    try {
        const session = req.session;
        logger.debug(`Session ID ${session.id} found`);

        // Check if session exists
        if (!session) {
            logger.debug('Session not found');
            return res.status(404).json({ error: req.translate("auth.session.not_found") });
        }
        // Check if session is active
        if (!session.is_active) {
            logger.debug('Session expired');
            return res.status(400).json({ error: req.translate("auth.session.expired") });
        }

        await Session.disableSession(session.id);

        logger.debug(`User ID ${req.user.id} logged out: ${session.id}`);
        res.status(200).json({ message: req.translate("auth.logout.success") });
    } catch (error) {
        if (error.name === 'TokenExpiredError') {
            logger.debug('Token expired');
            return res.status(401).json({ error: req.translate("auth.token.expired") });
        } else if (error.name === 'JsonWebTokenError') {
            logger.debug('Invalid token');
            return res.status(401).json({ error: req.translate("auth.token.invalid") });
        }
        logger.error("Error while logging out", error);
        return res.status(500).json({ error: req.translate("error.internal", { action: "logging out" }) });
    }
}

const getSessions = async (req, res) => {
    try {
        let sessions = await Session.getUserSessions(req.user.id);
        logger.debug(`${sessions.length} sessions found for User ID ${req.user.id} (${sessions.filter(session => session.is_active).length} active, ${sessions.filter(session => !session.is_active).length} expired)`);
        // Sort sessions by creation date descending
        sessions = sessions.sort((a, b) => b.created_at - a.created_at);
        // Transform country_code to country
        for (const session of sessions) {
            session.country = req.getCountryName(session.country);
        }
        res.status(200).json({
            current_session: sessions.find(session => session.id === req.session.id),
            active_sessions: sessions.filter(session => session.is_active),
            expired_sessions: sessions.filter(session => !session.is_active),
            all_sessions: sessions
        });
    } catch (error) {
        logger.error("Error while getting sessions", error);
        res.status(500).json({ error: req.translate("error.internal", { action: "getting sessions" }) });
    }
}

const refreshToken = async (req, res) => {
    const { useragent, browser, os, ipAddress } = parseRequest(req);

    // Check request headers
    if (!useragent) {
        logger.error("Could not parse useragent");
        return res.status(500).json({ error: req.translate("error.internal", { action: "parsing useragent" }) });
    }
    if (!ipAddress) {
        logger.error("Could not get IP address from request");
        return res.status(500).json({ error: req.translate("error.internal", { action: "getting IP address from request" }) });
    }

    try {
        const session = await Session.getSessionById(req.session.id);
        logger.debug(`Session ID ${req.session.id}`);
        if (!session) {
            logger.debug('Session not found');
            return res.status(404).json({ error: req.translate("auth.session.not_found") });
        }
        if (!session.is_active) {
            logger.debug('Session expired');
            return res.status(400).json({ error: req.translate("auth.session.expired") });
        }

        const newSessionId = uuidv4();
        logger.debug(`New session ID ${newSessionId} created for User ID ${req.user.id}`);
        const token_expiresAt = new Date(Date.now() + ms(config.session_management.short_token_expiry)).toISOString();
        const country_code = await getCountryFromIP(ipAddress);
        if (!country_code) {
            logger.error("Error while getting country from IP");
            return res.status(500).json({ error: req.translate("error.internal", { action: "getting country from IP" }) });
        }
        await Session.updateSessionId(req.session.id, newSessionId, token_expiresAt, useragent, os, browser, ipAddress, country_code);

        logger.debug(`Useragent: ${useragent}`);
        logger.debug(`Browser: ${browser}`);
        logger.debug(`OS: ${os}`);
        logger.debug(`IP Address: ${ipAddress}`);
        logger.debug(`Country: ${req.getCountryName(country_code)}`);

        // Generate new token
        const newToken = jwt.sign({
            userId: req.user.id,
            sessionId: newSessionId
        }, process.env.JWT_SECRET, {
            expiresIn: config.session_management.short_token_expiry,
        });

        res.status(200).json({ token: newToken });
    } catch (error) {
        logger.error("Error while refreshing token", error);
        res.status(500).json({ error: req.translate("error.internal", { action: "refreshing token" }) });
    }
}

const deleteSession = async (req, res) => {
    const { sessionId } = req.params;
    const { mfa_code } = req.body;
    logger.debug(`Session ID ${sessionId}`);

    // Check if the sessionId is a valid uuid
    if (!checkUUID(sessionId)) {
        logger.debug('Invalid sessionId uuid');
        return res.status(400).json({ error: req.translate("auth.session.invalid_uuid") });
    }

    // Check that the sessionId is not the current session
    if (sessionId.toLowerCase() === req.session.id) {
        logger.debug('Cannot delete current session');
        return res.status(400).json({ error: req.translate("auth.session.current_session") });
    }

    try {
        const session = await Session.getSessionById(sessionId);
        // Check if session exists
        if (!session) {
            logger.debug('Session not found');
            return res.status(404).json({ error: req.translate("auth.session.not_found") });
        }
        // Check if session is active
        if (!session.is_active) {
            logger.debug('Session expired');
            return res.status(400).json({ error: req.translate("auth.session.expired") });
        }
        // Check if session belongs to the user
        if (session.user_id !== req.user.id) {
            logger.debug('Session does not belong to user');
            return res.status(403).json({ error: req.translate("auth.session.does_not_belong_to_user") });
        }

        // Check if user has MFA enabled
        if (config.mfa.enable_multi_factor_authentication && req.user.mfa_enabled) {
            logger.debug('Checking Multi-factor authentication code...');
            if (!mfa_code) {
                logger.debug('Multi-factor authentication code required.');
                return res.status(403).json({ error: req.translate("auth.mfa.code_required"), mfa: true });
            }
            const userSecret = decryptMfaSecret(req.user.mfa_secret);
            const { valid, alreadyUsed, backupCode, hashedBackupCode } = await checkCode(mfa_code, userSecret, req.user.mfa_backup_codes);

            // Check if the code is not valid
            if (!valid) {
                if (alreadyUsed) {
                    logger.debug('MFA Code already used');
                    return res.status(403).json({ error: req.translate("auth.mfa.code_already_used") });
                } else if (backupCode) {
                    logger.debug('Invalid MFA Backup code');
                    return res.status(403).json({ error: req.translate("auth.mfa.invalid_backup_code") });
                } else {
                    logger.debug('Invalid MFA code');
                    return res.status(403).json({ error: req.translate("auth.mfa.invalid_code") });
                }
            }

            // Check if the code is a backup code
            if (hashedBackupCode) {
                // Remove backup code
                const index = req.user.mfa_backup_codes.indexOf(hashedBackupCode);
                req.user.mfa_backup_codes.splice(index, 1);
                await User.updateBackupCodes(req.user.id, req.user.mfa_backup_codes);
                logger.debug(`Backup code used for User ID ${req.user.id}`);
            }
            logger.debug('MFA code is valid');
        }

        await Session.disableSession(sessionId);

        logger.debug(`Session ID ${sessionId} disabled from User ID ${req.user.id}`);
        res.status(200).json({ message: req.translate("auth.session.deleted") });
    } catch (error) {
        logger.error("Error while deleting session", error);
        res.status(500).json({ error: req.translate("error.internal", { action: "deleting session" }) });
    }
}

const deleteAllSessions = async (req, res) => {
    const { mfa_code } = req.body;
    try {
        const sessions = await Session.getUserSessions(req.user.id);
        logger.debug(`${sessions.length} sessions found for User ID ${req.user.id} (${sessions.filter(session => session.is_active).length} active, ${sessions.filter(session => !session.is_active).length} expired)`);
        if (sessions.length == 0) {
            logger.debug('No sessions found');
            return res.status(404).json({ error: req.translate("auth.session.no_result") });
        }

        // Check if user has MFA enabled
        if (config.mfa.enable_multi_factor_authentication && req.user.mfa_enabled) {
            logger.debug('Checking Multi-factor authentication code...');
            if (!mfa_code) {
                logger.debug('Multi-factor authentication code required.');
                return res.status(403).json({ error: req.translate("auth.mfa.code_required"), mfa: true });
            }
            const userSecret = decryptMfaSecret(req.user.mfa_secret);
            const { valid, alreadyUsed, backupCode, hashedBackupCode } = await checkCode(mfa_code, userSecret, req.user.mfa_backup_codes);

            // Check if the code is not valid
            if (!valid) {
                if (alreadyUsed) {
                    logger.debug('MFA Code already used');
                    return res.status(403).json({ error: req.translate("auth.mfa.code_already_used") });
                } else if (backupCode) {
                    logger.debug('Invalid MFA Backup code');
                    return res.status(403).json({ error: req.translate("auth.mfa.invalid_backup_code") });
                } else {
                    logger.debug('Invalid MFA code');
                    return res.status(403).json({ error: req.translate("auth.mfa.invalid_code") });
                }
            }

            // Check if the code is a backup code
            if (hashedBackupCode) {
                // Remove backup code
                const index = req.user.mfa_backup_codes.indexOf(hashedBackupCode);
                req.user.mfa_backup_codes.splice(index, 1);
                await User.updateBackupCodes(req.user.id, req.user.mfa_backup_codes);
                logger.debug(`Backup code used for User ID ${req.user.id}`);
            }
            logger.debug('MFA code is valid');
        }

        const disabledSessions = await Session.disableAllSessionsExceptCurrent(req.user.id, req.session.id);
        for (const session of disabledSessions) {
            logger.debug(`Session ID ${session.id} disabled from User ID ${session.user_id}`);
        }

        res.status(200).json({ message: req.translate("auth.session.deleted_all") });
    } catch (error) {
        logger.error("Error while deleting all sessions", error);
        res.status(500).json({ error: req.translate("error.internal", { action: "deleting all sessions" }) });
    }
}

const unlockAccount = async (req, res) => {
    const { token: unlockToken } = req.body;
    logger.debug(`Unlock Token: ${unlockToken}`);

    // Check parameters
    if (!unlockToken) {
        logger.debug('Missing required parameter: token');
        return res.status(400).json({ error: req.translate("error.missing_parameter", { param: "token" }) });
    }

    try {
        const user = await User.findByEmailVerificationToken(unlockToken);
        if (user == null) {
            logger.debug('Invalid unlock token.');
            return res.status(404).json({ error: req.translate("auth.account_lockout.invalid_unlock_token") });
        }
        logger.debug(`User ID: ${user.id}`);

        await User.unlockUserAccount(user.id);

        logger.debug(`User ID ${user.id} unlocked: ${user.email}`);
        res.status(200).json({ message: req.translate("auth.account_lockout.unlocked") });
    } catch (error) {
        logger.error("Error while unlocking account", error);
        res.status(500).json({ error: req.translate("error.internal", { action: "unlocking account" }) });
    }
}

const whitelistCountry = async (req, res) => {
    const { token: whitelistToken } = req.body;
    logger.debug(`Whitelist Token: ${whitelistToken}`);

    // Check that connection verification is enabled
    if (!config.connection_verification.enable_connection_verification) {
        logger.debug('Connection verification is not enabled');
        return res.status(400).json({ error: req.translate("auth.connection_verification.not_enabled") });
    }

    // Check parameters
    if (!whitelistToken) {
        logger.debug('Missing required parameter: token');
        return res.status(400).json({ error: req.translate("error.missing_parameter", { param: "token" }) });
    }

    // Check if the whitelistToken is a valid uuid
    if (!checkUUID(whitelistToken)) {
        logger.debug('Invalid whitelistToken uuid');
        return res.status(400).json({ error: req.translate("auth.connection_verification.invalid_uuid") });
    }

    try {
        const user = await User.findByConnectionVerificationToken(whitelistToken);
        if (user == null) {
            logger.debug('Invalid whitelist token.');
            return res.status(404).json({ error: req.translate("auth.connection_verification.invalid_token") });
        }
        logger.debug(`User ID: ${user.id}`);
        logger.debug(`Country: ${req.getCountryName(user.connection_verification_country)}`);

        // Check if token is still valid
        if (user.connection_verification_expires < new Date()) {
            logger.debug('Whitelist Token expired.');
            return res.status(400).json({ error: req.translate("auth.connection_verification.token_expired") });
        }

        const newCountries = user.whitelisted_countries;
        newCountries.push(user.connection_verification_country);
        logger.debug(`New whitelisted countries: ${newCountries.join(', ')}`);

        // Update user with new country
        await User.updateWhitelistedCountries(user.id, newCountries);
        await User.updateConnectionVerificationToken(user.id, null, null, null);

        logger.debug(`Country ${req.getCountryName(user.connection_verification_country)} whitelisted for User ID ${user.id}`);
        res.status(200).json({ message: req.translate("auth.connection_verification.country_whitelisted", { country: req.getCountryName(user.connection_verification_country) }) });
    } catch (error) {
        logger.error("Error while whitelisting country", error);
        res.status(500).json({ error: req.translate("error.internal", { action: "whitelisting country" }) });
    }
}

const SetupMfa = async (req, res) => {
    // Check if MFA is enabled
    if (!config.mfa.enable_multi_factor_authentication) {
        logger.debug('MFA System is not enabled');
        return res.status(400).json({ error: req.translate("auth.mfa.not_enabled") });
    }

    try {
        // Check if MFA is already enabled
        if (req.user.mfa_enabled) {
            logger.debug('MFA is already enabled');
            return res.status(400).json({ error: req.translate("auth.mfa.already_enabled") });
        }

        const { userSecret, otpauth, qrCodeUrl } = await generateMfaSecret(req.user.email);
        const encryptedSecret = encryptMfaSecret(userSecret);
        logger.debug(`MFA secret generated for User ID ${req.user.id}`);

        await User.setupMfa(req.user.id, encryptedSecret);

        logger.debug(`MFA setup for User ID ${req.user.id}`);
        res.status(200).json({ qrCodeUrl, otpauth });
    } catch (error) {
        logger.error("Error while enabling MFA", error);
        res.status(500).json({ error: req.translate("error.internal", { action: "enabling MFA" }) });
    }
}

const verifyMfaCode = async (req, res) => {
    // Check if MFA is enabled
    if (!config.mfa.enable_multi_factor_authentication) {
        logger.debug('MFA System is not enabled');
        return res.status(400).json({ error: req.translate("auth.mfa.not_enabled") });
    }

    const { userId, code: mfa_code } = req.body;
    logger.debug(`MFA Code: ${mfa_code}`);

    // Check parameters
    if (!userId) {
        logger.debug('Missing required parameter: userId');
        return res.status(400).json({ error: req.translate("error.missing_parameter", { param: "userId" }) });
    }
    if (!mfa_code) {
        logger.debug('Missing required parameter: code');
        return res.status(400).json({ error: req.translate("error.missing_parameter", { param: "code" }) });
    }

    try {
        const user = await User.findById(userId);
        if (!user.mfa_enabled && !user.mfa_secret) {
            logger.debug(`MFA is not enabled for User ID ${user.id}`);
            return res.status(400).json({ error: req.translate("auth.mfa.not_enabled_for_user") });
        }

        const userSecret = decryptMfaSecret(user.mfa_secret);
        const { valid, alreadyUsed, backupCode, hashedBackupCode } = await checkCode(mfa_code, userSecret, user.mfa_backup_codes);

        // Check if the code is not valid
        if (!valid) {
            if (alreadyUsed) {
                logger.debug('MFA Code already used');
                return res.status(403).json({ error: req.translate("auth.mfa.code_already_used") });
            } else if (backupCode) {
                logger.debug('Invalid MFA Backup code');
                return res.status(403).json({ error: req.translate("auth.mfa.invalid_backup_code") });
            } else {
                logger.debug('Invalid MFA code');
                return res.status(403).json({ error: req.translate("auth.mfa.invalid_code") });
            }
        }

        // Check if the code is a backup code
        if (hashedBackupCode) {
            // Remove backup code
            const index = user.mfa_backup_codes.indexOf(hashedBackupCode);
            user.mfa_backup_codes.splice(index, 1);
            await User.updateBackupCodes(user.id, user.mfa_backup_codes);
            logger.debug(`Backup code used for User ID ${user.id}`);
        }

        if (!user.mfa_enabled) {
            // Generate backup codes
            const backup_codes = generateBackupCodes(config.mfa.backup_codes);

            // Hash backup codes
            const salt = bcrypt.genSaltSync(10);
            const hashedBackupCodes = backup_codes.map(code => bcrypt.hashSync(code, salt));

            // Enable MFA and save backup codes
            await User.enableMfa(user.id, hashedBackupCodes);

            logger.debug(`MFA enabled for User ID ${user.id}`);
            return res.status(200).json({ message: req.translate("auth.mfa.enabled"), backup_codes });
        }

        logger.debug(`MFA verified for User ID ${user.id}`);
        res.status(200).json({ message: req.translate("auth.mfa.verified") });
    } catch (error) {
        logger.error("Error while verifying MFA code", error);
        res.status(500).json({ error: req.translate("error.internal", { action: "verifying MFA code" }) });
    }
}

const disableMfa = async (req, res) => {
    // Check if MFA is enabled
    if (!config.mfa.enable_multi_factor_authentication) {
        logger.debug('MFA System is not enabled');
        return res.status(400).json({ error: req.translate("auth.mfa.not_enabled") });
    }

    const { code: mfa_code } = req.body;

    // Check parameters
    if (!mfa_code) {
        logger.debug('Missing required parameter: code');
        return res.status(400).json({ error: req.translate("error.missing_parameter", { param: "code" }) });
    }

    try {
        // Check if MFA is already disabled
        if (!req.user.mfa_enabled) {
            logger.debug('MFA is not enabled');
            return res.status(400).json({ error: req.translate("auth.mfa.not_enabled_for_user") });
        }


        // Check MFA Code
        const userSecret = decryptMfaSecret(req.user.mfa_secret);
        const { valid, alreadyUsed, backupCode, hashedBackupCode } = await checkCode(mfa_code, userSecret, req.user.mfa_backup_codes);

        // Check if the code is not valid
        if (!valid) {
            if (alreadyUsed) {
                logger.debug('MFA Code already used');
                return res.status(403).json({ error: req.translate("auth.mfa.code_already_used") });
            } else if (backupCode) {
                logger.debug('Invalid MFA Backup code');
                return res.status(403).json({ error: req.translate("auth.mfa.invalid_backup_code") });
            } else {
                logger.debug('Invalid MFA code');
                return res.status(403).json({ error: req.translate("auth.mfa.invalid_code") });
            }
        }

        // Check if the code is a backup code
        if (hashedBackupCode) {
            logger.debug(`Backup code used for User ID ${req.user.id}`);
        }

        await User.disableMfa(req.user.id);

        logger.debug(`MFA disabled for User ID ${req.user.id}`);
        res.status(200).json({ message: req.translate("auth.mfa.disabled") });
    } catch (error) {
        logger.error("Error while disabling MFA", error);
        res.status(500).json({ error: req.translate("error.internal", { action: "disabling MFA" }) });
    }
}

const getWhitelistedCountries = async (req, res) => {
    // Check if connection_verification is enabled
    if (!config.connection_verification.enable_connection_verification) {
        logger.debug('Connection verification is not enabled');
        return res.status(400).json({ error: req.translate("auth.connection_verification.not_enabled") });
    }
    try {
        const user = await User.findById(req.user.id)
        const countries = user?.whitelisted_countries.map(country_code => ({ country_code: country_code, country_name: req.getCountryName(country_code) }));
        logger.debug(`${countries.length} whitelisted countries found`);
        res.status(200).json(countries);
    } catch (error) {
        logger.error("Error while getting whitelisted countries", error);
        res.status(500).json({ error: req.translate("error.internal", { action: "getting whitelisted countries" }) });
    }
}

const deleteWhitelistedCountry = async (req, res) => {
    const { country_code } = req.params;
    const { mfa_code } = req.body;

    // Check if connection_verification is enabled
    if (!config.connection_verification.enable_connection_verification) {
        logger.debug('Connection verification is not enabled');
        return res.status(400).json({ error: req.translate("auth.connection_verification.not_enabled") });
    }

    // Check parameters
    if (!country_code) {
        logger.debug('Missing required parameter: country_code');
        return res.status(400).json({ error: req.translate("error.missing_parameter", { param: "country_code" }) });
    }

    try {
        const user = await User.findById(req.user.id)
        const countries = user?.whitelisted_countries.map(country_code => ({ country_code: country_code, country_name: req.getCountryName(country_code) }));

        // Check if the country is in the user's whitelist
        if (!countries.find(country => country.country_code === country_code)) {
            return res.status(404).json({ error: req.translate("auth.connection_verification.not_whitelisted") });
        }

        // Check if user has MFA enabled
        if (config.mfa.enable_multi_factor_authentication && req.user.mfa_enabled) {
            logger.debug('Checking Multi-factor authentication code...');
            if (!mfa_code) {
                logger.debug('Multi-factor authentication code required.');
                return res.status(403).json({ error: req.translate("auth.mfa.code_required"), mfa: true });
            }
            const userSecret = decryptMfaSecret(req.user.mfa_secret);
            const { valid, alreadyUsed, backupCode, hashedBackupCode } = await checkCode(mfa_code, userSecret, req.user.mfa_backup_codes);

            // Check if the code is not valid
            if (!valid) {
                if (alreadyUsed) {
                    logger.debug('MFA Code already used');
                    return res.status(403).json({ error: req.translate("auth.mfa.code_already_used") });
                } else if (backupCode) {
                    logger.debug('Invalid MFA Backup code');
                    return res.status(403).json({ error: req.translate("auth.mfa.invalid_backup_code") });
                } else {
                    logger.debug('Invalid MFA code');
                    return res.status(403).json({ error: req.translate("auth.mfa.invalid_code") });
                }
            }

            // Check if the code is a backup code
            if (hashedBackupCode) {
                // Remove backup code
                const index = req.user.mfa_backup_codes.indexOf(hashedBackupCode);
                req.user.mfa_backup_codes.splice(index, 1);
                await User.updateBackupCodes(req.user.id, req.user.mfa_backup_codes);
                logger.debug(`Backup code used for User ID ${req.user.id}`);
            }
            logger.debug('MFA code is valid');
        }

        const newCountries = user.whitelisted_countries.filter(c => c !== country_code);
        await User.updateWhitelistedCountries(user.id, newCountries);
        logger.debug(`Country ${req.getCountryName(country_code)} deleted from whitelisted countries for User ID ${req.user.id}`);
        res.status(200).json({ message: req.translate("auth.connection_verification.country_deleted", { country: req.getCountryName(country_code) }) });
    } catch (error) {
        logger.error("Error while deleting whitelisted country", error);
        res.status(500).json({ error: req.translate("error.internal", { action: "deleting whitelisted country" }) });
    }
}

module.exports = {
    register,
    verifyEmail,
    resendVerificationEmail,
    login,
    forgotPassword,
    resetPassword,
    checkResetToken,
    logout,
    getSessions,
    refreshToken,
    deleteSession,
    deleteAllSessions,
    unlockAccount,
    whitelistCountry,
    SetupMfa,
    verifyMfaCode,
    disableMfa,
    getWhitelistedCountries,
    deleteWhitelistedCountry,
};
