const Redirect = require('../models/redirectModel');
const RedirectStats = require('../models/redirectStatsModel');

const logger = require('../logger');
const config = require('../config');

const getCountryFromIP = require('../services/getCountryFromIP');
const isUrlValid = require('../utils/isUrlValid');
const aliasIsValid = require('../utils/aliasIsValid');
const generateAlias = require('../utils/generateAlias');
const parseUseragent = require('../utils/parseRequest');

// Cache for redirects
const redirectCache = new Map();
const loadRedirectsToCache = async () => {
    logger.debug("Loading redirects into cache");
    const redirects = await Redirect.getAllRedirects();
    redirects.forEach(redirect => {
        redirectCache.set(redirect.custom_alias, redirect);
    });
    logger.debug(`${redirects.length} redirects loaded into cache`);
};


const createRedirect = async (req, res) => {
    const { alias: chosenAlias, original_url } = req.body;
    logger.debug(`Chosen alias: ${chosenAlias}`);
    logger.debug(`Original URL: ${original_url}`);

    // Check parameters
    if (!original_url) {
        logger.debug("Missing required parameter: original_url");
        return res.status(400).json({ error: req.translate("error.missing_parameter", { param: "original_url" }) });
    }
    if (original_url.length > config.redirect.max_original_url_length) {
        logger.debug("Original URL is too long");
        return res.status(400).json({ error: req.translate("reditect.url_too_long"), max_length: config.redirect.max_original_url_length });
    }

    // Check if URL is valid
    if (!isUrlValid(original_url)) {
        logger.debug("Invalid URL");
        return res.status(400).json({ error: req.translate("redirect.invalid_url") });
    }
    // Check if URL is the domain of the app
    const original_url_domain = new URL(original_url).hostname;
    const app_domain = new URL(config.app.base_url).hostname;
    if (original_url_domain === app_domain) {
        logger.debug("Unable to shorten a URL from this domain");
        return res.status(400).json({ error: req.translate("redirect.unallowed_domain") });
    }

    // Checking/Generating alias
    let alias = chosenAlias;
    if (!alias || !config.redirect.allow_custom_alias) {
        alias = generateAlias()
    }
    if (!aliasIsValid(alias, config.redirect.custom_alias_min_length, config.redirect.custom_alias_max_length)) {
        logger("Alias is invalid");
        return res.status(400).json({
            error: req.translate("redirect.invalid_alias", {
                min: config.redirect.custom_alias_min_length,
                max: config.redirect.custom_alias_max_length
            }),
            min_length: config.redirect.custom_alias_min_length,
            max_length: config.redirect.custom_alias_max_length
        });
    }
    logger.debug(`Alias: ${alias}`);

    try {
        // Check if alias is already in use
        const existingRedirect = await Redirect.getRedirectByAlias(alias);
        if (existingRedirect != null) {
            logger.debug("Alias already in use");
            return res.status(409).json({ error: req.translate("redirect.alias_already_in_use") });
        }

        // Create redirect
        const newRedirect = await Redirect.createRedirectInDB(original_url, alias, req.user.id);
        // If cache is enabled, add to cache
        if (config.redirect.use_cache) {
            redirectCache.set(newRedirect.custom_alias, newRedirect);
        }
        logger.debug(`Redirect ID ${newRedirect.id} created: ${newRedirect.custom_alias}`);

        return res.status(201).json(newRedirect);
    } catch (error) {
        logger.error("Error while creating redirect", error);
        return res.status(500).json({ error: req.translate("error.internal", { action: "creating redirect" }) });
    }
};

const getRedirects = async (req, res) => {
    const userId = req.user.id;

    try {
        const redirects = await Redirect.getRedirectsByUserId(userId);
        logger.debug(`${redirects.length} redirects found for user ID ${userId}`);
        return res.json(redirects);
    } catch (error) {
        logger.error("Error while getting redirects", error);
        return res.status(500).json({ error: req.translate("error.internal", { action: "getting redirects" }) });
    }
};

const getRedirect = async (req, res) => {
    const { identifier } = req.params;
    const { useragent, browser, os, ipAddress } = parseUseragent(req);
    logger.debug(`Identifier: ${identifier}`);

    if (!identifier) {
        logger.debug("Missing required path parameter: identifier");
        return res.status(400).json({ error: req.translate("error.missing_path_parameter", { param: "identifier" }) });
    }

    const identifierIsAlias = aliasIsValid(identifier, config.redirect.custom_alias_min_length, config.redirect.custom_alias_max_length);

    try {
        // Get redirect from cache or DB
        let redirect
        if (config.redirect.use_cache) {
            // If identifier is an alias
            if (identifierIsAlias) {
                redirect = redirectCache.get(identifier);
            } else {
                redirect = Array.from(redirectCache.values()).find(r => r.id == identifier);
            }
        } else {
            // If identifier is an alias
            if (identifierIsAlias) {
                redirect = await Redirect.getRedirectByAlias(identifier);
            } else {
                redirect = await Redirect.getRedirectById(identifier);
            }
        }

        // Check if redirect exists
        if (redirect == null) {
            logger.debug("Redirect not found");
            return res.status(404).json({ error: req.translate("redirect.not_found") });
        }

        logger.debug(`Redirect ID ${redirect.id} found: ${redirect.custom_alias}`);

        if (identifierIsAlias) {
            logger.debug(`Original URL: ${redirect.original_url}`);
        }

        res.status(200).json(redirect);

        if (!identifierIsAlias) {
            return;
        }

        // Save stats
        const redirectId = redirect.id;
        const country_code = await getCountryFromIP(ipAddress);
        if (!country_code) {
            return logger.error("Error while getting country from IP");
        }

        logger.debug(`Useragent: ${useragent}`);
        logger.debug(`Browser: ${browser}`);
        logger.debug(`OS: ${os}`);
        logger.debug(`IP Address: ${ipAddress}`);
        logger.debug(`Country: ${req.getCountryName(country_code)}`);

        await RedirectStats.createStatInDB(redirectId, useragent, browser, os, ipAddress, country_code);

        return;
    } catch (error) {
        logger.error("Error while getting redirect", error);
        return res.status(500).json({ error: req.translate("error.internal", { action: "getting redirect" }) });
    }
};

const deleteRedirect = async (req, res) => {
    const { id: redirectId } = req.params;
    logger.debug(`Redirect ID: ${redirectId}`);

    // Check parameters
    if (!redirectId) {
        logger.debug("Missing required path parameter: id");
        return res.status(400).json({ error: req.translate("error.missing_path_parameter", { param: "id" }) });
    }
    if (isNaN(redirectId)) {
        logger.debug("Invalid Redirect ID");
        return res.status(400).json({ error: req.translate("error.invalid_id") });
    }

    try {
        const redirect = await Redirect.getRedirectById(redirectId);

        if (redirect == null) {
            logger.debug("Redirect not found");
            return res.status(404).json({ error: req.translate("redirect.not_found") });
        }
        logger.debug(`Redirect ID ${redirectId} found: ${redirect.custom_alias}`);

        if (redirect.user_id !== req.user.id) {
            logger.debug("You are not allowed to delete this redirect");
            return res.status(403).json({ error: req.translate("error.delete_not_allowed") });
        }

        const deletedStats = await RedirectStats.deleteStatsOfRedirectId(redirectId);
        logger.debug(`${deletedStats.length} stats of redirect ID ${redirectId} deleted`);

        await Redirect.deleteRedirectById(redirectId);
        // If cache is enabled, delete from cache
        if (config.redirect.use_cache) {
            redirectCache.delete(redirect.custom_alias);
        }
        logger.debug(`Redirect ID ${redirectId} deleted`);

        return res.status(204).send();
    } catch (error) {
        logger.error("Error while deleting redirect", error);
        return res.status(500).json({ error: req.translate("error.internal", { action: "deleting redirect" }) });
    }
}

const editRedirect = async (req, res) => {
    const { id } = req.params;
    const { original_url } = req.body;
    logger.debug(`ID: ${id}`);
    logger.debug(`Original URL: ${original_url}`);

    // Check parameters
    if (!id) {
        logger.debug("Missing required path parameter: id");
        return res.status(400).json({ error: req.translate("error.missing_path_parameter", { param: "id" }) });
    }
    if (isNaN(id)) {
        logger.debug("Invalid ID");
        return res.status(400).json({ error: req.translate("error.invalid_id") });
    }
    if (!original_url) {
        logger.debug("Missing required parameter: original_url");
        return res.status(400).json({ error: req.translate("error.missing_parameter", { param: "original_url" }) });
    }
    if (original_url.length > config.redirect.max_original_url_length) {
        logger.debug("Original URL is too long");
        return res.status(400).json({ error: req.translate("reditect.url_too_long"), max_length: config.redirect.max_original_url_length });
    }

    // Check if URL is valid
    if (!isUrlValid(original_url)) {
        logger.debug("Invalid URL");
        return res.status(400).json({ error: req.translate("redirect.invalid_url") });
    }
    // Check if URL is the domain of the app
    const original_url_domain = new URL(original_url).hostname;
    const app_domain = new URL(config.app.base_url).hostname;
    if (original_url_domain === app_domain) {
        logger.debug("You cannot shorten a URL from this domain");
        return res.status(400).json({ error: req.translate("redirect.unallowed_domain") });
    }

    try {
        const redirect = await Redirect.getRedirectById(id);

        if (redirect == null) {
            return res.status(404).json({ error: req.translate("redirect.not_found") });
        }
        logger.debug(`Redirect ID ${id} found: ${redirect.custom_alias}`);

        if (redirect.user_id !== req.user.id) {
            logger.debug("You are not allowed to edit this redirect");
            return res.status(403).json({ error: req.translate("error.edit_not_allowed") });
        }

        const editedRedirect = await Redirect.editRedirectById(id, original_url);
        // If cache is enabled, update cache
        if (config.redirect.use_cache) {
            redirectCache.set(editedRedirect.custom_alias, editedRedirect);
        }
        logger.debug(`Redirect ID ${id} edited: ${editedRedirect.custom_alias}`);
        return res.status(200).json(editedRedirect);
    } catch (error) {
        logger.error("Error while editing redirect", error);
        return res.status(500).json({ error: req.translate("error.internal", { action: "editing redirect" }) });
    }
}

loadRedirectsToCache();

module.exports = {
    createRedirect,
    getRedirects,
    getRedirect,
    deleteRedirect,
    editRedirect
};
