const RedirectStats = require('../models/redirectStatsModel');
const Redirect = require('../models/redirectModel');

const logger = require('../logger');

const getRedirectStats = async (req, res) => {
    const redirectId = req.params.id;
    logger.debug(`Redirect ID ${redirectId}`);

    if (!redirectId) {
        logger.error('Missing required path parameter: id');
        return res.status(400).json({ error: req.translate("error.missing_path_parameter", { param: "id" }) });
    }
    if (isNaN(redirectId)) {
        logger.error('Invalid path parameter: id, must be a number');
        return res.status(400).json({ error: req.translate("error.invalid_path_parameter", { param: "id", reason: "must be a number" }) });
    }

    try {
        const redirect = await Redirect.getRedirectById(redirectId);

        // Check if the redirect exists
        if (redirect == null) {
            return res.status(404).json({ error: req.translate("redirect.not_found") });
        }
        logger.debug(`Redirect ID ${redirectId} found: ${redirect.alias}`);

        // Check if the user is allowed to see the stats
        if (redirect.user_id !== req.user.id) {
            logger.error('User not allowed to see the stats of this redirect');
            return res.status(403).json({ error: req.translate("redirect.stats_not_allowed") });
        }

        const redirectStats = await RedirectStats.getRedirectStatsByRedirectId(redirectId);
        logger.debug(`${redirectStats.length} stats found for redirect ID ${redirectId}`);

        // Transform country_code to country name
        redirectStats.forEach(stat => {
            stat.country = req.getCountryName(stat.country);
        });

        return res.status(200).json(redirectStats);
    } catch (error) {
        logger.error("Error while getting redirect stats", error);
        return res.status(500).json({ error: req.translate("error.internal", { action: "getting redirect stats" }) });
    }
}

const getStats = async (req, res) => {
    try {
        const stats = await RedirectStats.getAllStats(req.user.id);
        logger.debug(`${stats.length} stats found for user ID ${req.user.id}`);

        // Transform country_code to country name
        stats.forEach(stat => {
            stat.country = req.getCountryName(stat.country);
        });

        return res.status(200).json(stats);
    } catch (error) {
        logger.error("Error while getting stats", error);
        return res.status(500).json({ error: req.translate("error.internal", { action: "getting stats" }) });
    }
}

module.exports = {
    getRedirectStats,
    getStats
};
