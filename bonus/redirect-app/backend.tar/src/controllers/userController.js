const bcrypt = require('bcryptjs');

const logger = require('../logger');
const config = require('../config');

const User = require('../models/userModel');
const Session = require('../models/sessionModel');
const Redirect = require('../models/redirectModel');
const RedirectStats = require('../models/redirectStatsModel');

const emailIsValid = require('../utils/emailIsValid');
const checkPasswordPolicy = require('../utils/checkPasswordPolicy');
const { checkCode, decryptMfaSecret } = require('../utils/mfa');

const getMe = async (req, res) => {
    logger.debug(`Getting user with ID ${req.user.id}`);

    const adminEmails = config.admin.admin_emails;
    const userIsAdmin = adminEmails.includes(req.user.email);

    res.status(200).json({
        id: req.user.id,
        username: req.user.username,
        email: req.user.email,
        created_at: req.user.created_at,
        email_verified: req.user.email_verified,
        whitelisted_countries: req.user.whitelisted_countries.map(country_code => req.getCountryName(country_code)),
        ...(config.mfa.enable_multi_factor_authentication ? { mfa_enabled: req.user.mfa_enabled } : {}),
        is_admin: userIsAdmin
    });
};

const getUser = async (req, res) => {
    const { identifier } = req.params;
    logger.debug(`Getting user with identifier ${identifier}`);

    if (!identifier) {
        logger.debug('Missing required path parameter: identifier');
        return res.status(400).json({ error: req.translate("error.missing_path_parameter", { param: "identifier" }) });
    }

    try {
        let user
        if (isNaN(identifier)) {
            user = await User.findByUsername(identifier);
        } else {
            user = await User.findById(identifier);
        }

        if (user == null) {
            return res.status(404).json({ error: req.translate("error.not_found", { element: "User" }) });
        }
        logger.debug(`User found: ID ${user.id}`);

        const adminEmails = config.admin.admin_emails;
        const userIsAdmin = adminEmails.includes(user.email);

        return res.status(200).json({
            id: user.id,
            username: user.username,
            email: user.email,
            created_at: user.created_at,
            is_admin: userIsAdmin,
        });
    } catch (error) {
        logger.error("Error while getting user", error);
        return res.status(500).json({ error: req.translate("error.internal", { action: "getting user" }) });
    }
};

const updateMe = async (req, res) => {
    const { username, email, password, oldPassword, mfa_code } = req.body;
    logger.debug(`Updating user with ID ${req.user.id}`);
    logger.debug(`Username: ${username}`);
    logger.debug(`Email: ${email}`);

    if (!username && !email && !password) {
        logger.debug('Missing at least one optional parameter: username, email, password');
        return res.status(400).json({ error: req.translate("error.missing_parameter_at_least_one", { params: "username, email, password" }) });
    }

    if (email) {
        if (!emailIsValid(email)) {
            logger.debug('Invalid email');
            return res.status(400).json({ error: req.translate("user.invalid_email") });
        }
    }

    if (password && !oldPassword) {
        logger.debug('Missing required parameter: oldPassword');
        return res.status(400).json({ error: req.translate("error.missing_parameter", { param: "oldPassword" }) });
    }

    let hashedPassword;
    // If password specified, check if old password is correct and if new password meets the password policy requirements
    if (password) {
        // Check if old password is correct
        const oldPasswordCorrect = bcrypt.compareSync(oldPassword, req.user.password);
        console.log(oldPasswordCorrect);

        // Check and hash new password
        const passwordPolicy = checkPasswordPolicy(password, req);
        if (!passwordPolicy.valid) {
            logger.debug('Password does not meet the password policy requirements');
            return res.status(400).json({ error: req.translate("auth.password_policy.invalid_password_policy"), message: passwordPolicy.message });
        }

        const salt = bcrypt.genSaltSync(10);
        hashedPassword = bcrypt.hashSync(password, salt);
    }

    try {
        // If username specified, check if it's already in use
        if (username) {
            const usernameExists = await User.findByUsername(username) != null;
            if (usernameExists && username !== req.user.username) {
                logger.debug(`Username ${username} is already in use`);
                return res.status(409).json({ error: req.translate("user.username_already_in_use") });
            }
        }
        // If email specified, check if it's already in use
        if (email) {
            const userExists = await User.findByEmail(email) != null;
            if (userExists) {
                logger.debug(`Email ${email} is already in use`);
                return res.status(409).json({ error: req.translate("user.email_already_in_use") });
            }
        }

        // If changing email or password, check if user has MFA enabled
        if (email || password && config.mfa.enable_multi_factor_authentication && req.user.mfa_enabled) {
            logger.debug('Checking Multi-factor authentication code...');
            if (!mfa_code) {
                logger.debug('Multi-factor authentication code required.');
                return res.status(403).json({ error: req.translate("auth.mfa.code_required"), mfa: true });
            }
            const userSecret = decryptMfaSecret(req.user.mfa_secret);
            const { valid, alreadyUsed, backupCode, hashedBackupCode } = await checkCode(mfa_code, userSecret, req.user.mfa_backup_codes);

            // Check if the code is not valid
            if (!valid) {
                if (alreadyUsed) {
                    logger.debug('MFA Code already used');
                    return res.status(403).json({ error: req.translate("auth.mfa.code_already_used") });
                } else if (backupCode) {
                    logger.debug('Invalid MFA Backup code');
                    return res.status(403).json({ error: req.translate("auth.mfa.invalid_backup_code") });
                } else {
                    logger.debug('Invalid MFA code');
                    return res.status(403).json({ error: req.translate("auth.mfa.invalid_code") });
                }
            }

            // Check if the code is a backup code
            if (hashedBackupCode) {
                // Remove backup code
                const index = req.user.mfa_backup_codes.indexOf(hashedBackupCode);
                req.user.mfa_backup_codes.splice(index, 1);
                await User.updateBackupCodes(req.user.id, req.user.mfa_backup_codes);
                logger.debug(`Backup code used for User ID ${req.user.id}`);
            }
            logger.debug('MFA code is valid');

            // If changing email, disable MFA
            if (email && req.user.mfa_enabled) {
                await User.disableMfa(req.user.id);
                logger.debug(`MFA disabled for User ID ${req.user.id}`);
            }
        }

        // Update user
        const updatedUser = await User.updateUser(req.user.id, username, email, hashedPassword);
        logger.debug(`User ID ${updatedUser.id} updated`);

        // If password changed, disable all sessions except current
        if (password) {
            const disabledSessions = await Session.disableAllSessionsExceptCurrent(updatedUser.id, req.session.id);
            for (const session of disabledSessions) {
                logger.debug(`Session ID ${session.id} disabled from User ID ${session.user_id}`);
            }
        }

        return res.status(200).json({
            id: updatedUser.id,
            username: updatedUser.username,
            email: updatedUser.email,
            created_at: updatedUser.created_at
        });
    } catch (error) {
        logger.error("Error while updating user", error);
        return res.status(500).json({ error: req.translate("error.internal", { action: "updating user" }) });
    }
};

const deleteMe = async (req, res) => {
    try {
        // Check if user has MFA enabled
        if (config.mfa.enable_multi_factor_authentication && req.user.mfa_enabled) {
            logger.debug('Checking Multi-factor authentication code...');
            if (!mfa_code) {
                logger.debug('Multi-factor authentication code required.');
                return res.status(403).json({ error: req.translate("auth.mfa.code_required"), mfa: true });
            }
            const userSecret = decryptMfaSecret(req.user.mfa_secret);
            const { valid, alreadyUsed, backupCode, hashedBackupCode } = await checkCode(mfa_code, userSecret, req.user.mfa_backup_codes);

            // Check if the code is not valid
            if (!valid) {
                if (alreadyUsed) {
                    logger.debug('MFA Code already used');
                    return res.status(403).json({ error: req.translate("auth.mfa.code_already_used") });
                } else if (backupCode) {
                    logger.debug('Invalid MFA Backup code');
                    return res.status(403).json({ error: req.translate("auth.mfa.invalid_backup_code") });
                } else {
                    logger.debug('Invalid MFA code');
                    return res.status(403).json({ error: req.translate("auth.mfa.invalid_code") });
                }
            }

            // Check if the code is a backup code
            if (hashedBackupCode) {
                // Remove backup code
                const index = req.user.mfa_backup_codes.indexOf(hashedBackupCode);
                req.user.mfa_backup_codes.splice(index, 1);
                await User.updateBackupCodes(req.user.id, req.user.mfa_backup_codes);
                logger.debug(`Backup code used for User ID ${req.user.id}`);
            }
            logger.debug('MFA code is valid');
        }

        const userRedirects = await Redirect.getRedirectsByUserId(req.user.id);
        logger.debug(`${userRedirects.length} redirects found for user ID ${req.user.id}`);
        for (const redirect of userRedirects) {
            const deletedStatus = await RedirectStats.deleteStatsOfRedirectId(redirect.id);
            logger.debug(`${deletedStatus.deletedCount} stats deleted for redirect ID ${redirect.id}`);
            await Redirect.deleteRedirectById(redirect.id);
            logger.debug(`Redirect ID ${redirect.id} deleted`);
        }
        await User.deleteUser(req.user.id);
        logger.debug(`User ID ${req.user.id} deleted`);
        return res.status(204).send();
    } catch (error) {
        logger.error("Error while deleting user", error);
        return res.status(500).json({ error: req.translate("error.internal", { action: "deleting user" }) });
    }
};

module.exports = {
    getMe,
    getUser,
    updateMe,
    deleteMe
};