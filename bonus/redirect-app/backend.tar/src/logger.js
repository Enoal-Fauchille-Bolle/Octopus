const fs = require('fs');
const path = require('path');
const config = require('./config');

const consoleStyles = require('./consoleStyles');

const logDir = config.logging.log_dir;

const logLevels = {
    debug: 0,
    info: 1,
    warn: 2,
    error: 3,
}

// Get log level from config
const logLevel = logLevels[config.logging.log_level];

// Get max size of log files from config
const maxSize = config.logging.max_size * 1024 * 1024;

if (logLevel === undefined) {
    throw new Error(`Invalid log level: ${config.logging.log_level}`);
}

const getFormattedTimestamp = () => {
    const now = new Date();
    const milliseconds = String(now.getMilliseconds()).padStart(3, '0');
    return `${String(now.getDate()).padStart(2, '0')}-${String(now.getMonth() + 1).padStart(2, '0')}-${now.getFullYear()} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}.${milliseconds}`;
};

const colorizeMessage = (message) => {
    return message
        .replace(/\b(?<![a-zA-Z0-9./-])(\d+)(?![a-zA-Z0-9./-])\b/g, (match) => consoleStyles.color.green(match)) // Numbers: green
        .replace(/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/g, (match) => consoleStyles.color.magenta(match)) // Emails: magenta
        .replace(/(GET|POST|PUT|DELETE|PATCH|OPTIONS|HEAD) (\S+)/g, (match, method, path) =>
            `${consoleStyles.color.yellow(method)} ${consoleStyles.color.cyan(path)}`) // Endpoint: yellow method, cyan path
        .replace(/\b([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-4[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})\b/g, (match) => consoleStyles.color.yellow(match)) // UUID: yellow
        .replace(/\b(?:\d{1,3}\.){3}\d{1,3}\b/g, (match) => consoleStyles.color.blue(match)) // IP Address: blue
        .replace(/\b\d+(\.\d+)?(s|ms)\b/g, (match) => consoleStyles.color.red(match)) // Seconds: red
        .replace(/https?:\/\/[^\s]+/g, (match) => consoleStyles.color.cyan(match)) // URLs: cyan
        .replace(/(true|false)/g, (match) => consoleStyles.color.cyan(match)) // Booleans: cyan
        .replace(/(\d+\.\d+)%/g, (match) => consoleStyles.color.yellow(match)) // Percentages: yellow

};

const colorizeLogLevel = (level) => {
    switch (level) {
        case 'debug': return consoleStyles.color.magenta('[DEBUG]'); // Magenta pour DEBUG
        case 'info': return consoleStyles.color.green('[INFO]');  // Vert pour INFO
        case 'warn': return consoleStyles.color.yellow('[WARN]');  // Jaune pour WARN
        case 'error': return consoleStyles.color.red('[ERROR]'); // Rouge pour ERROR
        default: return `[${level.toUpperCase()}]`;
    }
};

const getLogFilesSize = (level, currentLogContent, allLogContent, logContents) => {
    let totalSize = Buffer.byteLength(currentLogContent) + Buffer.byteLength(allLogContent);
    for (const [logLevel, content] of Object.entries(logContents)) {
        if (logLevel !== level) {
            totalSize += Buffer.byteLength(content);
        }
    }
    return totalSize;
};

const truncateLogFile = (currentLogContent) => {
    const lines = currentLogContent.split('\n');
    if (lines.length > 1) {
        lines.shift();
    }
    return lines.join('\n');
};

const removeColorCodes = (message) => {
    return message.replace(/\x1b\[[0-9;]*m/g, ''); // Supprime tous les codes de couleur ANSI
};

const logMessage = (level, message, error) => {
    if (!Object.keys(logLevels).includes(level.toLowerCase())) {
        throw new Error(`Invalid log level: ${level}`);
    }
    if (!message) message = "";
    if (typeof message !== 'string') {
        throw new Error(`Invalid log message: ${message}`);
    }
    const timestamp = getFormattedTimestamp();
    if (error && (error.stack || error.message)) {
        message += `: ${error.stack || error.message || error}`;
    }
    const logEntry = `${timestamp} [${level.toUpperCase()}]: ${message}\n`;

    if (config.logging.enable_logging) {
        const logFilePath = path.join(logDir, `${level}.log`);
        const allLogFilePath = path.join(logDir, 'all.log');

        if (
            (level == 'debug' && logLevel <= logLevels.debug) ||
            (level == 'info' && logLevel <= logLevels.info) ||
            (level == 'warn' && logLevel <= logLevels.warn) ||
            (level == 'error' && logLevel <= logLevels.error)
        ) {
            try {
                // Log to console
                if (config.logging.colors)
                    console.log(`${consoleStyles.color.gray(timestamp)} ${colorizeLogLevel(level.toLowerCase())}: ${colorizeMessage(message)}`);
                else
                    console.log(logEntry.slice(0, -1));

                // Read current log file content and all log file content
                let currentLogContent = fs.existsSync(logFilePath) ? fs.readFileSync(logFilePath, 'utf-8') : '';
                let allLogContent = fs.existsSync(allLogFilePath) ? fs.readFileSync(allLogFilePath, 'utf-8') : '';

                // Append log entry to current log file and all log file
                currentLogContent += logEntry;
                allLogContent += logEntry;

                // Read debug, info, warn, and error log file content
                const debugLogContent = fs.existsSync(path.join(logDir, 'debug.log')) ? fs.readFileSync(path.join(logDir, 'debug.log'), 'utf-8') : '';
                const infoLogContent = fs.existsSync(path.join(logDir, 'info.log')) ? fs.readFileSync(path.join(logDir, 'info.log'), 'utf-8') : '';
                const warnLogContent = fs.existsSync(path.join(logDir, 'warn.log')) ? fs.readFileSync(path.join(logDir, 'warn.log'), 'utf-8') : '';
                const errorLogContent = fs.existsSync(path.join(logDir, 'error.log')) ? fs.readFileSync(path.join(logDir, 'error.log'), 'utf-8') : '';

                // Get total size of all log files
                let totalSize = getLogFilesSize(level, currentLogContent, allLogContent, { debug: debugLogContent, info: infoLogContent, warn: warnLogContent, error: errorLogContent })


                // Truncate log files if total size exceeds max size
                while (totalSize > maxSize) {
                    currentLogContent = truncateLogFile(currentLogContent);
                    allLogContent = truncateLogFile(allLogContent);

                    totalSize = getLogFilesSize(level, currentLogContent, allLogContent, { debug: debugLogContent, info: infoLogContent, warn: warnLogContent, error: errorLogContent })
                }

                // Write log entries to log files
                fs.writeFileSync(logFilePath, removeColorCodes(currentLogContent));
                fs.writeFileSync(allLogFilePath, removeColorCodes(allLogContent));
            } catch (error) {
                config.logging.enable_logging = false;
                logMessage('error', `Error writing to log file`, error);
                logMessage('error', `Disabling file logging`);
            }
        } else {
            return;
        }
    } else {
        if (
            (level == 'debug' && logLevel <= logLevels.debug) ||
            (level == 'info' && logLevel <= logLevels.info) ||
            (level == 'warn' && logLevel <= logLevels.warn) ||
            (level == 'error' && logLevel <= logLevels.error)
        ) {
            // Log to console
            if (config.logging.colors)
                console.log(`${consoleStyles.color.gray(timestamp)} ${colorizeLogLevel(level.toLowerCase())}: ${colorizeMessage(message)}`);
            else
                console.log(logEntry.slice(0, -1));
        } else {
            return;
        }
    }
};

// Create log directory if it doesn't exist
try {
    if (!fs.existsSync(logDir) && config.logging.enable_logging) {
        fs.mkdirSync(logDir);
    }
} catch (error) {
    config.logging.enable_logging = false;
    logMessage('error', `Error creating log directory`, error);
    logMessage('error', `Disabling file logging`);
}

module.exports = {
    debug: (message, error) => logMessage('debug', message, error),
    info: (message, error) => logMessage('info', message, error),
    warn: (message, error) => logMessage('warn', message, error),
    error: (message, error) => logMessage('error', message, error),
    colors: consoleStyles.color,
    background: consoleStyles.background,
    textformatting: consoleStyles.textformatting,
};
