const logger = require('../logger');
const config = require('../config');

const adminMiddleware = async (req, res, next) => {
    logger.debug(`Incoming admin request...`);

    // Get user from request
    const user = req.user;

    // Get admin emails from config
    const adminEmails = config.admin.admin_emails;

    // Check if user is an admin
    if (!adminEmails.includes(user.email)) {
        logger.debug(`User ${user.email} is not an admin`);
        return res.status(403).json({ error: req.translate("admin.unauthorized") });
    }

    logger.debug(`User ID ${user.id}: ${user.email} is an admin`);

    next();
};

module.exports = adminMiddleware;
