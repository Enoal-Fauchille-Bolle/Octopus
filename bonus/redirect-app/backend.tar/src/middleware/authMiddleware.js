const jwt = require('jsonwebtoken');
const User = require('../models/userModel');
const Session = require('../models/sessionModel');

const logger = require('../logger');

const checkEmailAccess = require('../utils/checkEmailAccess');

const authMiddleware = async (req, res, next) => {
    const token = req.header('Authorization')?.replace('Bearer ', '');

    logger.debug(`Incoming auth request...`);

    if (!token) {
        logger.debug('No token provided');
        return res.status(401).json({ error: req.translate("auth.token.missing") });
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = await User.findById(decoded.userId);

        // Check if user exists
        if (!req.user) {
            logger.debug('Invalid token. User not found');
            return res.status(401).json({ error: req.translate("auth.token.invalid") });
        }

        // Check if session is valid
        req.session = await Session.getSessionById(decoded.sessionId);
        if (!req.session) {
            logger.debug('Invalid token. Session not found');
            return res.status(401).json({ error: req.translate("auth.token.invalid_session") });
        }
        if (!req.session.is_active) {
            logger.debug('Invalid token. Session expired');
            return res.status(401).json({ error: req.translate("auth.token.invalid_session_expired") });
        }

        // Check access control
        const emailAccess = checkEmailAccess(req.user.email);
        if (!emailAccess.allowed) {
            if (emailAccess.blacklisted) {
                logger.debug(`Email ${req.user.email} is in the blacklist`);
                return res.status(403).json({ error: req.translate("user.email_blacklisted") });
            }
            if (!emailAccess.whitelisted) {
                logger.debug(`Email ${req.user.email} is not in the whitelist`);
                return res.status(403).json({ error: req.translate("user.email_not_whitelisted") });
            }
        }

        // If user is not verified, check if the endpoint is allowed
        if (!req.user.email_verified) {
            // Check if the endpoint is allowed
            const allowedEndpoints = [
                { method: 'GET', path: /^\/auth\/verify-email/ },
                { method: 'POST', path: /^\/auth\/resend-verification-email/ },
                { method: 'GET', path: /^\/auth\/me/ },
                { method: 'GET', path: /^\/stats/ },
                { method: 'GET', path: /^\/redirects/ },
                { method: 'DELETE', path: /^\/auth\/me/ },
                { method: 'POST', path: /^\/logout/ },
            ];

            const currentEndpoint = allowedEndpoints.find(endpoint =>
                endpoint.method === req.method && endpoint.path.test(req.path)
            );

            if (!currentEndpoint) {
                logger.debug('Access forbidden: User not verified');
                return res.status(403).json({ error: req.translate("auth.email_verification.not_verified") });
            }
        }

        logger.debug(`User ID ${req.user.id} authenticated: ${req.user.email} (${req.session.id})`);

        next();

        // Disable expired sessions
        Session.disableExpiredSessions();

        // Update last activity
        Session.updateLastActivity(decoded.sessionId);
    } catch (error) {
        if (error.name === 'TokenExpiredError') {
            logger.debug('Token expired');
            return res.status(401).json({ error: req.translate("auth.token.expired") });
        } else if (error.name === 'JsonWebTokenError') {
            logger.debug('Invalid token');
            return res.status(401).json({ error: req.translate("auth.token.invalid") });
        }
        logger.error("Error while authenticating", error);
        return res.status(500).json({ error: req.translate("error.internal", { action: "authenticating" }) });
    }
};

module.exports = authMiddleware;
