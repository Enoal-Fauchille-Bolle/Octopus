const logger = require('../logger');
const config = require('../config');

function domainCheck(req, res, next) {
    const allowed_domains = config.general_security.allowed_domains;
    const origin = req.hostname;
    if (!allowed_domains.includes(origin)) {
        logger.debug(`Domain ${origin} is not allowed`);
        return res.status(403).json({ message: "Domain not allowed" });
    }
    next();
}

module.exports = domainCheck;
