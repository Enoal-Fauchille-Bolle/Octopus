const logger = require('../logger');
const checkIPAccess = require('../utils/checkIPAccess');

function ipAccessCheck(req, res, next) {
    const ipAccess = checkIPAccess(req.ip);
    if (!ipAccess.allowed) {
        if (ipAccess.blacklisted) {
            logger.debug(`IP ${req.ip} is in the blacklist`);
            return res.status(403).json({ error: req.translate("auth.ip_access_check.blacklisted") });
        }
        if (!ipAccess.whitelisted) {
            logger.debug(`IP ${req.ip} is not in the whitelist`);
            return res.status(403).json({ error: req.translate("auth.ip_access_check.not_whitelisted") });
        }
    }
    next();
}

module.exports = ipAccessCheck;
