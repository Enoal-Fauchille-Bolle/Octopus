const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');
const logger = require('../logger');

// Load all translations from the `locales` directory
const localesDir = path.join(__dirname, '../locales');
const countriesDir = path.join(localesDir, 'countries');

const translations = {};
const countriesTranslations = {};

fs.readdirSync(localesDir).forEach(file => {
    if (!file.endsWith('.yaml')) {
        return;
    }
    const lang = path.basename(file, path.extname(file));
    translations[lang] = yaml.load(fs.readFileSync(path.join(localesDir, file), 'utf8'));
});

fs.readdirSync(countriesDir).forEach(file => {
    if (!file.endsWith('.yaml')) {
        return;
    }
    const lang = path.basename(file, path.extname(file));
    countriesTranslations[lang] = yaml.load(fs.readFileSync(path.join(countriesDir, file), 'utf8'));
});

function getLanguageFromHeaders(headers) {
    const acceptLanguageKey = Object.keys(headers).find(key => key.toLowerCase() === 'accept-language');
    if (!acceptLanguageKey) {
        return null; // Retourne null si l'en-tête Accept-Language est manquant
    }

    const acceptLanguage = headers[acceptLanguageKey];
    const languages = acceptLanguage
        .split(',')
        .map(lang => lang.split(';')[0].trim().split('-')[0]); // Prend seulement la partie principale avant le tiret

    return languages[0] || null; // Retourne la première langue principale ou null si aucune langue n'est spécifiée
}

function getNestedValue(obj, key) {
    return key.split('.').reduce((o, i) => o?.[i], obj);
}

function languageMiddleware(req, res, next) {
    const language = getLanguageFromHeaders(req.headers) || 'en';

    req.translate = function (key, variables = {}) {
        let message = getNestedValue(translations[language], key) || getNestedValue(translations['en'], key) || key;
        return message.replace(/{{\s*(\w+)\s*}}/g, (_, varName) => variables[varName] || '');
    }

    req.getCountryName = function (countryCode) {
        countryCode = countryCode.toUpperCase();
        return getNestedValue(countriesTranslations[language], countryCode) || getNestedValue(countriesTranslations['en'], countryCode) || countryCode;
    }

    req.language = language;

    logger.debug(`Language: ${logger.colors.blue(req.getCountryName(language))}`);

    next();
}

module.exports = languageMiddleware;
