const logger = require('../logger');
const config = require('../config');

function methodCheck(req, res, next) {
    const allowed_methods = config.general_security.allowed_http_methods;
    const method = req.method;
    if (!allowed_methods.includes(method)) {
        logger.debug(`Method ${method} is not allowed`);
        return res.status(405).json({ message: "Method Not Allowed" });
    }
    next();
}

module.exports = methodCheck;
