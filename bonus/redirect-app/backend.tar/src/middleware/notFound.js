const logger = require('../logger');

function notFound(req, res, next) {
    logger.debug(`Route not found: ${req.method} ${req.url}`);
    res.status(404).json({ error: req.translate("error.not_found", { element: "Route" }) });
}

module.exports = notFound;
