const jwt = require('jsonwebtoken');
const User = require('../models/userModel');
const config = require('../config.js');
const logger = require('../logger.js');

const UserRateLimit = new Map();
const IPRateLimit = new Map();

const modes = ["ip", "both"];

const getUser = async (req) => {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) {
        return null;
    }
    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        return await User.findById(decoded.userId);
    } catch (error) {
        return null;
    }
}

const rateLimit = async (req, res, next) => {
    maxRequests = config.rate_limiting.max_requests;
    windowMs = config.rate_limiting.time_window * 1000;
    let mode = config.rate_limiting.mode;

    // Check if the mode is valid
    if (!modes.includes(mode)) {
        logger.warn(`Invalid rate limiting mode: ${mode}. Defaulting to 'both'`);
        mode = "both";
    }

    // If the mode is 'both', get the mode based on the request
    req.user = await getUser(req);
    if (mode === "both") {
        mode = req.user ? "user" : "ip";
    }

    // Get the key based on the mode
    let key;
    if (mode === "ip" || !req.user) {
        mode = "ip";
        key = req.ip;
    } else {
        key = req.user.id;
    }

    // Get the rate limit map based on the mode
    let rateLimitMap;
    if (mode === "ip") {
        rateLimitMap = IPRateLimit;
    } else {
        rateLimitMap = UserRateLimit;
    }

    const currentTime = Date.now();

    // If the IP address is not in the Map
    if (!rateLimitMap.has(key)) {
        // Add the IP address to the Map
        rateLimitMap.set(key, { count: 1, startTime: currentTime });
    } else {
        const data = rateLimitMap.get(key);

        // Check if the window has passed
        if (currentTime > data.startTime + windowMs) {
            // Reset the count and start time
            data.count = 1;
            data.startTime = currentTime;
        } else {
            // Increment the count
            data.count += 1;
            if (data.count > maxRequests) {
                const resetTime = (data.startTime + windowMs - currentTime) / 1000;
                res.setHeader('Retry-After', Math.ceil(resetTime));
                if (mode === "ip") {
                    logger.debug(`Rate limit exceeded for IP ${key}. Retry after ${resetTime}s`);
                } else {
                    logger.debug(`Rate limit exceeded for User ${key}. Retry after ${resetTime}s`);
                }
                return res.status(429).json({ message: req.translate("error.ratelimited") });
            }
        }
        rateLimitMap.set(key, data);
    }

    if (mode === "ip") {
        logger.debug(`Rate limit remaining for IP ${key}: ${maxRequests - rateLimitMap.get(key).count}`);
    } else {
        logger.debug(`Rate limit remaining for User ${key}: ${maxRequests - rateLimitMap.get(key).count}`);
    }

    // Clear the IP address from the Map after the window has passed
    setTimeout(() => {
        if (rateLimitMap.has(key)) {
            if (mode === "ip") {
                logger.debug(`Rate limit window passed for IP ${key}, now ${maxRequests}`);
            } else {
                logger.debug(`Rate limit window passed for User ${key}, now ${maxRequests}`);
            }
        }
        rateLimitMap.delete(key);
    }, windowMs);

    next();
};

module.exports = rateLimit;
