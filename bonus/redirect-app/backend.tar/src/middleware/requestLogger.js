const logger = require('../logger');

const requestLogger = (req, res, next) => {
    logger.debug();
    logger.debug(`${logger.textformatting.bold("Incoming Request:")} ${req.method} ${req._parsedUrl.pathname}`);
    logger.debug(`Request Query: ${JSON.stringify(req.query)}`);
    // logger.debug(`Request Body: ${JSON.stringify(req.body)}`);

    res.once("finish", () => {
        logger.debug(`${logger.textformatting.bold("Outgoing Response:")} ${res.statusCode} (${res.statusMessage})`);
    });

    next();
};

module.exports = requestLogger;
