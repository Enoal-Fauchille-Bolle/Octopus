const config = require('../config');
const logger = require('../logger');

const responseTimeLogger = (req, res, next) => {
    const startTime = Date.now();

    res.once("finish", () => {
        const duration = Date.now() - startTime;

        if (duration > config.logging.max_request_response_time) {
            logger.warn(`Request took ${duration}ms to process`);
        } else {
            logger.debug(`Request took ${duration}ms to process`);
        }
    });

    next();
};

module.exports = responseTimeLogger;
