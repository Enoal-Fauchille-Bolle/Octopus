const logger = require('../logger');

function useragentCheck(req, res, next) {
    const useragent = req.headers['user-agent'];
    if (!useragent) {
        logger.debug("User-Agent is missing");
        return res.status(400).json({ message: "User-Agent is missing" });
    }
    next();
}

module.exports = useragentCheck;
