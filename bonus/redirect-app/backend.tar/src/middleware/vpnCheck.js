const logger = require('../logger.js');
const checkVPNFromIP = require('../services/checkVPNFromIP.js');

const vpnCheck = (req, res, next) => {
    const ipAddress = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
    checkVPNFromIP(ipAddress).then((isVPN) => {
        if (isVPN) {
            logger.debug(`VPN Detected from IP ${ipAddress}, blocking request`);
            return res.status(403).json({ error: req.translate("auth.ip_access_check.vpn_unallowed") });
        }
        next();
    }).catch((error) => {
        logger.error("Error while checking VPN from IP", error);
        return res.status(500).json({ error: req.translate("error.internal", { action: "checking VPN from IP" }) });
    });
};

module.exports = vpnCheck;
