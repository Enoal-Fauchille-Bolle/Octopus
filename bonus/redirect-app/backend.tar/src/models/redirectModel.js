const pool = require('../config/db');

const createRedirectInDB = async (original_url, custom_alias, user_id) => {
    const result = await pool.query(
        'INSERT INTO redirects (original_url, custom_alias, user_id) VALUES ($1, $2, $3) RETURNING *',
        [original_url, custom_alias, user_id]
    );
    return result?.rows?.[0];
};

const getRedirectsByUserId = async (user_id) => {
    // const result = await pool.query('SELECT * FROM redirects WHERE user_id = $1', [user_id]);
    const query = `
        SELECT
            redirects.*,
            JSON_AGG(redirect_stats.*) AS stats
        FROM redirects
        LEFT JOIN redirect_stats
        ON redirect_stats.redirect_id = redirects.id
        WHERE redirects.user_id = $1
        GROUP BY redirects.id
        ORDER BY redirects.created_at DESC;
    `
    const result = await pool.query(query, [user_id]);
    return result?.rows
        .map(redirect => {
            redirect.stats = redirect.stats.filter(stat => stat != null);
            return redirect;
        })
};

const getRedirectByAlias = async (alias) => {
    const result = await pool.query('SELECT * FROM redirects WHERE custom_alias = $1', [alias]);
    return result?.rows?.[0];
};

const getRedirectById = async (id) => {
    const result = await pool.query('SELECT * FROM redirects WHERE id = $1', [id]);
    return result?.rows?.[0];
};

const deleteRedirectById = async (id) => {
    const result = await pool.query('DELETE FROM redirects WHERE id = $1', [id]);
    return result?.rows?.[0];
};

const editRedirectById = async (id, original_url) => {
    const result = await pool.query(
        'UPDATE redirects SET original_url = $1 WHERE id = $2 RETURNING *',
        [original_url, id]
    );
    return result?.rows?.[0];
};

const getAllRedirects = async () => {
    const result = await pool.query('SELECT * FROM redirects');
    return result.rows;
};

module.exports = {
    createRedirectInDB,
    getRedirectsByUserId,
    getRedirectByAlias,
    getRedirectById,
    deleteRedirectById,
    editRedirectById,
    getAllRedirects,
};
