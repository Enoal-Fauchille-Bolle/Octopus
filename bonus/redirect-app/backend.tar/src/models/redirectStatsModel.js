const pool = require('../config/db');

const createStatInDB = async (redirect_id, user_agent, browser, os, ip_address, country_code) => {
    const access_time = new Date();
    const result = await pool.query(
        'INSERT INTO redirect_stats (redirect_id, access_time, user_agent, browser, os, ip_address, country) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *',
        [redirect_id, access_time, user_agent, browser, os, ip_address, country_code]
    );
    return result?.rows?.[0];
};

const getRedirectStatsByRedirectId = async (redirect_id) => {
    const result = await pool.query(
        'SELECT * FROM redirect_stats WHERE redirect_id = $1',
        [redirect_id]
    );
    return result.rows;
};

const getAllStats = async (user_id) => {
    const result = await pool.query('SELECT * FROM redirect_stats WHERE redirect_id IN (SELECT id FROM redirects WHERE user_id = $1)', [user_id]);
    return result.rows;
};

const deleteStatsOfRedirectId = async (redirect_id) => {
    const result = await pool.query('DELETE FROM redirect_stats WHERE redirect_id = $1 RETURNING *', [redirect_id]);
    return result.rows;
};

module.exports = {
    createStatInDB,
    getRedirectStatsByRedirectId,
    getAllStats,
    deleteStatsOfRedirectId
};
