const pool = require('../config/db');

const createSession = async (sessionId, userId, expires_at, user_agent, os, browser, ip_address, country_code) => {
    const query = `
        INSERT INTO sessions (id, user_id, expires_at, user_agent, os, browser, ip_address, country)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
        RETURNING *;
    `;
    const values = [sessionId, userId, expires_at, user_agent, os, browser, ip_address, country_code];
    const result = await pool.query(query, values);
    return result?.rows?.[0];
};

const getUserSessions = async (userId) => {
    const query = `
        SELECT * FROM sessions WHERE user_id = $1;
    `;
    const result = await pool.query(query, [userId]);
    return result.rows;
};

const disableSession = async (id) => {
    const query = `
        UPDATE sessions
        SET is_active = false
        WHERE id = $1
        RETURNING *;
    `;
    const result = await pool.query(query, [id]);
    return result?.rows?.[0];
};

const disableAllSessionsExceptCurrent = async (userId, sessionId) => {
    const query = `
        UPDATE sessions
        SET is_active = false
        WHERE user_id = $1 AND id != $2 AND is_active = true
        RETURNING *;
    `;
    const result = await pool.query(query, [userId, sessionId]);
    return result.rows;
}

const disableAllSessions = async (userId) => {
    const query = `
        UPDATE sessions
        SET is_active = false
        WHERE user_id = $1 AND is_active = true
        RETURNING *;
    `;
    const result = await pool.query(query, [userId]);
    return result.rows;
}

const getSessionById = async (sessionId) => {
    const query = `
        SELECT * FROM sessions WHERE id = $1;
    `;
    const result = await pool.query(query, [sessionId]);
    return result?.rows?.[0];
};

const disableExpiredSessions = async () => {
    const query = `
        UPDATE sessions
        SET is_active = false
        WHERE expires_at < NOW()
        RETURNING *;
    `;
    const result = await pool.query(query);
    return result.rows;
};

const disableOldSessions = async (userId, numberOfSessionsToKeep) => {
    const selectQuery = `
        SELECT id
        FROM sessions
        WHERE user_id = $1 AND is_active = true
        ORDER BY expires_at DESC
        OFFSET $2
    `;
    const selectValues = [userId, numberOfSessionsToKeep];
    const result = await pool.query(selectQuery, selectValues);

    const sessionIdsToDisable = result.rows.map(session => session.id);

    if (sessionIdsToDisable.length > 0) {
        const updateQuery = `
            UPDATE sessions
            SET is_active = false
            WHERE id = ANY($1::uuid[])
            RETURNING *;
        `;
        const updateValues = [sessionIdsToDisable];
        const updatedResult = await pool.query(updateQuery, updateValues);
        return updatedResult.rows;
    }

    return [];
};

const updateSessionId = async (oldSessionId, newSessionId, expires_at, user_agent, os, browser, ip_address, country_code) => {
    const query = `
        UPDATE sessions
        SET id = $2, created_at = NOW(), expires_at = $3, user_agent = $4, os = $5, browser = $6, ip_address = $7, country = $8
        WHERE id = $1
        RETURNING *;
    `;
    const values = [oldSessionId, newSessionId, expires_at, user_agent, os, browser, ip_address, country_code];
    const result = await pool.query(query, values);
    return result?.rows?.[0];
}

const getUserCountrySessions = async (user_id, country) => {
    const query = `
        SELECT * FROM sessions WHERE user_id = $1 AND country = $2;
    `;
    const result = await pool.query(query, [user_id, country]);
    return result.rows;
}

const updateLastActivity = async (sessionId) => {
    const query = `
        UPDATE sessions
        SET last_activity = NOW()
        WHERE id = $1
        RETURNING *;
    `;
    const result = await pool.query(query, [sessionId]);
    return result?.rows?.[0];
}

module.exports = {
    createSession,
    getUserSessions,
    disableSession,
    disableAllSessionsExceptCurrent,
    disableAllSessions,
    getSessionById,
    disableExpiredSessions,
    disableOldSessions,
    updateSessionId,
    getUserCountrySessions,
    updateLastActivity
};
