const pool = require('../config/db');

const createUser = async (username, email, password, email_token, country_code) => {
    const query = `
        INSERT INTO users (username, email, password, email_verification_token, whitelisted_countries)
        VALUES ($1, $2, $3, $4, ARRAY[$5])
        RETURNING *;
    `;
    const values = [username, email, password, email_token, country_code];
    const result = await pool.query(query, values);
    return result?.rows?.[0];
};

const findByEmail = async (email) => {
    const query = `
        SELECT * FROM users WHERE email = $1;
    `;
    const result = await pool.query(query, [email]);
    return result?.rows?.[0];
};

const findById = async (id) => {
    const query = `
        SELECT * FROM users WHERE id = $1;
    `;
    const result = await pool.query(query, [id]);
    return result?.rows?.[0];
};

const updateUser = async (id, username, email, hashedPassword) => {
    // Parameters are optional
    const values = [id];
    let query = 'UPDATE users SET';
    if (username) {
        query += ` username = $${values.length + 1},`;
        values.push(username);
    }
    if (email) {
        query += ` email = $${values.length + 1},`;
        values.push(email);
    }
    if (hashedPassword) {
        query += ` password = $${values.length + 1},`;
        values.push(hashedPassword);
    }
    // Remove trailing comma
    query = query.slice(0, -1);
    query += ` WHERE id = $1 RETURNING *;`;
    const result = await pool.query(query, values);
    return result?.rows?.[0];
};

const deleteUser = async (id) => {
    const query = `
        DELETE FROM users
        WHERE id = $1
        RETURNING *;
    `;
    const result = await pool.query(query, [id]);
    return result?.rows?.[0];
};

const getAllUsers = async () => {
    const query = `
        SELECT * FROM users;
    `;
    const result = await pool.query(query);
    return result.rows;
};

const findByUsername = async (username) => {
    const query = `
        SELECT * FROM users WHERE username = $1;
    `;
    const result = await pool.query(query, [username]);
    return result?.rows?.[0];
}

const updateResetToken = async (user_id, token) => {
    const query = `
        UPDATE users
        SET reset_token = $1, reset_token_expires = NOW() + INTERVAL '1 hour'
        WHERE id = $2
        RETURNING *;
    `;
    const result = await pool.query(query, [token, user_id]);
    return result?.rows?.[0];
}

const findByResetToken = async (token) => {
    const query = `
        SELECT * FROM users
        WHERE reset_token = $1;
    `;
    const result = await pool.query(query, [token]);
    return result?.rows?.[0];
}

const updatePassword = async (user_id, hashedPassword) => {
    const query = `
        UPDATE users
        SET password = $1, reset_token = NULL, reset_token_expires = NULL
        WHERE id = $2
        RETURNING *;
    `;
    const result = await pool.query(query, [hashedPassword, user_id]);
    return result?.rows?.[0];
}

const findByEmailVerificationToken = async (token) => {
    const query = `
        SELECT * FROM users
        WHERE email_verification_token = $1;
    `;
    const result = await pool.query(query, [token]);
    return result?.rows?.[0];
}

const verifyEmail = async (user_id) => {
    const query = `
        UPDATE users
        SET email_verified = TRUE, email_verification_token = NULL
        WHERE id = $1
        RETURNING *;
    `;
    const result = await pool.query(query, [user_id]);
    return result?.rows?.[0];
}

const updateEmailVerificationToken = async (user_id, token) => {
    const query = `
        UPDATE users
        SET email_verification_token = $1
        WHERE id = $2
        RETURNING *;
    `;
    const result = await pool.query(query, [token, user_id]);
    return result?.rows?.[0];
}

const lockUserAccount = async (user_id, unlock_token, lockout_expires) => {
    const query = `
        UPDATE users
        SET is_locked = TRUE, email_verification_token = $1, lockout_expires = $2, failed_attempts = 0
        WHERE id = $3
        RETURNING *;
    `;
    const result = await pool.query(query, [unlock_token, lockout_expires, user_id]);
    return result?.rows?.[0];
}

const updateFailedAttempts = async (user_id, failed_attempts) => {
    const query = `
        UPDATE users
        SET failed_attempts = $1
        WHERE id = $2
        RETURNING *;
    `;
    const result = await pool.query(query, [failed_attempts, user_id]);
    return result?.rows?.[0];
}

const unlockUserAccount = async (user_id) => {
    const query = `
        UPDATE users
        SET is_locked = FALSE, lockout_expires = NULL, failed_attempts = 0, email_verification_token = NULL
        WHERE id = $1
        RETURNING *;
    `;
    const result = await pool.query(query, [user_id]);
    return result?.rows?.[0];
}

const resetFailedAttempts = async (user_id) => {
    const query = `
        UPDATE users
        SET failed_attempts = 0
        WHERE id = $1
        RETURNING *;
    `;
    const result = await pool.query(query, [user_id]);
    return result?.rows?.[0];
}

const updateConnectionVerificationToken = async (user_id, country_code, token, expires_at) => {
    const query = `
        UPDATE users
        SET connection_verification_token = $1, connection_verification_expires = $2, connection_verification_country = $4
        WHERE id = $3
        RETURNING *;
    `;
    const result = await pool.query(query, [token, expires_at, user_id, country_code]);
    return result?.rows?.[0];
}

const findByConnectionVerificationToken = async (token) => {
    const query = `
        SELECT * FROM users
        WHERE connection_verification_token = $1;
    `;
    const result = await pool.query(query, [token]);
    return result?.rows?.[0];
}

const updateWhitelistedCountries = async (user_id, countries) => {
    const query = `
        UPDATE users
        SET whitelisted_countries = $1
        WHERE id = $2
        RETURNING *;
    `;
    const result = await pool.query(query, [countries, user_id]);
    return result?.rows?.[0];
}

const setupMfa = async (user_id, secret) => {
    const query = `
        UPDATE users
        SET mfa_secret = $1
        WHERE id = $2
        RETURNING *;
    `;
    const result = await pool.query(query, [secret, user_id]);
    return result?.rows?.[0];
}

const enableMfa = async (user_id, hashed_backup_codes) => {
    const query = `
        UPDATE users
        SET mfa_enabled = TRUE, mfa_backup_codes = $1
        WHERE id = $2
        RETURNING *;
    `;
    const result = await pool.query(query, [hashed_backup_codes, user_id]);
    return result?.rows?.[0];
}

const disableMfa = async (user_id) => {
    const query = `
        UPDATE users
        SET mfa_enabled = FALSE, mfa_secret = NULL, mfa_backup_codes = NULL
        WHERE id = $1
        RETURNING *;
    `;
    const result = await pool.query(query, [user_id]);
    return result?.rows?.[0];
}

const updateBackupCodes = async (user_id, hashed_backup_codes) => {
    const query = `
        UPDATE users
        SET mfa_backup_codes = $1
        WHERE id = $2
        RETURNING *;
    `;
    const result = await pool.query(query, [hashed_backup_codes, user_id]);
    return result?.rows?.[0];
}

module.exports = {
    createUser,
    findByEmail,
    findById,
    updateUser,
    deleteUser,
    getAllUsers,
    findByUsername,
    updateResetToken,
    findByResetToken,
    updatePassword,
    findByEmailVerificationToken,
    verifyEmail,
    updateEmailVerificationToken,
    lockUserAccount,
    updateFailedAttempts,
    unlockUserAccount,
    resetFailedAttempts,
    updateConnectionVerificationToken,
    findByConnectionVerificationToken,
    updateWhitelistedCountries,
    setupMfa,
    enableMfa,
    disableMfa,
    updateBackupCodes,
};
