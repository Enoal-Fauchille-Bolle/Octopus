const config = require('./config');
const logger = require('./logger');
const os = require('os');
const osu = require('node-os-utils');
const sendHighUsageAlert = require('./services/sendHighUsageAlert');

const checkMemoryUsage = async (warningThreshold, verbose = false) => {
    const totalMemory = osu.mem
    const totalMemoryUsed = Math.round((await totalMemory.used()).usedMemMb)
    const memoryTotal = Math.round(os.totalmem() / 1024 / 1024)

    const usedMemoryPercentage = (totalMemoryUsed / memoryTotal) * 100;

    if (isNaN(usedMemoryPercentage)) {
        logger.error('Error calculating memory usage');
        return;
    }

    if (verbose)
        logger.debug(`Memory usage: ${usedMemoryPercentage.toFixed(2)}%`);

    if (usedMemoryPercentage > warningThreshold) {
        logger.warn(`High memory usage detected, at ${usedMemoryPercentage.toFixed(2)}% of capacity.`);
        if (!verbose && config.resource_monitoring.notify) {
            sendHighUsageAlert('Memory', usedMemoryPercentage.toFixed(2));
        }
    }
};


let timesBefore = os.cpus().map(c => c.times);

const checkCpuUsage = (warningThreshold, verbose = false) => {
    let timesAfter = os.cpus().map(c => c.times);
    let timeDeltas = timesAfter.map((t, i) => ({
        user: t.user - timesBefore[i].user,
        sys: t.sys - timesBefore[i].sys,
        idle: t.idle - timesBefore[i].idle
    }));

    timesBefore = timesAfter;

    const usagePercentage = timeDeltas
        .map(times => 1 - times.idle / (times.user + times.sys + times.idle))
        .reduce((l1, l2) => l1 + l2) / timeDeltas.length * 100;

    if (isNaN(usagePercentage)) {
        logger.error('Error calculating CPU usage');
        return;
    }

    if (verbose)
        logger.debug(`CPU usage: ${usagePercentage.toFixed(2)}%`);

    if (usagePercentage > warningThreshold) {
        logger.warn(`High CPU usage detected, at ${usagePercentage.toFixed(2)}% of capacity.`);
        if (!verbose && config.resource_monitoring.notify) {
            sendHighUsageAlert('CPU', usagePercentage.toFixed(2));
        }
    }
};

const checkResourceUsage = () => {
    if (config.resource_monitoring.memory.enable_memory_monitoring) {
        checkMemoryUsage(config.resource_monitoring.memory.warning_threshold, true);
    }
    if (config.resource_monitoring.cpu.enable_cpu_monitoring) {
        checkCpuUsage(config.resource_monitoring.cpu.warning_threshold, true);
    }
}

const startResourceMonitoring = () => {
    checkResourceUsage();

    setInterval(() => {
        checkMemoryUsage(config.resource_monitoring.memory.warning_threshold);
    }, config.resource_monitoring.memory.check_interval);

    setInterval(() => {
        checkCpuUsage(config.resource_monitoring.cpu.warning_threshold);
    }, config.resource_monitoring.cpu.check_interval);
};

module.exports = {
    startResourceMonitoring
};
