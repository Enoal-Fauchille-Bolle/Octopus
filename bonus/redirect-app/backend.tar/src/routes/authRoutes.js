const express = require('express');
const {
    register,
    verifyEmail,
    resendVerificationEmail,
    login,
    forgotPassword,
    resetPassword,
    checkResetToken,
    logout,
    getSessions,
    refreshToken,
    deleteSession,
    deleteAllSessions,
    unlockAccount,
    whitelistCountry,
    SetupMfa,
    verifyMfaCode,
    disableMfa,
    getWhitelistedCountries,
    deleteWhitelistedCountry,
} = require('../controllers/authController');
const authMiddleware = require('../middleware/authMiddleware');

const logger = require('../logger');

logger.debug("Initializing auth routes...");

const router = express.Router();

router.post('/register', register);
router.post('/verify-email', verifyEmail);
router.post('/resend-verification-email', resendVerificationEmail);
router.post('/login', login);
router.post('/forgot-password', forgotPassword);
router.post('/reset-password', resetPassword);
router.get('/reset-password', checkResetToken);
router.post('/logout', authMiddleware, logout);
// router.post('/refresh-token', authMiddleware, refreshToken);
router.get('/sessions', authMiddleware, getSessions);
router.delete('/sessions/all', authMiddleware, deleteAllSessions);
router.delete('/sessions/:sessionId', authMiddleware, deleteSession);
router.post('/unlock-account', unlockAccount);
router.post('/whitelist-country', whitelistCountry);
router.post('/mfa/setup', authMiddleware, SetupMfa);
router.post('/mfa/verify', authMiddleware, verifyMfaCode);
router.post('/mfa/disable', authMiddleware, disableMfa);
router.get("/whitelisted-countries", authMiddleware, getWhitelistedCountries);
router.delete("/whitelisted-countries/:country_code", authMiddleware, deleteWhitelistedCountry);

module.exports = router;

logger.debug("Auth routes initialized.");
