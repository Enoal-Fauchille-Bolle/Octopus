const express = require('express');
const {
    createRedirect,
    getRedirects,
    getRedirect,
    deleteRedirect,
    editRedirect
} = require('../controllers/redirectController');

const logger = require('../logger');

logger.debug("Initializing redirect routes...");

const router = express.Router();

router.post('/redirect', createRedirect);
router.get('/redirects', getRedirects);
router.put('/redirect/:id', editRedirect);
router.delete('/redirect/:id', deleteRedirect);
router.get('/redirect/:identifier', getRedirect);

module.exports = router;

logger.debug("Redirect routes initialized.");
