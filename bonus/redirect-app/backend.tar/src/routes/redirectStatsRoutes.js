const express = require('express');
const {
    getRedirectStats,
    getStats
} = require('../controllers/redirectStatsController');

const logger = require('../logger');

logger.debug("Initializing redirect stats routes...");

const router = express.Router();

router.get('/stats/redirect/:id', getRedirectStats);
router.get('/stats', getStats);

module.exports = router;

logger.debug("Redirect stats routes initialized.");
