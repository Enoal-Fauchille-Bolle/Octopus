const express = require('express');
const {
    getMe,
    getUser,
    deleteMe,
    updateMe
} = require('../controllers/userController');

const logger = require('../logger');

logger.debug("Initializing user routes...");

const router = express.Router();

router.get('/auth/me', getMe);
router.patch('/auth/me', updateMe);
router.get('/user/:identifier', getUser);
router.delete('/auth/me', deleteMe);

module.exports = router;

logger.debug("User routes initialized.");
