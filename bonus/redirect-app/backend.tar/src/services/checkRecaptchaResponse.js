const axios = require('axios');
const logger = require('../logger.js');
const config = require('../config.js');
const dotenv = require('dotenv');
dotenv.config();

const checkRecaptchaResponse = async (response, type) => {
    if (type === 'normal') {
        return await checkNormalRecaptchaResponse(response);
    } else if (type === 'invisible') {
        return await checkInvisibleRecaptchaResponse(response);
    } else {
        logger.error(`Invalid recaptcha type: ${type}`);
        return false;
    }
}

const checkNormalRecaptchaResponse = async (response) => {
    try {
        const recaptchaResponse = await axios.post(`https://www.google.com/recaptcha/api/siteverify?secret=${process.env.RECAPTCHA_v2_NORMAL_SERVER_KEY}&response=${response}`);
        if (recaptchaResponse.data.success) {
            return true;
        } else {
            return false;
        }
    } catch (error) {
        logger.error("Error while verifying recaptcha response", error);
        return false;
    }
}

const checkInvisibleRecaptchaResponse = async (response) => {
    try {
        const recaptchaResponse = await axios.post(`https://www.google.com/recaptcha/api/siteverify?secret=${process.env.RECAPTCHA_v2_INVISIBLE_SERVER_KEY}&response=${response}`);
        if (recaptchaResponse.data.success) {
            return true;
        } else {
            return false;
        }
    } catch (error) {
        logger.error("Error while verifying recaptcha response", error);
        return false;
    }
}

module.exports = checkRecaptchaResponse;
