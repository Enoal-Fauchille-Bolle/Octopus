const fs = require('fs');
const axios = require('axios');
const path = require('path');
const dotenv = require('dotenv');
dotenv.config();

const logger = require('../logger');

const cacheFilePath = path.join(__dirname, 'ipVPNCache.json');

let vpnCache = {};

const loadCache = () => {
    logger.debug("Loading IP VPN cache");
    if (fs.existsSync(cacheFilePath)) {
        const data = fs.readFileSync(cacheFilePath);
        vpnCache = JSON.parse(data);
        logger.debug(`Loaded ${Object.keys(vpnCache).length} cached IP VPN addresses`);
    }
};

const saveCache = () => {
    fs.writeFileSync(cacheFilePath, JSON.stringify(vpnCache));
    logger.debug(`Saved ${Object.keys(vpnCache).length} cached IP addresses`);
};

const checkVPNFromIP = async (ipAddress) => {
    logger.debug(`Checking VPN for IP address ${ipAddress}`);
    // Check if the IP is already in the cache

    if (vpnCache[ipAddress] != null) {
        logger.debug(`VPN for IP address ${ipAddress} found in cache: ${vpnCache[ipAddress]}`);
        return vpnCache[ipAddress];
    }

    // If not, fetch the country from the external service
    logger.debug(`VPN for IP address ${ipAddress} not found in cache, fetching from external service`);
    const isVPN = await fetchVPNFromExternalService(ipAddress);
    logger.debug(`VPN for IP address ${ipAddress} is ${isVPN}`);

    // Store the country in the cache
    vpnCache[ipAddress] = isVPN;
    saveCache();

    return isVPN;
}

const fetchVPNFromExternalService = async (ipAddress) => {
    const url = `https://vpnapi.io/api/${ipAddress}?key=${process.env.VPNAPI_API_KEY}`;
    let isVPN = null;
    await axios.get(url).then((response) => {
        isVPN = response?.data?.security?.vpn || false;
    }).catch((error) => {
        if (error.status == 429) {
            logger.error("Error while checking VPN from IP: Rate limit exceeded");
            return null;
        }
        logger.error("Error while checking VPN from IP", error);
    });
    return isVPN;
};

loadCache();

module.exports = checkVPNFromIP;