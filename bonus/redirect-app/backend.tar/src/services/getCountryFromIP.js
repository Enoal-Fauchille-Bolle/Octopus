const fs = require('fs');
const axios = require('axios');
const path = require('path');

const logger = require('../logger');

const cacheFilePath = path.join(__dirname, 'ipCountryCache.json');

let countryCache = {};

const loadCache = () => {
    logger.debug("Loading IP country cache");
    if (fs.existsSync(cacheFilePath)) {
        const data = fs.readFileSync(cacheFilePath);
        countryCache = JSON.parse(data);
        logger.debug(`Loaded ${Object.keys(countryCache).length} cached IP Country code addresses`);
    }
};

const saveCache = () => {
    fs.writeFileSync(cacheFilePath, JSON.stringify(countryCache));
    logger.debug(`Saved ${Object.keys(countryCache).length} cached IP addresses`);
};

const getCountryFromIP = async (ipAddress) => {
    logger.debug(`Getting country code for IP address ${ipAddress}`);
    // Check if the country is already in the cache

    if (countryCache[ipAddress]) {
        logger.debug(`Country code for IP address ${ipAddress} found in cache: ${countryCache[ipAddress]}`);
        return countryCache[ipAddress];
    }

    // If not, fetch the country from the external service
    logger.debug(`Country code for IP address ${ipAddress} not found in cache, fetching from external service`);
    const country = await fetchCountryFromExternalService(ipAddress);
    logger.debug(`Country code for IP address ${ipAddress} is ${country}`);

    // Store the country in the cache
    countryCache[ipAddress] = country;
    saveCache();

    return country;
}

const fetchCountryFromExternalService = async (ipAddress) => {
    const url = `https://ipapi.co/${ipAddress}/json/`;
    let country = null;
    await axios.get(url).then((response) => {
        if (response.data.reserved) {
            country = 'Local Host';
        } else {
            country = response.data.country_code || null;
        }
    }).catch((error) => {
        if (error.status == 429) {
            logger.error("Error while getting country from IP: Rate limit exceeded");
            return null;
        }
        logger.error("Error while getting country from IP", error);
    });
    return country;
};

loadCache();

module.exports = getCountryFromIP;
