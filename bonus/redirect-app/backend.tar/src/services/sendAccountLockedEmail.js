const sgMail = require('@sendgrid/mail')
const dotenv = require('dotenv')
dotenv.config()

const logger = require('../logger');
const config = require('../config');

sgMail.setApiKey(process.env.SENDGRID_API_KEY)

const sendAccountLockedEmail = async (email, unlock_token) => {
    const msg = {
        to: email,
        from: config.email.from_address,
        templateId: config.email.account_locked.template_id,
        dynamic_template_data: {
            application_name: config.app.application_name,
            icon_url: config.app.application_icon,
            unlock_link: config.email.account_locked.link.replace('{{unlock_token}}', unlock_token),
        },
    }
    try {
        logger.debug(`Sending account locked email to ${email}`);
        await sgMail.send(msg);
        logger.debug(`Account locked email sent to ${email}`);
    } catch (error) {
        logger.error("Error while sending account locked email", error);
        return error;
    }
}

module.exports = sendAccountLockedEmail;