const axios = require('axios');
const dotenv = require('dotenv');
const logger = require('../logger');
dotenv.config();

const sendHighUsageAlert = async (resource, usage) => {
    const topic = process.env.NTFY_TOPIC;
    const message =
        `**${resource}:** ${usage}%\n` +
        `Please check system resources immediately.`;

    axios.post(`https://ntfy.sh/${topic}`, message, {
        headers: {
            'Title': `System Alert - High ${resource} Usage`,
            'Priority': 'default',
            'Markdown': 'yes',
            'Tags': 'warning'
        }
    }).catch(error => {
        logger.error(`Error sending high usage alert`, error);
    });
}

module.exports = sendHighUsageAlert;
