const sgMail = require('@sendgrid/mail')
const dotenv = require('dotenv')
dotenv.config()

const logger = require('../logger');
const config = require('../config');

sgMail.setApiKey(process.env.SENDGRID_API_KEY)

const sendPasswordChangedEmail = async (email) => {
    const msg = {
        to: email,
        from: config.email.from_address,
        templateId: config.email.password_changed.template_id,
        dynamic_template_data: {
            application_name: config.app.application_name,
            icon_url: config.app.application_icon,
            reset_link: config.email.password_changed.link
        },
    }
    try {
        logger.debug(`Sending password changed email to ${email}`);
        await sgMail.send(msg);
        logger.debug(`Password changed email sent to ${email}`);
    } catch (error) {
        logger.error("Error while sending password changed email", error);
        return error;
    }
}

module.exports = sendPasswordChangedEmail;