const sgMail = require('@sendgrid/mail')
const dotenv = require('dotenv')
dotenv.config()

const logger = require('../logger');
const config = require('../config');

sgMail.setApiKey(process.env.SENDGRID_API_KEY)

const sendResetPasswordEmail = async (email, reset_token) => {
    const msg = {
        to: email,
        from: config.email.from_address,
        templateId: config.email.reset_password.template_id,
        dynamic_template_data: {
            application_name: config.app.application_name,
            icon_url: config.app.application_icon,
            reset_link: config.email.reset_password.link.replace('{{reset_token}}', reset_token),
        },
    }
    try {
        logger.debug(`Sending reset password email to ${email}`);
        await sgMail.send(msg);
        logger.debug(`Reset password email sent to ${email}`);
    } catch (error) {
        logger.error("Error while sending reset password email", error);
        return error;
    }
}

module.exports = sendResetPasswordEmail;