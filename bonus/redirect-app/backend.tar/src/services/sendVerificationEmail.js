const sgMail = require('@sendgrid/mail')
const dotenv = require('dotenv')
dotenv.config()

const logger = require('../logger');
const config = require('../config');

sgMail.setApiKey(process.env.SENDGRID_API_KEY)

const sendVerificationEmail = async (email, email_verification_token) => {
    const msg = {
        to: email,
        from: config.email.from_address,
        templateId: config.email.verification.template_id,
        dynamic_template_data: {
            application_name: config.app.application_name,
            icon_url: config.app.application_icon,
            verification_link: config.email.verification.link.replace('{{email_verification_token}}', email_verification_token),
        },
    }
    try {
        logger.debug(`Sending verification email to ${email}`);
        await sgMail.send(msg);
        logger.debug(`Verification email sent to ${email}`);
    } catch (error) {
        logger.error("Error while sending verification email", error);
        return error;
    }
}

module.exports = sendVerificationEmail;