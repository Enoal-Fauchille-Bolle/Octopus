const sgMail = require('@sendgrid/mail')
const dotenv = require('dotenv')
dotenv.config()

const logger = require('../logger');
const config = require('../config');

sgMail.setApiKey(process.env.SENDGRID_API_KEY)

const sendWhitelistCountryEmail = async (email, email_verification_token, ip_address, country) => {
    const msg = {
        to: email,
        from: config.email.from_address,
        templateId: config.email.whitelist_country.template_id,
        dynamic_template_data: {
            application_name: config.app.application_name,
            icon_url: config.app.application_icon,
            verification_link: config.email.whitelist_country.link.replace('{{whitelist_token}}', email_verification_token),
            ip_address: ip_address,
            country: country,
            date_time: new Date().toLocaleString(),
        },
    }
    try {
        logger.debug(`Sending whitelist country email to ${email}`);
        await sgMail.send(msg);
        logger.debug(`Whitelist country email sent to ${email}`);
    } catch (error) {
        logger.error("Error while sending whitelist country email", error);
        return error;
    }
}

module.exports = sendWhitelistCountryEmail;