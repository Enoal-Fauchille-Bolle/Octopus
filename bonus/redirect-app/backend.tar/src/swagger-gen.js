const swaggerAutogen = require('swagger-autogen')();

const doc = {
  info: {
    title: 'API Documentation',
    description: 'Description de l\'API',
  },
  host: 'redirect.azerdev.me',
  schemes: ['https'],
  components: {
    securitySchemes: {
      BearerAuth: {
        type: 'http',
        scheme: 'bearer',
        bearerFormat: 'JWT',
      },
    },
  },
  security: [
    {
      BearerAuth: [], // Appliquer le schéma de sécurité à toutes les opérations
    },
  ],
};

const outputFile = './swagger-output.json';
const endpointsFiles = ['./app.js']; // Fichier principal où les routes sont définies

swaggerAutogen(outputFile, endpointsFiles, doc)
