const swaggerUi = require('swagger-ui-express');
const swaggerFile = require('./swagger-output.json');
const config = require('./config');

const setupSwagger = (app) => {
    app.use(config.swagger.base_url, swaggerUi.serve, swaggerUi.setup(swaggerFile));
};

module.exports = setupSwagger;
