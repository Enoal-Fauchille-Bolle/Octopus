const aliasIsValid = (alias, minLength, maxLength) => {
    if (!alias) {
        return false;
    }
    let aliasRegex = new RegExp(`^[a-zA-Z0-9_-]{${minLength},${maxLength}}$`);
    return aliasRegex.test(alias);
};

module.exports = aliasIsValid;