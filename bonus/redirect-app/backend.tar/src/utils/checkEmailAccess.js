const config = require('../config');

const checkEmailAccess = (email) => {
    if (config.whitelist.enable_email_whitelist) {
        if (config.whitelist.email_whitelist.includes(email)) {
            return {
                allowed: true,
                blacklisted: false,
                whitelisted: true
            };
        } else {
            return {
                allowed: false,
                blacklisted: false,
                whitelisted: false
            }
        }
    }

    if (config.blacklist.enable_email_blacklist) {
        if (config.blacklist.email_blacklist.includes(email)) {
            return {
                allowed: false,
                blacklisted: true,
                whitelisted: false
            }
        } else {
            return {
                allowed: true,
                blacklisted: false,
                whitelisted: false
            }
        }
    }

    return {
        allowed: true,
        blacklisted: false,
        whitelisted: false
    }
};

module.exports = checkEmailAccess;