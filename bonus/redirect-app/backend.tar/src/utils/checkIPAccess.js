const config = require('../config');

const checkIPAccess = (ip) => {
    if (config.whitelist.enable_ip_whitelist) {
        if (config.whitelist.ip_whitelist?.includes(ip)) {
            return {
                allowed: true,
                blacklisted: false,
                whitelisted: true
            };
        } else {
            return {
                allowed: false,
                blacklisted: false,
                whitelisted: false
            }
        }
    }

    if (config.blacklist.enable_ip_blacklist) {
        if (config.blacklist.ip_blacklist?.includes(ip)) {
            return {
                allowed: false,
                blacklisted: true,
                whitelisted: false
            }
        } else {
            return {
                allowed: true,
                blacklisted: false,
                whitelisted: false
            }
        }
    }

    return {
        allowed: true,
        blacklisted: false,
        whitelisted: false
    }
};

module.exports = checkIPAccess;