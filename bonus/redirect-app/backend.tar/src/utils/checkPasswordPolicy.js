const logger = require('../logger');
const config = require('../config');

const checkPasswordPolicy = (password, req) => {
    const passwordPolicy = config.password_policy;
    const passwordMinLength = passwordPolicy.min_length;
    const passwordMaxLength = passwordPolicy.max_length;
    const passwordRequireNumbers = passwordPolicy.require_numbers;
    const passwordRequireLowercase = passwordPolicy.require_lowercase;
    const passwordRequireUppercase = passwordPolicy.require_uppercase;
    const passwordRequireSpecialCharacters = passwordPolicy.require_special_characters;

    // Check if password policy is enabled
    if (!passwordPolicy.enable_password_policy) {
        logger.debug('Password policy is not enabled');
        return { valid: true };
    }

    // Check if password is enough length
    if (password.length < passwordMinLength) {
        logger.debug(`Password must be at least ${passwordMinLength} characters long`);
        return { valid: false, message: req.translate("auth.password_policy.min_length", { min: passwordMinLength }) };
    }

    // Check if password is too long
    if (password.length > passwordMaxLength) {
        logger.debug(`Password must be less than ${passwordMaxLength} characters long`);
        return { valid: false, message: req.translate("auth.password_policy.max_length", { max: passwordMaxLength }) };
    }

    // Check if password contains numbers
    if (passwordRequireNumbers && !/\d/.test(password)) {
        logger.debug('Password must contain at least one number');
        return { valid: false, message: req.translate("auth.password_policy.numbers") };
    }

    // Check if password contains lowercase characters
    if (passwordRequireLowercase && !/[a-z]/.test(password)) {
        logger.debug('Password must contain at least one lowercase character');
        return { valid: false, message: req.translate("auth.password_policy.lowercase") };
    }

    // Check if password contains uppercase characters
    if (passwordRequireUppercase && !/[A-Z]/.test(password)) {
        logger.debug('Password must contain at least one uppercase character');
        return { valid: false, message: req.translate("auth.password_policy.uppercase") };
    }

    // Check if password contains special characters
    if (passwordRequireSpecialCharacters && !/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
        logger.debug('Password must contain at least one special character');
        return { valid: false, message: req.translate("auth.password_policy.special_characters") };
    }

    return { valid: true };
};

module.exports = checkPasswordPolicy;