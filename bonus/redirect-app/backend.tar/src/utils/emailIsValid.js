const emailIsValid = (email) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) && !/\.{2,}/.test(email);
};

module.exports = emailIsValid;