const config = require('../config');

const generateAlias = () => {
    let alias = '';
    const characters = config.redirect.alias_characters;
    for (let i = 0; i < config.redirect.alias_length; i++) {
        alias += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return alias;
};

module.exports = generateAlias;