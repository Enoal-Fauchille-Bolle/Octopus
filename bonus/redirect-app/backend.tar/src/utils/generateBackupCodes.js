const generateBackupCodes = (amount = 10, length = 8) => {
    const codes = [];
    for (let i = 0; i < amount; i++) {
        const code = Array.from({ length }, () => Math.floor(Math.random() * 10)).join('');
        codes.push(code);
    }
    return codes;
}

module.exports = generateBackupCodes;
