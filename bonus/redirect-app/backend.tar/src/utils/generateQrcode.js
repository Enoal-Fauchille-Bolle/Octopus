const qrcode = require('qrcode');
const logger = require('../logger');

const generateQrcode = async (string) => {
    try {
        const qrCodeUrl = await qrcode.toDataURL(string);
        return qrCodeUrl;
    } catch (error) {
        logger.error("Error generating QR code", error);
    }
};

module.exports = generateQrcode;