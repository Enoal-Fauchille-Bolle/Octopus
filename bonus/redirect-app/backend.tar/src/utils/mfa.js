const crypto = require('crypto');
const otplib = require('otplib');
const bcrypt = require('bcryptjs');

const config = require('../config');
const logger = require('../logger');

const generateQrcode = require('../utils/generateQrcode');

const dotenv = require('dotenv');
dotenv.config();

// Configuring otplib
otplib.authenticator.options = {
    digits: 6,
};


const secretKey = process.env["MFA_SECRET"];

function encryptMfaSecret(secret) {
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(secretKey, 'hex'), iv);
    let encrypted = cipher.update(secret, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return iv.toString('hex') + ':' + encrypted;
}

function decryptMfaSecret(encryptedSecret) {
    let decrypted = '';
    try {
        const [ivHex, encryptedData] = encryptedSecret.split(':');
        const iv = Buffer.from(ivHex, 'hex');
        const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(secretKey, 'hex'), iv);
        decrypted = decipher.update(encryptedData, 'hex', 'utf8');
        decrypted += decipher.final('utf8');
    } catch (error) {
        return null;
    }
    return decrypted;
}


const usedCodes = [];

function removeUsedCode(code) {
    const index = usedCodes.indexOf(code);
    if (index !== -1) {
        usedCodes.splice(index, 1);
    }
}

async function findBackupCode(code, hashedBackupCodes) {
    if (code.length !== 8) {
        return null;
    }
    for (let i = 0; i < hashedBackupCodes.length; i++) {
        const hashedCode = hashedBackupCodes[i];
        if (await bcrypt.compare(code, hashedCode)) {
            return hashedCode;
        }
    }
    return null;
}

async function checkCode(code, userSecret, hashedBackupCodes) {
    // Check if the code is already used
    if (usedCodes.includes(code)) {
        return {
            valid: false,
            alreadyUsed: true,
            backupCode: false,
            hashedBackupCode: null,
        }
    }

    // Check if the code is valid
    if (otplib.authenticator.check(code, userSecret)) {
        usedCodes.push(code);
        setTimeout(() => {
            removeUsedCode(code);
        }, 30000);
        return {
            valid: true,
            alreadyUsed: false,
            backupCode: false,
            hashedBackupCode: null,
        }
    }

    // Check if the code is a backup code
    let hashedBackupCode = await findBackupCode(code, hashedBackupCodes);
    if (hashedBackupCode) {
        return {
            valid: true,
            alreadyUsed: false,
            backupCode: true,
            hashedBackupCode: hashedBackupCode,
        }
    }

    if (code.length === 6) {
        return {
            valid: false,
            alreadyUsed: false,
            backupCode: false,
            hashedBackupCode: null,
        }
    } else if (code.length === 8) {
        return {
            valid: false,
            alreadyUsed: false,
            backupCode: true,
            hashedBackupCode: null,
        }
    }
}


async function generateMfaSecret(email) {
    const userSecret = otplib.authenticator.generateSecret(); // Génère un secret aléatoire pour l'utilisateur
    const otpauth = otplib.authenticator.keyuri(email, config.app.application_name, userSecret); // Utilise userId pour l'URI
    const qrCodeUrl = await generateQrcode(otpauth);
    return { userSecret, otpauth, qrCodeUrl };
}


module.exports = {
    generateMfaSecret,
    checkCode,
    encryptMfaSecret,
    decryptMfaSecret
};