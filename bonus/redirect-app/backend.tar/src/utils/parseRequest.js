const uap = require('ua-parser-js');

const parseUseragent = (req) => {
    const useragent = req.headers?.['user-agent']
    const ua = uap(useragent);
    const os = ua.os.name ? ua.os.name : undefined;
    const browser = ua.browser.name ? ua.browser.name : undefined;
    const ipAddress = req.headers?.['x-forwarded-for'] || req.connection?.remoteAddress;

    return { useragent, os, browser, ipAddress };
}

module.exports = parseUseragent;
