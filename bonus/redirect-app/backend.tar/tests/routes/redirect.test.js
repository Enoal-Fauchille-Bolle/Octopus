// tests/routes/redirect.test.js
const request = require('supertest');
const app = require('../../src/app'); // Assurez-vous de bien importer l'app Express

let server;

beforeAll(() => {
    server = app.listen(50003); // Démarrer le serveur avant les tests
});

afterAll(() => {
    server.close(); // Fermer le serveur après les tests
});

describe("GET /redirect/:alias", () => {
    test('should redirect to the correct URL for valid alias', async () => {
        const response = await request(server)
            .get('/api/redirect/test')
            .set('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');
        expect(response.status).toBe(200);
        expect(response.header.location).toBe('https://example.com');
    });

    test('should return 404 for invalid alias', async () => {
        const response = await request(server)
            .get('/api/redirect/invalidAlias')
            .set('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');
        expect(response.status).toBe(404);
    });
});
