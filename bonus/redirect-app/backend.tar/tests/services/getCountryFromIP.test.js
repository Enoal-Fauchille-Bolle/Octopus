const axios = require('axios');
const getCountryFromIP = require('../../src/services/getCountryFromIP');

jest.mock('axios');

describe.skip('getCountryFromIP', () => {
  it('should return the country for a valid IP', async () => {
    const ip = "82.65.212.233";
    const mockResponse = { data: { country_name: 'France', error: false } };

    axios.get.mockResolvedValue(mockResponse);

    const country = await getCountryFromIP(ip);
    console.log(country);
    
    expect(country).toBe('FR');
  });

  it('should throw an error for a reserved IP', async () => {
    const ip = "192.168.1.254";
    const mockResponse = { data: { error: true, reason: 'Reserved IP Address', reserved: true } };

    axios.get.mockResolvedValue(mockResponse);

    const country = await getCountryFromIP(ip);

    expect(country).toBe('Local Host');
  });

  it('should throw an error for an invalid IP', async () => {
    const ip = "qiyozurdsiq";
    const mockResponse = { data: { ip: "qiyozurdsiq", error: true, reason: 'Invalid IP Address' } };

    axios.get.mockResolvedValue(mockResponse); // Simuler une réponse d'erreur

    const country = await getCountryFromIP(ip);

    expect(country).toBe(null);
  });

  it('should throw an error if the API call fails', async () => {
    const ip = '82.65.212.233';
    axios.get.mockRejectedValue(new Error('Network Error')); // Simuler un échec de l'appel API

    const country = await getCountryFromIP(ip);

    expect(country).toBe(null);
  });
});
