const fs = require('fs');
const axios = require('axios');
const path = require('path');
const getCountryFromIP = require('../../src/services/getCountryFromIP');
const logger = require('../../src/logger');

jest.mock('fs');
jest.mock('axios');
jest.mock('../../src/logger');
jest.mock('../../src/config', () => ({
    logging: {
        log_dir: './logs', // Indiquez un chemin valide ou fictif pour les tests
        log_level: 'info'
    },
}));

const cacheFilePath = path.join(__dirname, 'ipCountryCache.json');

describe.skip('getCountryFromIP', () => {
    let countryCache;

    beforeEach(() => {
        countryCache = {};
        jest.resetAllMocks();
    });

    test('should load cache if cache file exists', () => {
        const mockData = JSON.stringify({ '127.0.0.1': 'Local Host' });
        fs.existsSync.mockReturnValue(true);
        fs.readFileSync.mockReturnValue(mockData);

        const loadCache = require('../../src/services/getCountryFromIP').loadCache;
        loadCache();

        expect(fs.existsSync).toHaveBeenCalledWith(cacheFilePath);
        expect(fs.readFileSync).toHaveBeenCalledWith(cacheFilePath);
        expect(logger.debug).toHaveBeenCalledWith("Loading IP country cache");
        expect(logger.debug).toHaveBeenCalledWith(`Loaded 1 cached IP Country code addresses`);
    });

    test('should save cache to file', () => {
        countryCache = { '127.0.0.1': 'Local Host' };
        const saveCache = require('../../src/services/getCountryFromIP').saveCache;
        saveCache();

        expect(fs.writeFileSync).toHaveBeenCalledWith(cacheFilePath, JSON.stringify(countryCache));
        expect(logger.debug).toHaveBeenCalledWith(`Saved 1 cached IP addresses`);
    });

    test('should return country code from cache if available', async () => {
        countryCache['82.65.212.233'] = 'FR';
        fs.existsSync.mockReturnValue(true);
        fs.readFileSync.mockReturnValue(JSON.stringify(countryCache));

        const result = await getCountryFromIP('82.65.212.233');

        expect(result).toBe('FR');
        expect(logger.debug).toHaveBeenCalledWith("Country code for IP address 82.65.212.233 found in cache: FR");
    });

    test('should fetch country from external service if not in cache', async () => {
        const ipAddress = '82.65.212.233';
        const mockCountry = 'FR';
        axios.get.mockResolvedValue({ data: { country_code: mockCountry } });

        const result = await getCountryFromIP(ipAddress);

        expect(result).toBe(mockCountry);
        expect(axios.get).toHaveBeenCalledWith(`https://ipapi.co/${ipAddress}/json/`);
        expect(logger.debug).toHaveBeenCalledWith(`Country code for IP address ${ipAddress} is ${mockCountry}`);
        expect(fs.writeFileSync).toHaveBeenCalled();
    });

    test('should handle reserved IP and return "Local Host"', async () => {
        const ipAddress = '127.0.0.1';
        axios.get.mockResolvedValue({ data: { reserved: true } });

        const result = await getCountryFromIP(ipAddress);

        expect(result).toBe('Local Host');
        expect(logger.debug).toHaveBeenCalledWith(`Country code for IP address ${ipAddress} is Local Host`);
        expect(fs.writeFileSync).toHaveBeenCalled();
    });

    test('should handle rate limit error (429) gracefully', async () => {
        axios.get.mockRejectedValue({ status: 429 });

        const result = await getCountryFromIP('82.65.212.233');

        expect(result).toBeNull();
        expect(logger.error).toHaveBeenCalledWith("Error while getting country from IP: Rate limit exceeded");
    });

    test('should handle other errors gracefully', async () => {
        const error = new Error('Network Error');
        axios.get.mockRejectedValue(error);

        const result = await getCountryFromIP('82.65.212.233');

        expect(result).toBeNull();
        expect(logger.error).toHaveBeenCalledWith("Error while getting country from IP", error);
    });
});
