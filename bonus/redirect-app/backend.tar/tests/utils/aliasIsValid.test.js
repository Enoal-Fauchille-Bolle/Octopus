const aliasIsValid = require('../../src/utils/aliasIsValid');

describe('aliasIsValid', () => {

    test('valid alias', () => {
        expect(aliasIsValid('validAlias123', 3, 15)).toBe(true);
    });

    test('invalid alias special chars', () => {
        expect(aliasIsValid('invalid@Alias!', 3, 15)).toBe(false);
    });

    test('alias too short', () => {
        expect(aliasIsValid('sh', 3, 15)).toBe(false);
    });

    test('alias too long', () => {
        expect(aliasIsValid('ThisAliasIsWayTooLongForValidation', 3, 15)).toBe(false);
    });

    test('valid alias with underscores and dashes', () => {
        expect(aliasIsValid('valid_alias-123', 3, 15)).toBe(true);
    });

    test('empty alias', () => {
        expect(aliasIsValid('', 3, 15)).toBe(false);
    });

    test('alias min length', () => {
        expect(aliasIsValid('abc', 3, 15)).toBe(true);
    });

    test('alias max length', () => {
        expect(aliasIsValid('a'.repeat(15), 3, 15)).toBe(true);
    });

    test('alias min-1 length', () => {
        expect(aliasIsValid('ab', 3, 15)).toBe(false);
    });

    test('alias max+1 length', () => {
        expect(aliasIsValid('a'.repeat(16), 3, 15)).toBe(false);
    });

    test('alias accented chars', () => {
        expect(aliasIsValid('álias', 3, 15)).toBe(false);
    });

    test('alias with spaces', () => {
        expect(aliasIsValid('alias with space', 3, 15)).toBe(false);
    });

    test('large max length', () => {
        expect(aliasIsValid('a'.repeat(1000), 1, 1000)).toBe(true);
    });

    test('alias > large max length', () => {
        expect(aliasIsValid('a'.repeat(1001), 1, 1000)).toBe(false);
    });

    test('empty alias with minLength 0', () => {
        expect(aliasIsValid('', 0, 15)).toBe(false);
    });

    test('non-empty alias with maxLength 0', () => {
        expect(aliasIsValid('alias', 0, 0)).toBe(false);
    });

    test('undefined alias', () => {
        expect(aliasIsValid(undefined, 3, 15)).toBe(false);
    });

    test('null alias', () => {
        expect(aliasIsValid(null, 3, 15)).toBe(false);
    });

});
