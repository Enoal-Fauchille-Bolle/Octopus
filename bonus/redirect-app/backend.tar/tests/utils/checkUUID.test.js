const checkUUID = require('../../src/utils/checkUUID');

describe("UUID Validation", () => {

    test("valid UUID v4 (lowercase)", () => {
        expect(checkUUID("123e4567-e89b-42d3-a456-556642440000")).toBe(true);
    });

    test("valid UUID v4 (uppercase)", () => {
        expect(checkUUID("123E4567-E89B-42D3-A456-556642440000")).toBe(true);
    });

    test("invalid UUID (non-hex characters)", () => {
        expect(checkUUID("123e4567-e89b-42d3-a456-zzzzzzzzzzzz")).toBe(false);
    });

    test("too long UUID", () => {
        expect(checkUUID("123e4567-e89b-42d3-a456-55664244000012345")).toBe(false);
    });

    test("too short UUID", () => {
        expect(checkUUID("123e4567-e89b-42d3-a456-55664244000")).toBe(false);
    });

    test("extra hyphens", () => {
        expect(checkUUID("123e-4567-e89b-42d3-a456-556642440000")).toBe(false);
    });

    test("incorrect section length", () => {
        expect(checkUUID("123e4567-e89b-42d3-aaa-556642440000")).toBe(false);
    });

    test("invalid version", () => {
        expect(checkUUID("123e4567-e89b-12d3-a456-556642440000")).toBe(false);
    });

    test("null input", () => {
        expect(checkUUID(null)).toBe(false);
    });

    test("undefined input", () => {
        expect(checkUUID(undefined)).toBe(false);
    });
});
