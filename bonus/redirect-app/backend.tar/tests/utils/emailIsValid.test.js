const emailIsValid = require('../../src/utils/emailIsValid');

describe("Email Validation", () => {

    test("valid lowercase", () => {
        expect(emailIsValid("test@example.com")).toBe(true);
    });

    test("valid uppercase", () => {
        expect(emailIsValid("TEST@EXAMPLE.COM")).toBe(true);
    });

    test("valid with numbers", () => {
        expect(emailIsValid("user123@example123.com")).toBe(true);
    });

    test("valid with subdomain", () => {
        expect(emailIsValid("user@mail.example.com")).toBe(true);
    });

    test("valid with hyphen", () => {
        expect(emailIsValid("user@sub-domain.example.com")).toBe(true);
    });

    test("valid with dots", () => {
        expect(emailIsValid("first.last@example.com")).toBe(true);
    });

    test("valid with dot before '@'", () => {
        expect(emailIsValid("user.name@domain.com")).toBe(true);
    });

    test("valid with special chars", () => {
        expect(emailIsValid("user+test@example.com")).toBe(true);
    });

    test("valid with long domain", () => {
        expect(emailIsValid("user@verylongdomainname.com")).toBe(true);
    });

    test("valid with number in domain", () => {
        expect(emailIsValid("user@example123.com")).toBe(true);
    });

    test("valid with country code", () => {
        expect(emailIsValid("user@example.co.uk")).toBe(true);
    });

    test("no '@'", () => {
        expect(emailIsValid("userexample.com")).toBe(false);
    });

    test("space before '@'", () => {
        expect(emailIsValid("user @example.com")).toBe(false);
    });

    test("space after '@'", () => {
        expect(emailIsValid("user@ example.com")).toBe(false);
    });

    test("multiple '@'", () => {
        expect(emailIsValid("user@@example.com")).toBe(false);
    });

    test("missing domain", () => {
        expect(emailIsValid("user@.com")).toBe(false);
    });

    test("empty local part", () => {
        expect(emailIsValid("@example.com")).toBe(false);
    });

    test("no TLD", () => {
        expect(emailIsValid("user@example")).toBe(false);
    });

    test("special chars in domain", () => {
        expect(emailIsValid("user@exam@ple.com")).toBe(false);
    });

    test("multiple dots in domain", () => {
        expect(emailIsValid("user@ex..ample.com")).toBe(false);
    });

    test("consecutive dots", () => {
        expect(emailIsValid("user..name@example.com")).toBe(false);
    });

    test("spaces in domain", () => {
        expect(emailIsValid("user@ex ample.com")).toBe(false);
    });

    test("only numbers", () => {
        expect(emailIsValid("12345@67890.com")).toBe(true);
    });

    test("valid country code", () => {
        expect(emailIsValid("user@domain.co")).toBe(true);
    });

    test("missing TLD", () => {
        expect(emailIsValid("user@domain.")).toBe(false);
    });

    test("no '@' and domain", () => {
        expect(emailIsValid("user.com")).toBe(false);
    });

    test("null", () => {
        expect(emailIsValid(null)).toBe(false);
    });

    test("undefined", () => {
        expect(emailIsValid(undefined)).toBe(false);
    });

    test("empty string", () => {
        expect(emailIsValid("")).toBe(false);
    });
});
