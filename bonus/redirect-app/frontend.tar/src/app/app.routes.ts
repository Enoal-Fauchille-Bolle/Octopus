import { Routes } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';
import { NoauthGuard } from './guards/noauth.guard';

import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { FullLayoutComponent } from './layout/full/full.component';
import { BlankLayoutComponent } from './layout/blank/blank.component';
import { LoginComponent } from './pages/authentication/login/login.component';
import { NotfoundComponent } from './pages/errors/notfound/notfound.component';
import { RegisterComponent } from './pages/authentication/register/register.component';
import { LogoutComponent } from './pages/authentication/logout/logout.component';
import { ForbiddenComponent } from './pages/errors/forbidden/forbidden.component';
import { ForgotPasswordComponent } from './pages/authentication/forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './pages/authentication/reset-password/reset-password.component';
import { VerifyEmailComponent } from './pages/authentication/verify-email/verify-email.component';
import { SettingsComponent } from './pages/settings/settings.component';
import { BadgatewayComponent } from './pages/errors/badgateway/badgateway.component';
import { RedirectHandlerComponent } from './redirect-handler/redirect-handler.component';
import { UnlockAccountComponent } from './pages/authentication/unlock-account/unlock-account.component';
import { AdminPanelComponent } from './pages/admin-panel/admin-panel.component';
import { AccountComponent } from './pages/account/account.component';
import { RedirectsComponent } from './pages/redirects/redirects.component';
import { RedirectDetailsComponent } from './pages/redirect-details/redirect-details.component';
import { InternalerrorComponent } from './pages/errors/internalerror/internalerror.component';

const routeConfig: Routes = [
    {
        path: '',
        redirectTo: '/dashboard',
        pathMatch: 'full'
    },
    {
        path: 'login',
        title: "AzerDev Redirects - Log in",
        component: BlankLayoutComponent,
        children: [
            {
                path: '',
                component: LoginComponent,
                canActivate: [NoauthGuard],
            }
        ]
    },
    {
        path: 'register',
        title: "AzerDev Redirects - Register",
        component: BlankLayoutComponent,
        children: [
            {
                path: '',
                component: RegisterComponent,
                canActivate: [NoauthGuard],
            }
        ]
    },
    {
        path: 'logout',
        title: "AzerDev Redirects - Log out",
        component: BlankLayoutComponent,
        children: [
            {
                path: '',
                component: LogoutComponent,
            }
        ]
    },
    {
        path: 'forgot-password',
        title: "AzerDev Redirects - Forgot password",
        component: BlankLayoutComponent,
        children: [
            {
                path: '',
                component: ForgotPasswordComponent,
            }
        ]
    },
    {
        path: 'reset-password',
        title: "AzerDev Redirects - Reset password",
        component: BlankLayoutComponent,
        children: [
            {
                path: '',
                component: ResetPasswordComponent,
            }
        ]
    },
    {
        path: 'verify-email',
        title: "AzerDev Redirects - Reset password",
        component: BlankLayoutComponent,
        children: [
            {
                path: '',
                component: VerifyEmailComponent,
            }
        ]
    },
    {
        path: 'unlock-account',
        title: "AzerDev Redirects - Unlock account",
        component: BlankLayoutComponent,
        children: [
            {
                path: '',
                component: UnlockAccountComponent,
            }
        ]
    },
    {
        path: '',
        component: FullLayoutComponent,
        children: [
            {
                path: 'dashboard',
                title: "AzerDev Redirects - Dashboard",
                component: DashboardComponent,
                canActivate: [AuthGuard],
            },
            {
                path: 'redirects',
                title: "AzerDev Redirects - Redirects",
                component: RedirectsComponent,
                canActivate: [AuthGuard],
            },
            {
                path: 'redirects/:id',
                title: "AzerDev Redirects - Redirect details",
                component: RedirectDetailsComponent,
                canActivate: [AuthGuard],
            },
            {
                path: 'admin',
                title: "AzerDev Redirects - Admin panel",
                component: AdminPanelComponent,
                canActivate: [AuthGuard],
            },
            {
                path: 'account',
                title: "AzerDev Redirects - Account",
                component: AccountComponent,
                canActivate: [AuthGuard],
            },
            {
                path: 'settings',
                title: "AzerDev Redirects - Settings",
                component: SettingsComponent,
                canActivate: [AuthGuard],
            },
        ]
    },
    {
        path: 'forbidden',
        title: "AzerDev Redirects - Forbidden",
        pathMatch: 'full',
        component: ForbiddenComponent
    },
    {
        path: 'bad-gateway',
        title: "AzerDev Redirects - Bad gateway",
        pathMatch: 'full',
        component: BadgatewayComponent
    },
    {
        path: 'internal-error',
        title: "AzerDev Redirects - Internal error",
        pathMatch: 'full',
        component: InternalerrorComponent
    },
    {
        path: 'notfound',
        title: "AzerDev Redirects - Not found",
        pathMatch: 'full',
        component: NotfoundComponent
    },
    {
        path: 'r/:redirectId',
        title: "AzerDev Redirects",
        component: RedirectHandlerComponent,
    },
    {
        path: '**',
        title: "AzerDev Redirects - Not found",
        pathMatch: 'full',
        component: NotfoundComponent
    },
];

export default routeConfig;

