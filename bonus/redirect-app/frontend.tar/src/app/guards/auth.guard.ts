import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthService } from '../services/auth/auth.service';
import { UserService } from '../services/user/user.service';

@Injectable({
    providedIn: 'root',
})
export class AuthGuard implements CanActivate {

    constructor(private authService: AuthService, private userService: UserService, private router: Router) { }

    async canActivate(): Promise<boolean> {
        const user = await this.authService.getUser();
        if (this.authService.isAuthenticated() && user) {
            this.userService.setUser(user);
            return true;
        } else {
            this.router.navigate(['/login']);
            return false;
        }
    }
}
