import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';

export const AuthInterceptor: HttpInterceptorFn = (req, next) => {
    const router = inject(Router);

    return next(req).pipe(
        catchError((error: any) => {
            if (error.status === 401) {
                localStorage.removeItem('auth-token');
                router.navigate(['/login']);
            } else if (error.status === 403) {
                // router.navigate(['/forbidden']);
            } else if (error.status === 502 || (error.status === 0 && error.message.includes('Unknown Error'))) {
                router.navigate(['/bad-gateway']);
            }

            return throwError(() => error);
        })
    );
};
