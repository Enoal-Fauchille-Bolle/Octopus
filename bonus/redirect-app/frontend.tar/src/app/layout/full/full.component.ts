import { Component } from '@angular/core';
import { NavbarComponent } from './navbar/navbar.component';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [NavbarComponent, RouterOutlet, HeaderComponent, FooterComponent],
  templateUrl: './full.component.html',
  styleUrl: './full.component.css'
})
export class FullLayoutComponent {

}
