import { Component, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatToolbarModule } from '@angular/material/toolbar';
import { ResendEmailComponent } from "./resend-email/resend-email.component";
import { TranslatePipe, TranslateService } from "@ngx-translate/core";
import { LanguageService } from '../../../services/language/language.service';
import { trigger, transition, style, animate } from '@angular/animations';
import { MatIconModule } from '@angular/material/icon';
import { ThemeService } from '../../../services/theme/theme.service';
import { RouterModule } from '@angular/router';
import { UserService } from '../../../services/user/user.service';
import { MatTooltipModule, MatTooltip } from '@angular/material/tooltip';

@Component({
    selector: 'app-header',
    standalone: true,
    imports: [
        CommonModule,
        RouterModule,
        TranslatePipe,
        MatToolbarModule,
        ResendEmailComponent,
        MatIconModule,
        MatTooltipModule,
    ],
    templateUrl: './header.component.html',
    styleUrl: './header.component.css',
    animations: [
        trigger('menuState', [
            transition(':enter', [
                style({ opacity: 0, transform: 'translateY(-10px)' }),
                animate('0.1s', style({ opacity: 1, transform: 'translateY(0)' }))
            ]),
            transition(':leave', [
                animate('0.1s', style({ opacity: 0, transform: 'translateY(-10px)' }))
            ])
        ])
    ]
})
export class HeaderComponent {
    languages = [
        { code: 'en', name: 'EN', flag: 'assets/english.png' },
        { code: 'fr', name: 'FR', flag: 'assets/french.png' },
    ];
    selectedLanguage = this.languages[0];
    languageMenuVisible: boolean = false;
    userMenuVisible: boolean = false;
    darkMode: boolean;
    user: any;

    constructor(
        private languageService: LanguageService,
        private themeService: ThemeService,
        private userService: UserService,
    ) { }

    ngOnInit(): void {
        this.selectedLanguage = this.languages.find(
            (lang) => lang.code === this.languageService.getSavedLanguage()
        ) || this.selectedLanguage;
        this.darkMode = this.themeService.getSavedTheme() === 'dark';
        this.user = this.userService.getUser();
    }

    toggleDropdown() {
        this.languageMenuVisible = !this.languageMenuVisible;
    }

    changeLanguage(language: any) {
        this.selectedLanguage = language;
        this.languageService.setLanguage(language.code);
        this.languageMenuVisible = false;
    }

    toggleTheme() {
        this.darkMode = !this.darkMode;
        this.themeService.setDarkMode(this.darkMode);
    }

    @HostListener('document:click', ['$event'])
    clickOutside(event: MouseEvent) {
        const languageSelector = document.querySelector('.language-selector')!;
        if (!languageSelector?.contains(event.target as Node)) {
            this.languageMenuVisible = false;
        }
        const userProfile = document.querySelector('.user-profile')!;
        if (!userProfile?.contains(event.target as Node)) {
            this.userMenuVisible = false;
        }
    }

    toggleUserMenu() {
        this.userMenuVisible = !this.userMenuVisible;
    }

    getUserInitials(username: string): string {
        return username.split(' ').map(part => part[0].toUpperCase()).join('').slice(0, 2);
    }

    getUserColor(username: string): string {
        // const colors = ['#FF5733', '#33FF57', '#3357FF', '#F3FF33', '#FF33A8'];
        // const colors = ['#6E85D3', '#E84545', '#41AF7D', '#F2A119', '#707B89'];
        const colors = ['#6E85D3', '#E84545', '#41AF7D', '#F2A119'];
        let hash = 0;
        for (let i = 0; i < username.length; i++) {
            hash = username.charCodeAt(i) + ((hash << 5) - hash);
        }
        return colors[Math.abs(hash % colors.length)];
    }
}
