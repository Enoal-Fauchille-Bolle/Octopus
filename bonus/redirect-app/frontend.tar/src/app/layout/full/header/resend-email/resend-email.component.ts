import { Component, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatToolbarModule } from '@angular/material/toolbar';
import { AuthService } from '../../../../services/auth/auth.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { RecaptchaModule, RecaptchaComponent } from 'ng-recaptcha';
import { environment } from '../../../../../environments/environment';
import { UserService } from '../../../../services/user/user.service';

@Component({
    selector: 'app-resend-email',
    standalone: true,
    imports: [
        CommonModule,
        MatToolbarModule,
        RecaptchaModule,
    ],
    templateUrl: './resend-email.component.html',
    styleUrl: './resend-email.component.css'
})
export class ResendEmailComponent {
    @ViewChild('captchaRef') captchaRef: RecaptchaComponent;
    emailNotVerified: boolean = false;
    isLoading: boolean = false;
    user: any;

    recaptchaEnabled: boolean = environment.enableRecaptchaResendEmailVerification;
    siteKey = "6LdsRHUqAAAAAF5NOmH_V-5mj5XNbb4DuF_aC-om";
    recaptchaToken: string | null = null;
    recaptchaResetInProgress: boolean = false;

    constructor(private authService: AuthService, private userService: UserService, private snackBar: MatSnackBar) { }

    ngOnInit(): void {
        this.user = this.userService.getUser();
        if (!this.user.email_verified) {
            this.emailNotVerified = true;
        }
    }

    openSuccessSnackBar(message: string, action: string | undefined, delay: number | undefined): void {
        this.snackBar.open(message, action, {
            duration: delay,
            horizontalPosition: 'right',
            verticalPosition: 'bottom',
            panelClass: ['success-snackbar']
        });
    }

    openErrorSnackBar(message: string, action: string | undefined, delay: number | undefined): void {
        this.snackBar.open(message, action, {
            duration: delay,
            horizontalPosition: 'right',
            verticalPosition: 'bottom',
            panelClass: ['error-snackbar']
        });
    }

    resendEmailVerification(): void {
        this.isLoading = true;
        this.authService.resendVerificationEmail(this.user.email, this.recaptchaToken).subscribe({
            next: () => {
                this.isLoading = false;
                this.openSuccessSnackBar('Email verification sent', 'Close', undefined);
                if (this.recaptchaEnabled) {
                    setTimeout(() => {
                        this.recaptchaResetInProgress = true;
                        this.captchaRef.reset();
                    }, 500);
                }
            },
            error: (error) => {
                this.isLoading = false;
                if (this.recaptchaEnabled) {
                    setTimeout(() => {
                        this.recaptchaResetInProgress = true;
                        this.captchaRef.reset();
                    }, 500);
                }
                if (error.status === 429) {
                    this.openErrorSnackBar(error?.error?.error || 'Please wait before sending another email verification', 'Close', undefined);
                    return;
                }
                if (error.status == 403 && error.error.recaptcha_failed) {
                    this.openErrorSnackBar(error.error.error, 'Close', undefined);
                    return;
                }
                this.openErrorSnackBar('An error occurred while sending email verification', 'Close', undefined);
            }
        });
    }

    resolved(recaptchaResponse: string) {
        if (this.recaptchaResetInProgress) {
            this.recaptchaResetInProgress = false;
            return;
        }
        this.recaptchaToken = recaptchaResponse;
        this.resendEmailVerification();
    }

    resendEmailVerificationSubmit() {
        if (this.recaptchaEnabled) {
            this.captchaRef.execute();
        } else {
            this.resendEmailVerification();
        }
    }
}
