import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { RouterLinkActive, RouterLink } from '@angular/router';
import { TranslatePipe } from "@ngx-translate/core";
import { UserService } from '../../../services/user/user.service';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
    selector: 'app-navbar',
    standalone: true,
    imports: [
        CommonModule,
        RouterModule,
        RouterLinkActive,
        RouterLink,
        TranslatePipe,
        MatIconModule,
    ],
    templateUrl: './navbar.component.html',
    styleUrl: './navbar.component.css'
})
export class NavbarComponent {
    user: any;

    constructor(
        private userService: UserService,
    ) { }

    ngOnInit(): void {
        this.user = this.userService.getUser();
    }
}
