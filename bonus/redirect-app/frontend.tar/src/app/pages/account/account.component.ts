import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormsModule, Validators } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { UserService } from '../../services/user/user.service';
import { TranslatePipe, TranslateService, _ } from '@ngx-translate/core';
import { MatSnackBar } from '@angular/material/snack-bar';

/**
 * export class YourComponent {
  constructor(private translate: TranslateService) {
    this.translate.get(_('app.hello'), {value: 'world'}).subscribe((res: string) => {
      console.log(res);
      //=> 'hello world'
    });
  }
}
 */

@Component({
    selector: 'app-account',
    standalone: true,
    imports: [
        CommonModule,
        MatCardModule,
        MatIconModule,
        TranslatePipe,
        ReactiveFormsModule,
    ],
    templateUrl: './account.component.html',
    styleUrl: './account.component.css'
})
export class AccountComponent {
    isLoading: boolean = true;
    user: any;
    errorMessage: string | null = null;

    profileForm: FormGroup;
    isUsernameFocused: boolean = false;
    isEmailFocused: boolean = false;
    invalidUsername: boolean = false;
    invalidEmail: boolean = false;
    isUpdatingProfile: boolean = false;

    passwordForm: FormGroup;
    isOldPasswordFocused: boolean = false;
    isNewPasswordFocused: boolean = false;
    isNewPasswordRepeatFocused: boolean = false;
    invalidOldPassword: boolean = false;
    invalidNewPassword: boolean = false;
    invalidNewPasswordRepeat: boolean = false;
    oldPasswordVisible: boolean = false;
    newPasswordVisible: boolean = false;
    newPasswordRepeatVisible: boolean = false;
    isUpdatingPassword: boolean = false;

    constructor(
        private userService: UserService,
        private fb: FormBuilder,
        private snackBar: MatSnackBar,
        private translate: TranslateService,
    ) {
        this.profileForm = this.fb.group({
            username: ['', [Validators.required]],
            email: ['', [Validators.required, Validators.email]],
        });
        this.passwordForm = this.fb.group({
            oldPassword: ['', [Validators.required]],
            newPassword: ['', [Validators.required]],
            newPasswordRepeat: ['', [Validators.required]],
        });
    }

    ngOnInit(): void {
        this.user = this.userService.getUser();
        this.isLoading = false;
        this.profileForm.patchValue({
            email: this.user.email,
            username: this.user.username,
        });
    }

    onInputFocus(input: string): void {
        if (input === 'email') {
            this.isEmailFocused = true;
            this.invalidEmail = false;
        } else if (input === 'username') {
            this.isUsernameFocused = true;
            this.invalidUsername = false;
        }
    }

    onInputBlur(input: string): void {
        if (input === 'email') {
            this.isEmailFocused = false;
        } else if (input === 'username') {
            this.isUsernameFocused = false;
        }
    }

    openSuccessSnackBar(message: string, action: string | undefined, delay: number | undefined): void {
        this.snackBar.open(message, action, {
            duration: delay,
            horizontalPosition: 'right',
            verticalPosition: 'bottom',
            panelClass: ['success-snackbar']
        });
    }

    openErrorSnackBar(message: string, action: string | undefined, delay: number | undefined): void {
        this.snackBar.open(message, action, {
            duration: delay,
            horizontalPosition: 'right',
            verticalPosition: 'bottom',
            panelClass: ['error-snackbar']
        });
    }

    onSubmitProfile() {
        this.errorMessage = null;
        if (!this.profileForm.valid) {
            this.invalidEmail = true;
            this.invalidUsername = true;
            return;
        }
        this.isUpdatingProfile = true;

        let username = this.profileForm.value.username;
        let email = this.profileForm.value.email;

        // If the username and email are the same as the current user's, don't update
        if (username === this.user.username && email === this.user.email) {
            setTimeout(() => {
                this.isUpdatingProfile = false;
            }, 100);
            return;
        }
        // If the username or email are the same as the current user's, don't update
        if (username === this.user.username) {
            username = null;
        }
        // If the username or email are the same as the current user's, don't update
        if (email === this.user.email) {
            email = null;
        }

        this.userService.updateUserProfile(
            username,
            email,
        ).subscribe({
            next: (response) => {
                this.userService.setUser(response);
                this.user = response;
                this.isUpdatingProfile = false;
                this.translate.get('pages.account.profile.update-success').subscribe((res: string) => {
                    this.openSuccessSnackBar(res, 'Close', 5000);
                });
            },
            error: (error) => {
                console.error(error);
                this.errorMessage = error.error.message;
                this.isUpdatingProfile = false;
            }
        });
    }

    togglePasswordVisibility(type: string): void {
        if (type === "oldPassword") {
            this.oldPasswordVisible = !this.oldPasswordVisible;
        } else if (type === "newPassword") {
            this.newPasswordVisible = !this.newPasswordVisible;
        } else if (type === "newPasswordRepeat") {
            this.newPasswordRepeatVisible = !this.newPasswordRepeatVisible;
        }
    }

    onSubmitPassword() {
        this.errorMessage = null;
        if (!this.passwordForm.valid) {
            this.invalidOldPassword = true;
            this.invalidNewPassword = true;
            this.invalidNewPasswordRepeat = true;
            return;
        }
        this.isUpdatingPassword = true;

        let oldPassword = this.passwordForm.value.oldPassword;
        let newPassword = this.passwordForm.value.newPassword;
        let newPasswordRepeat = this.passwordForm.value.newPasswordRepeat;

        console.log(oldPassword, newPassword, newPasswordRepeat);

        // this.userService.updateUserProfile(
        //     username,
        //     email,
        // ).subscribe({
        //     next: (response) => {
        //         this.userService.setUser(response);
        //         this.user = response;
        //         this.isUpdatingProfile = false;
        //         this.translate.get('pages.account.profile.update-success').subscribe((res: string) => {
        //             this.openSuccessSnackBar(res, 'Close', 5000);
        //         });
        //     },
        //     error: (error) => {
        //         console.error(error);
        //         this.errorMessage = error.error.message;
        //         this.isUpdatingProfile = false;
        //     }
        // });
    }
}
