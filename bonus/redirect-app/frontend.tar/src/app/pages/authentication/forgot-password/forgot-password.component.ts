import { Component, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { RouterModule, Router } from '@angular/router';
import { AuthService } from '../../../services/auth/auth.service';
import { RecaptchaModule, RecaptchaComponent } from 'ng-recaptcha';
import { environment } from '../../../../environments/environment';

@Component({
    selector: 'app-forgot-password',
    standalone: true,
    imports: [
        CommonModule,
        RouterModule,
        ReactiveFormsModule,
        MatCardModule,
        MatCheckboxModule,
        MatButtonModule,
        MatFormFieldModule,
        MatInputModule,
        RecaptchaModule,
    ],
    templateUrl: './forgot-password.component.html',
    styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent {
    @ViewChild('captchaRef') captchaRef: RecaptchaComponent;
    forgotPasswordForm: FormGroup;
    errorMessage: string | null = null;
    successMessage: string | null = null;
    isLoading = false;
    isEmailFocused: boolean = false;
    invalidEmail = false;

    recaptchaEnabled: boolean = environment.enableRecaptchaForgotPassword;
    siteKey = environment.recaptchaNormalSiteKey;
    recaptchaToken: string | null = null;

    constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {
        this.forgotPasswordForm = this.fb.group({
            email: ['', [Validators.required, Validators.email]],
        });
    }

    resolved(captchaResponse: string) {
        this.recaptchaToken = captchaResponse;
    }

    onSubmit() {
        const email = this.forgotPasswordForm.get('email')?.value;
        this.errorMessage = null;
        this.successMessage = null;

        if (!this.forgotPasswordForm.valid) {
            this.invalidEmail = true;
            return;
        }

        this.isLoading = true;
        this.authService.forgotPassword(email, this.recaptchaToken).subscribe({
            next: (response) => {
                this.isLoading = false;
                this.successMessage = response.message;
                if (this.recaptchaEnabled) {
                    this.captchaRef.reset();
                }
            },
            error: (error) => {
                this.errorMessage = error?.error?.error || "Erreur lors de la connexion";
                this.isLoading = false;
                if (this.recaptchaEnabled) {
                    this.captchaRef.reset();
                }
            }
        });
    }

    setRememberMe(email: string) {
        localStorage.setItem('email', email);
        localStorage.setItem('rememberMe', 'true');
    }

    clearRememberMe() {
        localStorage.removeItem('email');
        localStorage.removeItem('rememberMe');
    }


    onInputFocus(input: string): void {
        if (input === 'email') {
            this.isEmailFocused = true;
            this.invalidEmail = false;
        }
    }

    onInputBlur(input: string): void {
        if (input === 'email') {
            this.isEmailFocused = false;
        }
    }
}
