import { Component, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { RouterModule, Router } from '@angular/router';
import { AuthService } from '../../../services/auth/auth.service';
import { RecaptchaModule, RecaptchaComponent } from 'ng-recaptcha';
import { environment } from '../../../../environments/environment';
import { TranslatePipe } from '@ngx-translate/core';

@Component({
    selector: 'app-login',
    standalone: true,
    imports: [
        CommonModule,
        RouterModule,
        ReactiveFormsModule,
        MatCardModule,
        MatCheckboxModule,
        MatButtonModule,
        MatFormFieldModule,
        MatInputModule,
        RecaptchaModule,
        FormsModule,
        TranslatePipe,
    ],
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss']
})
export class LoginComponent {
    @ViewChild('captchaRef') captchaRef: RecaptchaComponent;
    loginForm: FormGroup;
    mfaForm: FormGroup;
    errorMessage: string | null = null;
    passwordVisible: boolean = false;
    isLoading: boolean = false;
    isEmailFocused: boolean = false;
    isPasswordFocused: boolean = false;
    isMfaCodeFocused: boolean = false;
    invalidEmail: boolean = false;
    invalidPassword: boolean = false;
    invalidMfaCode: boolean = false;

    recaptchaEnabled: boolean = environment.enableRecaptchaLogin;
    siteKey = environment.recaptchaInvisibleSiteKey;
    recaptchaToken: string | null = null;
    recaptchaResetInProgress: boolean = false;

    showMfa: boolean = false;

    constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {
        this.loginForm = this.fb.group({
            email: ['', [Validators.required, Validators.email]],
            password: ['', [Validators.required]],
            rememberMe: [false, [Validators.required]]
        });
        this.mfaForm = this.fb.group({
            code: ['', [Validators.required, Validators.pattern('^[0-9]{6}$')]],
            backupCode: [false, [Validators.required]]
        });
    }

    login() {
        const email = this.loginForm.get('email')?.value;
        const password = this.loginForm.get('password')?.value;
        const rememberMe = this.loginForm.get("rememberMe")?.value;
        const mfaCode = this.mfaForm.get('code')?.value?.toString();

        this.isLoading = true;
        this.authService.login(email, password, rememberMe, this.recaptchaToken, mfaCode).subscribe({
            next: (response) => {
                this.authService.storeToken(response.token);
                this.router.navigate(['/dashboard']);
            },
            error: (error) => {
                this.isLoading = false;
                if (error.error.mfa) {
                    this.showMfa = true;
                    return;
                }
                this.errorMessage = error?.error?.error || "Erreur lors de la connexion";
                if (this.recaptchaEnabled) {
                    setTimeout(() => {
                        this.recaptchaResetInProgress = true;
                        this.captchaRef.reset();
                    }, 500);
                }
            }
        });

        if (rememberMe) {
            this.setRememberMe(email);
        } else {
            this.clearRememberMe();
        }

    }

    resolved(recaptchaResponse: string) {
        if (this.recaptchaResetInProgress) {
            this.recaptchaResetInProgress = false;
            return;
        }
        this.recaptchaToken = recaptchaResponse;
        this.login();
    }

    onSubmit() {
        this.errorMessage = null;
        if (!this.loginForm.valid) {
            this.invalidEmail = true;
            this.invalidPassword = true;
            return;
        }

        if (this.recaptchaEnabled) {
            this.captchaRef.execute();
        } else {
            this.login();
        }
    }

    onSubmitMfa() {
        this.errorMessage = null;
        if (!this.mfaForm.valid) {
            this.invalidMfaCode = true;
            return;
        }

        this.login();
    }

    setRememberMe(email: string) {
        localStorage.setItem('email', email);
        localStorage.setItem('rememberMe', 'true');
    }

    clearRememberMe() {
        localStorage.removeItem('email');
        localStorage.removeItem('rememberMe');
    }

    ngOnInit() {
        if (!window.grecaptcha) {
            console.error("Google reCAPTCHA script not loaded.");
        }
    }

    ngAfterViewInit() {
        const rememberMe = localStorage.getItem('rememberMe');
        this.loginForm.patchValue({ rememberMe: rememberMe === 'true' });
        if (rememberMe === 'true' && this.showMfa === false) {
            const email = localStorage.getItem('email');
            if (email) {
                this.loginForm.patchValue({ email });
            }
        }
    }

    togglePasswordVisibility() {
        this.passwordVisible = !this.passwordVisible;
    }

    onInputFocus(input: string): void {
        if (input === 'email') {
            this.isEmailFocused = true;
            this.invalidEmail = false;
        } else if (input === 'password') {
            this.isPasswordFocused = true;
            this.invalidPassword = false;
        } else if (input === 'mfaCode') {
            this.isMfaCodeFocused = true;
            this.invalidMfaCode = false;
        }
    }

    onInputBlur(input: string): void {
        if (input === 'email') {
            this.isEmailFocused = false;
        } else if (input === 'password') {
            this.isPasswordFocused = false;
        } else if (input === 'mfaCode') {
            this.isMfaCodeFocused = false;
        }
    }

    backupCodeCheckboxChange(values: any): void {
        const checked = values.currentTarget.checked
        const mfaCodeInput = document.getElementById('mfaCodeInput') as HTMLInputElement;

        if (checked) {
            mfaCodeInput.placeholder = "12345678";
            mfaCodeInput.maxLength = 8;
            this.mfaForm.get('code')?.setValidators([Validators.required, Validators.pattern('^[0-9]{8}$')]);
        } else {
            mfaCodeInput.placeholder = "123456"
            mfaCodeInput.maxLength = 6;
            mfaCodeInput.value = mfaCodeInput.value.slice(0, 6);
            this.mfaForm.get('code')?.setValidators([Validators.required, Validators.pattern('^[0-9]{6}$')]);
        }
    }
}
