import { Component, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { RouterModule, Router } from '@angular/router';
import { AuthService } from '../../../services/auth/auth.service';
import { RecaptchaModule, RecaptchaComponent } from 'ng-recaptcha';
import { environment } from '../../../../environments/environment';
import { TranslatePipe } from '@ngx-translate/core';

@Component({
    selector: 'app-register',
    standalone: true,
    imports: [
        CommonModule,
        RouterModule,
        ReactiveFormsModule,
        MatCardModule,
        MatCheckboxModule,
        MatButtonModule,
        MatFormFieldModule,
        MatInputModule,
        RecaptchaModule,
        TranslatePipe,
    ],
    templateUrl: './register.component.html',
    styleUrls: ['./register.component.scss']
})
export class RegisterComponent {
    @ViewChild('captchaRef') captchaRef: RecaptchaComponent;
    registerForm: FormGroup;
    errorMessage: string | null = null;
    passwordVisible: boolean = false;
    isLoading = false;
    isUsernameFocused: boolean = false;
    isEmailFocused: boolean = false;
    isPasswordFocused: boolean = false;
    invalidUsername = false;
    invalidEmail = false;
    invalidPassword = false;

    recaptchaEnabled: boolean = environment.enableRecaptchaRegister;
    siteKey = environment.recaptchaNormalSiteKey;
    recaptchaToken: string | null = null;

    constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {
        this.registerForm = this.fb.group({
            email: ['', [Validators.required, Validators.email]],
            username: ['', [Validators.required]],
            password: ['', [Validators.required]]
        });
    }

    resolved(captchaResponse: string) {
        this.recaptchaToken = captchaResponse;
    }

    onSubmit() {
        const email = this.registerForm.get('email')?.value;
        const username = this.registerForm.get('username')?.value;
        const password = this.registerForm.get('password')?.value;

        this.errorMessage = null;
        if (!this.registerForm.valid) {
            this.invalidEmail = true;
            this.invalidUsername = true;
            this.invalidPassword = true;
            return;
        }

        this.isLoading = true;
        this.authService.register(email, username, password, this.recaptchaToken).subscribe({
            next: (response) => {
                this.isLoading = false;
                this.authService.storeToken(response.token);
                this.router.navigate(['/dashboard']);
            },
            error: (error) => {
                this.errorMessage = error.error.error;
                this.isLoading = false;
                if (this.recaptchaEnabled) {
                    this.captchaRef.reset();
                }
            }
        });
    }

    togglePasswordVisibility() {
        this.passwordVisible = !this.passwordVisible;
    }

    onInputFocus(input: string): void {
        if (input === 'email') {
            this.isEmailFocused = true;
            this.invalidEmail = false;
        } else if (input === 'username') {
            this.isUsernameFocused = true;
            this.invalidUsername = false;
        } else if (input === 'password') {
            this.isPasswordFocused = true;
            this.invalidPassword = false
        }
    }

    onInputBlur(input: string): void {
        if (input === 'email') {
            this.isEmailFocused = false;
        } else if (input === 'username') {
            this.isUsernameFocused = false;
        } else if (input === 'password') {
            this.isPasswordFocused = false;
        }
    }
}
