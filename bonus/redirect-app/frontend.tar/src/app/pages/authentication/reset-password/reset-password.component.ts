import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { RouterModule, Router } from '@angular/router';
import { AuthService } from '../../../services/auth/auth.service';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'app-login',
    standalone: true,
    imports: [CommonModule, RouterModule, ReactiveFormsModule, MatCardModule, MatCheckboxModule, MatButtonModule, MatFormFieldModule, MatInputModule],
    templateUrl: './reset-password.component.html',
    styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent {
    resetPasswordForm: FormGroup;
    errorMessage: string | null = null;
    passwordVisible: boolean = false;
    isCheckingResetToken = true;
    isLoading = false;
    isPasswordFocused: boolean = false;
    isRepeatPasswordFocused: boolean = false;
    invalidPassword = false;
    invalidRepeatPassword = false;
    resetToken: string | null = null;
    invalidResetToken = false;

    constructor(private fb: FormBuilder, private authService: AuthService, private router: Router, private route: ActivatedRoute) {
        this.resetPasswordForm = this.fb.group({
            password: ['', [Validators.required]],
            repeatPassword: ['', [Validators.required]]
        });
    }

    ngOnInit(): void {
        this.route.queryParamMap.subscribe(async params => {
            this.resetToken = params.get('token');
            if (!this.resetToken) {
                this.invalidResetToken = true;
                this.isCheckingResetToken = false;
                return;
            }
            if (!await this.authService.checkResetToken(this.resetToken)) {
                this.invalidResetToken = true;
                this.isCheckingResetToken = false;
                return;
            }
            this.isCheckingResetToken = false;
        });
    }

    onSubmit() {
        const password = this.resetPasswordForm.get('password')?.value;
        const repeatPassword = this.resetPasswordForm.get('repeatPassword')?.value;

        this.errorMessage = null;
        if (!this.resetPasswordForm.valid) {
            this.invalidPassword = true;
            this.invalidRepeatPassword = true;
            return;
        }

        if (password !== repeatPassword) {
            this.invalidRepeatPassword = true;
            return;
        }

        if (!this.resetToken) {
            this.invalidResetToken = true;
            return;
        }

        this.isLoading = true;
        this.authService.resetPassword(password, this.resetToken).subscribe({
            next: (response) => {
                this.isLoading = false;
                this.router.navigate(['/login']);
            },
            error: (error) => {
                this.errorMessage = error?.error?.error || "Erreur lors de la connexion";
                this.isLoading = false;
            }
        });
    }

    togglePasswordVisibility() {
        this.passwordVisible = !this.passwordVisible;
    }

    onInputFocus(input: string): void {
        if (input === 'password') {
            this.isPasswordFocused = true;
            this.invalidPassword = false;
        } else if (input === 'repeat-password') {
            this.isRepeatPasswordFocused = true;
            this.invalidRepeatPassword = false;
        }
    }

    onInputBlur(input: string): void {
        if (input === 'password') {
            this.isPasswordFocused = false;
        } else if (input === 'repeat-password') {
            this.isRepeatPasswordFocused = false;
        }
    }
}
