import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { RouterModule, Router } from '@angular/router';
import { AuthService } from '../../../services/auth/auth.service';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'app-unlock-account',
    standalone: true,
    imports: [CommonModule, RouterModule, MatCardModule],
    templateUrl: './unlock-account.component.html',
    styleUrl: './unlock-account.component.css'
})
export class UnlockAccountComponent {
    isCheckingUnlockToken: boolean = true;
    errorMessage: string | null = null;
    successMessage: string | null = null;
    unlockToken: string | null = null;

    constructor(private authService: AuthService, private router: Router, private route: ActivatedRoute) { }

    ngOnInit(): void {
        this.route.queryParamMap.subscribe(async params => {
            this.unlockToken = params.get('token');
            if (!this.unlockToken) {
                this.isCheckingUnlockToken = false;
                this.errorMessage = 'Invalid unlock link, please check your email';
                return;
            }
            this.authService.unlockAccount(this.unlockToken).subscribe({
                next: (response) => {
                    this.isCheckingUnlockToken = false;
                    this.successMessage = response?.message || "Successfull unlocked account";
                },
                error: (error) => {
                    this.isCheckingUnlockToken = false;
                    this.errorMessage = error?.error?.error || "Error while unlocking account";
                }
            });
        });
    }
}
