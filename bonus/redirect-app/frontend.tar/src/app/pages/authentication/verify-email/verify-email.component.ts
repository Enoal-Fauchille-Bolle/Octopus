import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { RouterModule, Router } from '@angular/router';
import { AuthService } from '../../../services/auth/auth.service';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'app-verify-email',
    standalone: true,
    imports: [CommonModule, RouterModule, MatCardModule],
    templateUrl: './verify-email.component.html',
    styleUrl: './verify-email.component.css'
})
export class VerifyEmailComponent {
    isCheckingVerifyToken: boolean = true;
    errorMessage: string | null = null;
    successMessage: string | null = null;
    verifyToken: string | null = null;

    constructor(private authService: AuthService, private router: Router, private route: ActivatedRoute) { }

    ngOnInit(): void {
        this.route.queryParamMap.subscribe(async params => {
            this.verifyToken = params.get('token');
            if (!this.verifyToken) {
                this.isCheckingVerifyToken = false;
                this.errorMessage = 'Invalid verification link, please check your email';
                return;
            }
            this.authService.verifyEmail(this.verifyToken).subscribe({
                next: (response) => {
                    this.isCheckingVerifyToken = false;
                    this.successMessage = response?.message || "Successfull verified email";
                },
                error: (error) => {
                    this.isCheckingVerifyToken = false;
                    this.errorMessage = error?.error?.error || "Error while verifying email";
                }
            });
        });
    }
}
