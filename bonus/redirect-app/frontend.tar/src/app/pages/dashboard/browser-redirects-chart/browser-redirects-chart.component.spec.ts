import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BrowserRedirectsChartComponent } from './browser-redirects-chart.component';

describe('BrowserRedirectsChartComponent', () => {
  let component: BrowserRedirectsChartComponent;
  let fixture: ComponentFixture<BrowserRedirectsChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BrowserRedirectsChartComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BrowserRedirectsChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
