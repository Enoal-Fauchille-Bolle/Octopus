import { Component, ViewChild, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { ChartComponent } from "ng-apexcharts";
import { TranslatePipe } from "@ngx-translate/core";

import {
    NgApexchartsModule,
    ApexNonAxisChartSeries,
    ApexResponsive,
    ApexChart,
    ApexLegend,
    ApexFill,
} from "ng-apexcharts";

export type ChartOptions = {
    series: ApexNonAxisChartSeries;
    chart: ApexChart;
    legend: ApexLegend;
    responsive: ApexResponsive[];
    labels: string[] | undefined;
    fill: ApexFill;
};

@Component({
    selector: 'app-browser-redirects-chart',
    standalone: true,
    imports: [
        CommonModule,
        MatCardModule,
        NgApexchartsModule,
        TranslatePipe,
    ],
    templateUrl: './browser-redirects-chart.component.html',
    styleUrl: './browser-redirects-chart.component.css'
})
export class BrowserRedirectsChartComponent {
    @ViewChild("chart") chart: ChartComponent;
    public chartOptions: Partial<ChartOptions>;
    isLoading: boolean = true;
    series: any = [];
    @Input() stats: any;

    ngOnInit() {
        const interval = setInterval(() => {
            if (this.stats) {
                this.parseStats(this.stats);
                this.isLoading = false;
                clearInterval(interval);
            }
        }, 100);
    }

    parseStats(stats: any) {
        const browserSeries: { [key: string]: number } = {};

        for (const stat of stats) {
            let { browser } = stat;
            if (!browser) {
                browser = "Unknown";
            }
            if (browserSeries[browser]) {
                browserSeries[browser]++;
            } else {
                browserSeries[browser] = 1;
            }
        }

        this.series = browserSeries;
        this.initChartData();
    }

    constructor() {
        this.initChartData();
    }

    public initChartData(): void {
        this.chartOptions = {
            series: Object.values(this.series),
            chart: {
                type: "donut"
            },
            legend: {
                position: "bottom"
            },
            labels: Object.keys(this.series),
            fill: {
                // colors: ['#008BF7', '#00E59A', '#FFB131']
            },
        };
    }
}
