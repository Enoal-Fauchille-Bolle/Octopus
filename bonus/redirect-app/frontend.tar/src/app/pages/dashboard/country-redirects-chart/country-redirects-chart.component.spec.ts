import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CountryRedirectsChartComponent } from './country-redirects-chart.component';

describe('CountryRedirectsChartComponent', () => {
  let component: CountryRedirectsChartComponent;
  let fixture: ComponentFixture<CountryRedirectsChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CountryRedirectsChartComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CountryRedirectsChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
