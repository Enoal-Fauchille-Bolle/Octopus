import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { TotalRedirectsChartComponent } from './total-redirects-chart/total-redirects-chart.component';
import { DeviceRedirectsChartComponent } from './device-redirects-chart/device-redirects-chart.component';
import { OsRedirectsChartComponent } from './os-redirects-chart/os-redirects-chart.component';
import { BrowserRedirectsChartComponent } from './browser-redirects-chart/browser-redirects-chart.component';
import { CountryRedirectsChartComponent } from './country-redirects-chart/country-redirects-chart.component';
import { RedirectsListComponent } from './redirects-list/redirects-list.component';
import { TranslatePipe } from "@ngx-translate/core";

import { RedirectsService } from '../../services/redirects/redirects.service';

@Component({
    selector: 'app-dashboard',
    standalone: true,
    imports: [
        CommonModule,
        MatCardModule,
        TotalRedirectsChartComponent,
        DeviceRedirectsChartComponent,
        OsRedirectsChartComponent,
        BrowserRedirectsChartComponent,
        CountryRedirectsChartComponent,
        RedirectsListComponent,
        TranslatePipe,
    ],
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent {
    stats: any = null;
    redirects: any = null;

    constructor(private redirectsService: RedirectsService) { }

    ngOnInit() {
        this.redirectsService.getStats().subscribe((data: any) => {
            this.stats = data;
        });
        this.redirectsService.getRedirects().subscribe((data: any) => {
            this.redirects = data;
        });
    }
}
