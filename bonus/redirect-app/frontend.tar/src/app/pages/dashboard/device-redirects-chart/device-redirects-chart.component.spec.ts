import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeviceRedirectsChartComponent } from './device-redirects-chart.component';

describe('DeviceRedirectsChartComponent', () => {
  let component: DeviceRedirectsChartComponent;
  let fixture: ComponentFixture<DeviceRedirectsChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DeviceRedirectsChartComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DeviceRedirectsChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
