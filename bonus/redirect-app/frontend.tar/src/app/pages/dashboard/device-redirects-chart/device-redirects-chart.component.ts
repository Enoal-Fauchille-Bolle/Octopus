import { Component, ViewChild, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { ChartComponent } from "ng-apexcharts";
import { TranslatePipe } from "@ngx-translate/core";

import {
    NgApexchartsModule,
    ApexNonAxisChartSeries,
    ApexResponsive,
    ApexChart,
    ApexLegend,
    ApexFill,
} from "ng-apexcharts";

export type ChartOptions = {
    series: ApexNonAxisChartSeries;
    chart: ApexChart;
    legend: ApexLegend;
    responsive: ApexResponsive[];
    labels: string[] | undefined;
    fill: ApexFill;
};

@Component({
    selector: 'app-device-redirects-chart',
    standalone: true,
    imports: [
        CommonModule,
        MatCardModule,
        NgApexchartsModule,
        TranslatePipe,
    ],
    templateUrl: './device-redirects-chart.component.html',
    styleUrl: './device-redirects-chart.component.css'
})
export class DeviceRedirectsChartComponent {
    @ViewChild("chart") chart: ChartComponent;
    @Input() stats: any;
    public chartOptions: Partial<ChartOptions>;
    isLoading: boolean = true;
    series: any = [];

    ngOnInit() {
        const interval = setInterval(() => {
            if (this.stats) {
                this.parseStats(this.stats);
                this.isLoading = false;
                clearInterval(interval);
            }
        }, 100);
    }

    classifyDevice(stat: any): 'Desktop' | 'Mobile' | 'Other' {
        const { os, user_agent } = stat;

        // Check mobile operating systems
        const mobileOS = ['Android', 'iOS'];
        if (mobileOS.includes(os)) {
            return 'Mobile';
        }

        // Check browsers or systems associated with desktops
        const desktopOS = ['Windows', 'MacOS', 'Linux'];
        if (desktopOS.includes(os)) {
            return 'Desktop';
        }

        // Check specific user agents if necessary
        if (/Mobile/i.test(user_agent) || /Tablet/i.test(user_agent)) {
            return 'Mobile';
        }

        return 'Other';
    }

    parseStats(stats: any) {
        const deviceSeries: { Desktop: number; Mobile: number; Other: number } = {
            Desktop: 0,
            Mobile: 0,
            Other: 0
        }

        for (const stat of stats) {
            deviceSeries[this.classifyDevice(stat)]++;
        }

        this.series = deviceSeries;
        this.initChartData();
    }

    constructor() {
        this.initChartData();
    }

    public initChartData(): void {
        this.chartOptions = {
            series: Object.values(this.series),
            chart: {
                type: "donut"
            },
            legend: {
                position: "bottom"
            },
            labels: Object.keys(this.series),
            fill: {
                // colors: ['#008BF7', '#00E59A', '#FFB131', '#FF3E60']
            },
        };
    }
}
