import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OsRedirectsChartComponent } from './os-redirects-chart.component';

describe('OsRedirectsChartComponent', () => {
  let component: OsRedirectsChartComponent;
  let fixture: ComponentFixture<OsRedirectsChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [OsRedirectsChartComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OsRedirectsChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
