import { Component, ViewChild, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { ChartComponent } from "ng-apexcharts";
import { TranslatePipe } from "@ngx-translate/core";

import {
    NgApexchartsModule,
    ApexNonAxisChartSeries,
    ApexResponsive,
    ApexChart,
    ApexLegend,
    ApexFill,
} from "ng-apexcharts";

export type ChartOptions = {
    series: ApexNonAxisChartSeries;
    chart: ApexChart;
    legend: ApexLegend;
    responsive: ApexResponsive[];
    labels: string[] | undefined;
    fill: ApexFill;
};

@Component({
    selector: 'app-os-redirects-chart',
    standalone: true,
    imports: [
        CommonModule,
        MatCardModule,
        NgApexchartsModule,
        TranslatePipe,
    ],
    templateUrl: './os-redirects-chart.component.html',
    styleUrl: './os-redirects-chart.component.css'
})
export class OsRedirectsChartComponent {
    @ViewChild("chart") chart: ChartComponent;
    public chartOptions: Partial<ChartOptions>;
    isLoading: boolean = true;
    series: any = [];
    @Input() stats: any;

    ngOnInit() {
        const interval = setInterval(() => {
            if (this.stats) {
                this.parseStats(this.stats);
                this.isLoading = false;
                clearInterval(interval);
            }
        }, 100);
    }

    parseStats(stats: any) {
        const osSeries: { [key: string]: number } = {};

        for (const stat of stats) {
            let { os } = stat;
            if (!os) {
                os = "Unknown";
            }
            if (osSeries[os]) {
                osSeries[os]++;
            } else {
                osSeries[os] = 1;
            }
        }

        this.series = osSeries;
        this.initChartData();
    }

    constructor() {
        this.initChartData();
    }

    public initChartData(): void {
        this.chartOptions = {
            series: Object.values(this.series),
            chart: {
                type: "donut"
            },
            legend: {
                position: "bottom"
            },
            labels: Object.keys(this.series),
            fill: {
                // colors: ['#008BF7', '#00E59A', '#FFB131']
            },
        };
    }
}
