import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RedirectsListComponent } from './redirects-list.component';

describe('RedirectsListComponent', () => {
  let component: RedirectsListComponent;
  let fixture: ComponentFixture<RedirectsListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RedirectsListComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RedirectsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
