import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { TranslatePipe } from "@ngx-translate/core";

@Component({
  selector: 'app-redirects-list',
  standalone: true,
  imports: [
      CommonModule,
      MatCardModule,
      TranslatePipe,
  ],
  templateUrl: './redirects-list.component.html',
  styleUrl: './redirects-list.component.css'
})
export class RedirectsListComponent {

}
