import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TotalRedirectsChartComponent } from './total-redirects-chart.component';

describe('TotalRedirectsChartComponent', () => {
  let component: TotalRedirectsChartComponent;
  let fixture: ComponentFixture<TotalRedirectsChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TotalRedirectsChartComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TotalRedirectsChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
