import { Component, ViewChild, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { ApexStroke, NgApexchartsModule } from "ng-apexcharts";
import { TranslatePipe } from "@ngx-translate/core";

const sleep = (delay: number) => new Promise((resolve) => setTimeout(resolve, delay))

import {
    ChartComponent,
    ApexAxisChartSeries,
    ApexChart,
    ApexDataLabels,
    ApexFill,
    ApexMarkers,
    ApexYAxis,
    ApexXAxis,
    ApexTooltip
} from "ng-apexcharts";

export type ChartOptions = {
    series: ApexAxisChartSeries;
    chart: ApexChart;
    dataLabels: ApexDataLabels;
    markers: ApexMarkers;
    fill: ApexFill;
    yaxis: ApexYAxis;
    xaxis: ApexXAxis;
    tooltip: ApexTooltip;
    stroke: ApexStroke;
};

function sortObjectByDate(obj: { [key: string]: any }) {
    return Object.keys(obj)
        .sort((a, b) => Date.parse(a) - Date.parse(b))
        .reduce((acc: { [key: string]: number }, key: string) => {
            acc[key] = obj[key];
            return acc;
        }, {})
}

@Component({
    selector: 'app-total-redirects-chart',
    standalone: true,
    imports: [
        CommonModule,
        MatCardModule,
        NgApexchartsModule,
        TranslatePipe,
    ],
    templateUrl: './total-redirects-chart.component.html',
    styleUrl: './total-redirects-chart.component.css'
})
export class TotalRedirectsChartComponent {
    @ViewChild("chart") chart: ChartComponent;
    @Input() stats: any;
    isLoading: boolean = true;
    public chartOptions: Partial<ChartOptions>;
    series: any = [];

    ngOnInit() {
        const interval = setInterval(() => {
            if (this.stats) {
                this.parseStats(this.stats);
                this.isLoading = false;
                clearInterval(interval);
            }
        }, 100);
    }

    parseStats(stats: any) {
        if (stats.length === 0) {
            this.series = [];
            this.initChartData();
            return;
        }

        // Parse the access_time to a date
        stats.map((stat: any) => {
            stat.access_time = Date.parse(stat.access_time);
            stat.access_day = new Date(stat.access_time).toLocaleDateString("en-US");
            return stat;
        })

        // Count the number of redirects by day
        let count: { [key: string]: number } = {};
        stats.forEach((stat: { access_day: string }) => {
            count[stat.access_day] = count[stat.access_day] ? count[stat.access_day] + 1 : 1;
        });

        // Sort the object by date
        count = sortObjectByDate(count);

        // Add missing dates until today
        let currentDate = Object.keys(count)[0];
        const lastDate = new Date().toLocaleDateString("en-US");
        while (currentDate !== lastDate) {
            if (!count[currentDate]) {
                count[currentDate] = 0;
            }
            const newDate = new Date(currentDate);
            currentDate = new Date(newDate.setDate(newDate.getDate() + 1)).toLocaleDateString("en-US");
        }

        // Sort the object by date
        count = sortObjectByDate(count);

        // Transform the object into a series array
        let series = Object.keys(count).map((key: string) => {
            return [Date.parse(key), count[key]];
        });


        this.series = series;

        this.initChartData();
    }

    constructor() {
        this.initChartData();
    }

    public initChartData(): void {
        this.chartOptions = {
            series: [
                {
                    name: "Redirects",
                    data: this.series
                }
            ],
            chart: {
                type: "area",
                stacked: false,
                height: 250,
                width: "100%",
                zoom: {
                    enabled: false,
                },
                toolbar: {
                    show: false
                }
            },
            dataLabels: {
                enabled: false
            },
            markers: {
                size: 4
            },
            // fill: {
            //     type: "gradient",
            //     gradient: {
            //         shadeIntensity: 1,
            //         inverseColors: false,
            //         opacityFrom: 0.5,
            //         opacityTo: 0,
            //         stops: [0, 90, 100]
            //     }
            // },
            // fill: {
            //     type: "solid",
            //     opacity: 0
            // },
            yaxis: {
                title: {
                    text: "Redirects",
                    style: {
                        fontSize: '12px',
                        fontWeight: 'bold',
                        color: '#333',
                        fontFamily: 'Montserrat, sans-serif',
                    },
                }
            },
            xaxis: {
                type: "datetime",
                labels: {
                    format: 'dd MMM',
                    style: {
                        fontWeight: 100,
                    },
                },
            },
            stroke: {
                width: 4,
                curve: 'smooth'
            },
        }
    }
}
