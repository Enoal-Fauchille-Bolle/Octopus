import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { Router } from '@angular/router';

@Component({
    selector: 'app-badgateway',
    standalone: true,
    imports: [CommonModule, MatCardModule],
    templateUrl: './badgateway.component.html',
    styleUrl: './badgateway.component.css'
})
export class BadgatewayComponent {
    constructor(private router: Router) { }

    goBack() {
        localStorage.removeItem('auth-token');
        this.router.navigate(['/login']);
    }
}
