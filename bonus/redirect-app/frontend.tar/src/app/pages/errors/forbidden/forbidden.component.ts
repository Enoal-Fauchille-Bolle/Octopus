import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Location } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { Router } from '@angular/router';

@Component({
    selector: 'app-forbidden',
    standalone: true,
    imports: [CommonModule, MatCardModule],
    templateUrl: './forbidden.component.html',
    styleUrl: './forbidden.component.css'
})
export class ForbiddenComponent {
    // constructor(private _location: Location) { }
    constructor(private router: Router) { }

    goBack() {
        // this._location.back();
        this.router.navigate(['/dashboard']);
    }
}
