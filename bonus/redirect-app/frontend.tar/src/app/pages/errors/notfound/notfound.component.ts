import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Location } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { Router } from '@angular/router';

@Component({
    selector: 'app-notfound',
    standalone: true,
    imports: [CommonModule, MatCardModule],
    templateUrl: './notfound.component.html',
    styleUrl: './notfound.component.css'
})
export class NotfoundComponent {
    // constructor(private _location: Location) { }
    constructor(private router: Router) { }

    goBack() {
        // this._location.back();
        this.router.navigate(['/dashboard']);
    }
}
