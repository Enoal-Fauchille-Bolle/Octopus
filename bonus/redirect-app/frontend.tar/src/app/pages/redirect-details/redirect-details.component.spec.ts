import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RedirectDetailsComponent } from './redirect-details.component';

describe('RedirectDetailsComponent', () => {
  let component: RedirectDetailsComponent;
  let fixture: ComponentFixture<RedirectDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RedirectDetailsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RedirectDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
