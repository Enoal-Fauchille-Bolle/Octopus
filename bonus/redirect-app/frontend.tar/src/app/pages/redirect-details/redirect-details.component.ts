import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { environment } from '../../../environments/environment';
import { RedirectsService } from '../../services/redirects/redirects.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
    selector: 'app-redirect-details',
    standalone: true,
    imports: [
        CommonModule,
        MatCardModule,
        MatIconModule,
    ],
    templateUrl: './redirect-details.component.html',
    styleUrl: './redirect-details.component.css'
})
export class RedirectDetailsComponent {
    isLoading: boolean = true;
    redirect: any = null;
    aliasPrefix: string = environment.aliasPrefix;

    constructor(
        private redirectsService: RedirectsService,
        private route: ActivatedRoute,
        private router: Router,
    ) { }

    ngOnInit() {
        this.route.params.subscribe(params => {
            console.log(params)
            if (!params?.['id']) {
                this.isLoading = false;
                this.router.navigate(['/notfound']);
                return;
            }
            this.redirectsService.getRedirectFromId(params?.['id']).subscribe({
                next: (data: any) => {
                    this.redirect = data;
                    console.log(this.redirect);
                    this.isLoading = false;
                },
                error: (error: any) => {
                    console.log(error)
                    this.isLoading = false;
                    if (error.status === 404) {
                        this.router.navigate(['/notfund']);
                    } else if (error.status === 500) {
                        this.router.navigate(['/internalerror']);
                    }
                }
            });
        });
    }
}
