import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { environment } from '../../../environments/environment';
import { RedirectsService } from '../../services/redirects/redirects.service';
import { RouterModule } from '@angular/router';
import {
    MatDialog,
    MatDialogActions,
    MatDialogClose,
    MatDialogContent,
    MatDialogRef,
    MatDialogTitle,
} from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
    selector: 'app-redirects',
    standalone: true,
    imports: [
        CommonModule,
        RouterModule,
        MatCardModule,
        MatIconModule,
    ],
    templateUrl: './redirects.component.html',
    styleUrl: './redirects.component.css',
})
export class RedirectsComponent {
    isLoading: boolean = true;
    redirects: any = null;
    aliasPrefix: string = environment.aliasPrefix;
    readonly dialog = inject(MatDialog);

    constructor(private redirectsService: RedirectsService, private snackBar: MatSnackBar) { }

    ngOnInit() {
        this.redirectsService.getRedirects().subscribe((data: any) => {
            this.redirects = data.map((redirect: any) => {
                return {
                    ...redirect,
                    recent_stats: redirect.stats.filter((stat: any) => {
                        return new Date(stat.access_time).getTime() > new Date().getTime() - 7 * 24 * 60 * 60 * 1000; // 7 days
                    })
                };
            });
            console.log(this.redirects);
            this.isLoading = false;
        });
    }

    openSuccessSnackBar(message: string, action: string | undefined, delay: number | undefined): void {
        this.snackBar.open(message, action, {
            duration: delay,
            horizontalPosition: 'right',
            verticalPosition: 'bottom',
            panelClass: ['success-snackbar']
        });
    }

    copyToClipboard(text: string) {
        navigator.clipboard.writeText(text)
        .then(() => {
            this.openSuccessSnackBar("Copied to clipboard", "Close", 3000);
        })
        .catch(() => {
            console.error("Unable to copy text");
        });
    }

    openDeleteRedirectDialog(redirect: any): void {
        const dialogRef = this.dialog.open(DeleteRedirectDialog, {
            width: '250px',
            enterAnimationDuration: "100ms",
            exitAnimationDuration: "100ms",
            autoFocus: false,
        });

        dialogRef.afterClosed().subscribe(result => {
            const confirmDelete = result;
            if (confirmDelete) {
                console.log("Delete redirect");
                this.isLoading = true;
                this.redirectsService.deleteRedirect(redirect.id).subscribe(() => {
                    this.redirects = this.redirects.filter((r: any) => r.id !== redirect.id);
                    this.isLoading = false;
                });
            }
        });
    }
}

@Component({
    selector: 'delete-redirect-dialog',
    standalone: true,
    templateUrl: './delete-redirect-dialog.html',
    styleUrl: './delete-redirect-dialog.css',
    imports: [MatButtonModule, MatDialogActions, MatDialogClose, MatDialogTitle, MatDialogContent],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DeleteRedirectDialog {
    readonly dialogRef = inject(MatDialogRef<DeleteRedirectDialog>);
}
