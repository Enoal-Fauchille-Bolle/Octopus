import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { MatCardModule } from '@angular/material/card';
import { RedirectsService } from '../services/redirects/redirects.service';

@Component({
    selector: 'app-redirect-handler',
    standalone: true,
    imports: [CommonModule, MatCardModule],
    templateUrl: './redirect-handler.component.html',
    styleUrl: './redirect-handler.component.css'
})
export class RedirectHandlerComponent implements OnInit {
    constructor(
        private route: ActivatedRoute,
        private http: HttpClient,
        private router: Router,
        private redirectsService: RedirectsService
    ) { }

    ngOnInit(): void {
        const redirectId = this.route.snapshot.paramMap.get('redirectId');

        if (redirectId) {
            this.redirectsService.getRedirectFromAlias(redirectId).subscribe({
                next: (response) => {
                    console.log(response)
                    window.location.href = response.original_url;
                },
                error: (err) => {
                    console.error(err);
                    this.router.navigate(['/notfound']);
                }
            });
        } else {
            this.router.navigate(['/notfound']);
        }
    }
}
