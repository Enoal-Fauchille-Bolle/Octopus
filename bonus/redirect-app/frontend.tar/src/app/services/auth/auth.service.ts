import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { environment } from '../../../environments/environment';

@Injectable({
    providedIn: 'root',
})
export class AuthService {
    private apiUrl = environment.apiUrl;
    private tokenKey = environment.tokenKey;

    constructor(private http: HttpClient, private router: Router) { }

    //////////////////////////////////////////// API Calls ////////////////////////////////////////////

    async getUser(): Promise<any> {
        const user = await this.http.get<any>(`${this.apiUrl}/auth/me`, {}).toPromise();
        return user;
    }

    login(email: string, password: string, rememberMe: boolean = false, recaptchaResponse: string | null, mfaCode: string | null): Observable<any> {
        return this.http.post<any>(`${this.apiUrl}/auth/login`, { email, password, rememberme: rememberMe, recaptchaResponse, mfa_code: mfaCode });
    }

    register(email: string, username: string, password: string, recaptchaResponse: string | null): Observable<any> {
        return this.http.post<any>(`${this.apiUrl}/auth/register`, { email, username, password, recaptchaResponse });
    }

    logout(): void {
        this.http.post<any>(`${this.apiUrl}/auth/logout`, {}).subscribe({
            next: () => {
                this.removeToken();
                this.router.navigate(['/login']);
            },
            error: (error) => {
                this.router.navigate(['/login']);
            },
        });
    }

    forgotPassword(email: string, recaptchaResponse: string | null): Observable<any> {
        return this.http.post<any>(`${this.apiUrl}/auth/forgot-password`, { email, recaptchaResponse });
    }

    async checkResetToken(resetToken: string): Promise<boolean> {
        try {
            await this.http.get<any>(`${this.apiUrl}/auth/reset-password?token=${resetToken}`).toPromise();
            return true;
        } catch (error) {
            return false;
        }
    }

    resetPassword(password: string, resetToken: string): Observable<any> {
        return this.http.post<any>(`${this.apiUrl}/auth/reset-password`, { token: resetToken, password });
    }

    verifyEmail(verifyToken: string): Observable<any> {
        return this.http.post<any>(`${this.apiUrl}/auth/verify-email`, { token: verifyToken });
    }

    resendVerificationEmail(email: string, recaptchaResponse: string | null): Observable<any> {
        return this.http.post<any>(`${this.apiUrl}/auth/resend-verification-email`, { email, recaptchaResponse });
    }

    unlockAccount(unlockToken: string): Observable<any> {
        return this.http.post<any>(`${this.apiUrl}/auth/unlock-account`, { token: unlockToken });
    }

    //////////////////////////////////////////// Session Management ////////////////////////////////////////////

    getToken(): string | null {
        return localStorage.getItem(this.tokenKey);
    }

    storeToken(token: string): void {
        localStorage.setItem(this.tokenKey, token);
    }

    removeToken(): void {
        localStorage.removeItem(this.tokenKey);
    }

    isAuthenticated(): boolean {
        return !!localStorage.getItem(this.tokenKey);
    }

    async isSessionValid(): Promise<boolean> {
        try {
            const user = await this.http.get<any>(`${this.apiUrl}/auth/me`, {}).toPromise();
            return user;
        } catch (error) {
            return false;
        }
    }
}
