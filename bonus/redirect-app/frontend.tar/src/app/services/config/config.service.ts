import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { load } from 'js-yaml';
import { firstValueFrom } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ConfigService {
  private config: any;

  constructor(private http: HttpClient) {}

  async loadConfig(): Promise<void> {
    const yamlData = await firstValueFrom(
      this.http.get('config.yaml', { responseType: 'text' })
    );
    this.config = load(yamlData) as Record<string, any>;
  }

  get(key: string): any {
    return key.split('.').reduce((obj, k) => obj?.[k], this.config);
  }
}
