import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Injectable({
    providedIn: 'root',
})
export class LanguageService {
    private languageKey = 'user-language';

    constructor(private translateService: TranslateService) { }

    getSavedLanguage(): string {
        return localStorage.getItem(this.languageKey) || 'en';
    }

    setLanguage(language: string): void {
        this.translateService.use(language);
        localStorage.setItem(this.languageKey, language);
    }

    initLanguage(): void {
        const savedLanguage = this.getSavedLanguage();
        this.translateService.use(savedLanguage);
    }
}
