import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root',
})
export class ThemeService {
    private themeKey = 'theme';
    private theme = 'light';

    getSavedTheme(): string {
        return localStorage.getItem(this.themeKey) || 'light';
    }

    setDarkMode(darkMode: boolean) {
        if (darkMode) {
            this.theme = 'dark';
        } else {
            this.theme = 'light';
        }
        if (darkMode) {
            document.body.classList.add('dark-theme');
        } else {
            document.body.classList.remove('dark-theme');
        }
        localStorage.setItem(this.themeKey, this.theme);
    }

    initTheme(): void {
        const savedTheme = this.getSavedTheme();
        this.setDarkMode(savedTheme === 'dark');
    }
}