import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class UserService {
    private userSubject = new BehaviorSubject<any>(null);
    user$ = this.userSubject.asObservable();
    private apiUrl = environment.apiUrl;

    constructor(private http: HttpClient) { }

    setUser(user: any) {
        this.userSubject.next(user);
    }

    getUser() {
        return this.userSubject.value;
    }

    updateUserProfile(username: string, email: string): Observable<any> {
        return this.http.patch<any>(`${this.apiUrl}/auth/me`, { username, email });
    }
}
